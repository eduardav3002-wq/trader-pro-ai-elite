# Trader Pro AI Elite — Smart Overlay Android v2.8 (DEMONSTRAÇÃO)

## Para que serve

Protótipo **nativo Android** complementar ao Streamlit v2.7. Mostra um painel pequeno que pode ficar sobre outros aplicativos (se o usuário conceder a permissão do sistema), arrastar, minimizar em uma bolha `◈ DEMO`, expandir e fechar. Tem estados de **COMPRA / VENDA / AGUARDAR / NÃO OPERAR**, **todos simulados**. O painel avisa explicitamente que não existe feed de mercado ou execução de ordens.

**Não use estados COMPRA/VENDA desta demonstração para operar.** Nenhuma cotação, calendário, corretora, broker API, serviço remoto, autenticação, sinal financeiro real ou automação de ordens foi implementado. O APK não pede permissão INTERNET, Acessibilidade, leitura da tela nem instalação de certificados. Não muda o código do Streamlit nem altera a estratégia, o risco ou a validação prospectiva.

### O que está implementado

- O usuário concede `SYSTEM_ALERT_WINDOW` nas Configurações do Android.
- O painel roda num **serviço de primeiro plano iniciado manualmente** e exibe notificação permanente de que a DEMO está ativa (permissão de notificações solicitada no Android 13+).
- O painel é compacto, arrastável, minimizável e pode ser encerrado pelo `×`, pela notificação ou pela tela principal.
- Os estados de compra, venda e aguardar **expiram em 60 segundos** e retornam a **NÃO OPERAR**, usando tempo monotônico. O estado padrão e em caso de entrada inválida é **NÃO OPERAR**.
- Quando o usuário fecha o serviço a sobreposição é retirada. Quando o sistema encerra o serviço, a sobreposição pode desaparecer.
- Não usa APIs de acessibilidade, captura de tela ou leitura de outros aplicativos.

### Limitações importantes

- **Esta é uma compilação de código-fonte, não um APK já compilado.** O APK de debug será gerado por GitHub Actions ou Android Studio. Um teste de lógica não substitui o teste em aparelho.
- A sobreposição pode ser escondida ou bloqueada pelo Android ou por aplicativos sensíveis, incluindo corretoras. Respeite os bloqueios do sistema e da corretora.
- Não há feed ao vivo, envio de notificações de sinal ou comunicação com o painel Streamlit v2.7. O app Android é **independente e somente para testar a experiência de interface**.
- A notificação permanente serve para indicar que o painel está ativo; não é um sinal da bolsa. O sistema pode restringir notificações e serviços em segundo plano.
- APK debug é apropriado para teste pessoal; produção e Google Play exigem assinatura, revisão de permissões e política de serviço de primeiro plano.

## Como compilar no Android Studio

Abra esta pasta como projeto Android, sincronize o Gradle e execute **Build > Build APK(s)**. Requisitos: JDK 17, Android Gradle Plugin 8.7.3, Gradle 8.9 e SDK API 35.

## Como compilar apenas pelo celular com GitHub Actions no MESMO repositório Streamlit

É possível manter `trader-pro-ai-elite` **sem modificar `app.py`**:

1. Baixe o arquivo `Trader_Pro_AI_Elite_v2_8_Android.zip`. **Não extraia** esse ZIP para este método.
2. Abra o repositório do GitHub, em `main`, e envie o ZIP para a **raiz** usando **Add file > Upload files > Commit changes**.
3. No GitHub, use **Add file > Create new file**. No campo do nome digite exatamente `.github/workflows/android_overlay_v28.yml`. Cole o conteúdo completo do arquivo `android_overlay_v28.yml` fornecido junto ao ZIP. Confirme o commit.
4. Abra a aba **Actions** do GitHub, selecione `Gerar APK Android v2.8 DEMO` e execute **Run workflow**, caso não execute automaticamente.
5. Após uma execução **verde**, entre nessa execução, desça até **Artifacts** e toque no arquivo `Trader-Pro-AI-Elite-Android-v2.8-DEMO` (será um ZIP com `app-debug.apk`).
6. Extraia o ZIP de artifact no celular e, se desejar testar, instale o `app-debug.apk` conforme as permissões de instalação de apps da sua versão do Android. Não instale arquivos de fontes desconhecidas.

**Se a execução ficar vermelha**: abra os logs do GitHub Actions. Não presuma que o APK foi gerado. Envie o log do passo que falhou para correção.

**Evite renomear** o ZIP na raiz. A workflow procura o arquivo de nome exato acima.

## Como testar no celular

1. Abra o aplicativo `Trader Pro AI · Overlay DEMO`.
2. Toque em **Autorizar janela sobre outros apps** e conceda a permissão na tela do Android.
3. Volte ao app e toque em **Ativar painel flutuante (NÃO OPERAR)**.
4. Abra outro aplicativo. Arraste a faixa `◈ SMART ALERTS · DEMO` para mover o painel. Toque `−` para minimizar ou `×` para desligar.
5. Para demonstrar **COMPRA** e **VENDA**, volte ao aplicativo Android e toque nesses botões; depois volte ao outro aplicativo. O aviso expira e volta a **NÃO OPERAR** após 60 segundos. Não há sinal real.

### Testes locais realizados

A lógica Java pura (`DemoSignal` / `DemoPolicy`) é verificável com:

```
mkdir -p out
javac -encoding UTF-8 -d out app/src/main/java/com/traderproaielite/overlaydemo/DemoSignal.java app/src/main/java/com/traderproaielite/overlaydemo/DemoPolicy.java tests/DemoPolicyTest.java
java -cp out DemoPolicyTest
```

A compilação Android do aplicativo completo deverá ser validada na execução do workflow ou no Android Studio.
