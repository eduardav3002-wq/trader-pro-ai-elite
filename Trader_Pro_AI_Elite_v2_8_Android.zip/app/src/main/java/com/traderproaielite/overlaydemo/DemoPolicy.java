package com.traderproaielite.overlaydemo;

/** Simple deterministic TTL policy. Independent of Android and wall-clock changes. */
public final class DemoPolicy {
    public static final long TTL_MS = 60_000L;
    private DemoPolicy() {}

    public static DemoSignal effective(DemoSignal requested, long startedElapsedMs, long nowElapsedMs) {
        if (requested == null || requested == DemoSignal.NAO_OPERAR) return DemoSignal.NAO_OPERAR;
        if (startedElapsedMs < 0 || nowElapsedMs < startedElapsedMs) return DemoSignal.NAO_OPERAR;
        if (nowElapsedMs - startedElapsedMs >= TTL_MS) return DemoSignal.NAO_OPERAR;
        return requested;
    }
}
