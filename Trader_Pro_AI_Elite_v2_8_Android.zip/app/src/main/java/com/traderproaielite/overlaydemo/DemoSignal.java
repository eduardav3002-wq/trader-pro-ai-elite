package com.traderproaielite.overlaydemo;

/** Local demo state. No quotes, no broker, no backend, and no order routing. */
public enum DemoSignal {
    COMPRA("COMPRA · SIMULAÇÃO", "Exemplo visual apenas. NÃO use para operar.", 0xFF43D9A3),
    VENDA("VENDA · SIMULAÇÃO", "Exemplo visual apenas. NÃO use para operar.", 0xFFFF7798),
    AGUARDAR("AGUARDAR", "Simulação: os critérios não foram confirmados.", 0xFFA9C7EA),
    NAO_OPERAR("NÃO OPERAR", "SEM FEED AO VIVO. Nenhuma entrada habilitada.", 0xFFFFC76B);

    public final String label;
    public final String description;
    public final int color;

    DemoSignal(String label, String description, int color) {
        this.label = label;
        this.description = description;
        this.color = color;
    }

    public static DemoSignal fromUntrustedString(String value) {
        if (value == null) return NAO_OPERAR;
        for (DemoSignal state : values()) {
            if (state.name().equals(value)) return state;
        }
        return NAO_OPERAR;
    }
}
