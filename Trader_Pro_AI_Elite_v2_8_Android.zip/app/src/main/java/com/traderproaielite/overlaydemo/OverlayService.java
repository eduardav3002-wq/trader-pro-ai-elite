package com.traderproaielite.overlaydemo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/** User-initiated native overlay. All trade-like states are VISUAL DEMOS. */
public final class OverlayService extends Service {
    public static final String ACTION_SHOW = "com.traderproaielite.overlaydemo.SHOW_DEMO";
    public static final String ACTION_STOP = "com.traderproaielite.overlaydemo.STOP_DEMO";
    public static final String EXTRA_SIGNAL = "demo_signal";
    private static final String CHANNEL_ID = "demo_overlay_status_v28";
    private static final int NOTIFICATION_ID = 2808;
    private static final int BACKGROUND = 0xFF111C33;
    private static final int SECONDARY = 0xFFADB9D1;
    private final Handler tickHandler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private WindowManager.LayoutParams layoutParams;
    private LinearLayout overlay;
    private TextView countdown;
    private DemoSignal requested = DemoSignal.NAO_OPERAR;
    private long requestedAt = -1;
    private boolean minimized = false;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent == null || !ACTION_SHOW.equals(intent.getAction()) || !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        ensureForeground();
        requested = DemoSignal.fromUntrustedString(intent.getStringExtra(EXTRA_SIGNAL));
        requestedAt = SystemClock.elapsedRealtime();
        // Default always fails closed if the app is restarted or a state expires.
        if (requested == DemoSignal.NAO_OPERAR) requestedAt = -1;
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (overlay == null) createOverlay();
        else renderOverlay();
        tickHandler.removeCallbacks(expirationTick);
        tickHandler.postDelayed(expirationTick, 1000L);
        return START_NOT_STICKY;
    }

    private void ensureForeground() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Painel Android · DEMONSTRAÇÃO", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Aviso de que o painel de demonstração está ativo. Não contém sinais reais.");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 28, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 29, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Trader Pro AI · SOBREPOSIÇÃO DEMO")
                .setContentText("Painel simulado ativo · sem dados ao vivo ou ordens")
                .setContentIntent(openPi)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                        "Desligar painel", stopPi).build());
        Notification notice = builder.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notice, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notice);
        }
    }

    private void createOverlay() {
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        layoutParams = new WindowManager.LayoutParams(
                dp(280), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = dp(16);
        layoutParams.y = dp(110);
        renderOverlay();
        windowManager.addView(overlay, layoutParams);
    }

    private void renderOverlay() {
        if (overlay == null) return;
        overlay.removeAllViews();
        DemoSignal state = DemoPolicy.effective(requested, requestedAt, SystemClock.elapsedRealtime());
        if (state == DemoSignal.NAO_OPERAR) requested = DemoSignal.NAO_OPERAR;
        int stroke = state.color;
        overlay.setBackground(background(BACKGROUND, stroke, 18));
        overlay.setPadding(dp(13), dp(11), dp(13), dp(12));
        if (minimized) {
            TextView bubble = label("◈ DEMO", 14, stroke, true);
            bubble.setGravity(Gravity.CENTER);
            overlay.addView(bubble, new LinearLayout.LayoutParams(-1, dp(34)));
            bubble.setOnTouchListener(new DragListener(true));
            resizeOverlay(dp(100));
            return;
        }
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView heading = label("◈ SMART ALERTS · DEMO", 12, SECONDARY, true);
        titleRow.addView(heading, new LinearLayout.LayoutParams(0, dp(32), 1f));
        heading.setOnTouchListener(new DragListener(false));
        TextView minimize = label("−", 24, 0xFFE8EEFD, true);
        minimize.setGravity(Gravity.CENTER);
        titleRow.addView(minimize, new LinearLayout.LayoutParams(dp(32), dp(38)));
        minimize.setOnClickListener(v -> { minimized = true; renderOverlay(); });
        TextView close = label("×", 24, 0xFFFFA6AE, true);
        close.setGravity(Gravity.CENTER);
        titleRow.addView(close, new LinearLayout.LayoutParams(dp(32), dp(38)));
        close.setOnClickListener(v -> stopSelf());
        overlay.addView(titleRow);
        TextView stateLabel = label(state.label, 21, state.color, true);
        overlay.addView(stateLabel);
        TextView detail = label(state.description, 13, 0xFFE0E7F5, false);
        detail.setPadding(0, dp(5), 0, dp(5));
        overlay.addView(detail);
        countdown = label("", 11, SECONDARY, false);
        overlay.addView(countdown);
        updateCountdown(state);
        resizeOverlay(dp(280));
    }

    private void resizeOverlay(int width) {
        if (layoutParams == null) return;
        layoutParams.width = width;
        if (windowManager != null && overlay.getWindowToken() != null) {
            windowManager.updateViewLayout(overlay, layoutParams);
        }
    }

    private void updateCountdown(DemoSignal state) {
        if (countdown == null || minimized) return;
        if (state == DemoSignal.NAO_OPERAR) {
            countdown.setText("SEM FEED AO VIVO · SEM ORDENS");
            return;
        }
        long remaining = Math.max(0L,
                DemoPolicy.TTL_MS - (SystemClock.elapsedRealtime() - requestedAt));
        countdown.setText("SIMULAÇÃO · expira em " + ((remaining + 999L) / 1000L) + "s");
    }

    private final Runnable expirationTick = new Runnable() {
        @Override public void run() {
            if (overlay == null) return;
            DemoSignal effective = DemoPolicy.effective(requested, requestedAt,
                    SystemClock.elapsedRealtime());
            if (effective != requested) {
                requested = DemoSignal.NAO_OPERAR;
                requestedAt = -1;
                renderOverlay();
            } else {
                updateCountdown(effective);
            }
            tickHandler.postDelayed(this, 1000L);
        }
    };

    private TextView label(String value, int sizeSp, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(sizeSp);
        text.setTextColor(color);
        text.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return text;
    }

    private GradientDrawable background(int color, int border, int radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radiusDp));
        shape.setStroke(dp(1), border);
        return shape;
    }

    private int dp(float val) {
        return (int) (val * getResources().getDisplayMetrics().density + 0.5f);
    }

    private final class DragListener implements View.OnTouchListener {
        private final boolean togglesOnTap;
        private float rawX, rawY;
        private int originalX, originalY;
        private boolean dragged;

        DragListener(boolean togglesOnTap) { this.togglesOnTap = togglesOnTap; }
        @Override public boolean onTouch(View v, MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    rawX = ev.getRawX(); rawY = ev.getRawY();
                    originalX = layoutParams.x; originalY = layoutParams.y;
                    dragged = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float diffX = ev.getRawX() - rawX;
                    float diffY = ev.getRawY() - rawY;
                    if (Math.abs(diffX) > dp(7) || Math.abs(diffY) > dp(7)) dragged = true;
                    if (dragged) {
                        Point screen = new Point();
                        windowManager.getDefaultDisplay().getSize(screen);
                        layoutParams.x = Math.max(0, Math.min(screen.x - layoutParams.width,
                                originalX + Math.round(diffX)));
                        layoutParams.y = Math.max(0, Math.min(screen.y - dp(60),
                                originalY + Math.round(diffY)));
                        windowManager.updateViewLayout(overlay, layoutParams);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!dragged && togglesOnTap) {
                        minimized = false;
                        renderOverlay();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    return true;
                default:
                    return false;
            }
        }
    }

    @Override public void onDestroy() {
        tickHandler.removeCallbacks(expirationTick);
        if (windowManager != null && overlay != null) {
            try { windowManager.removeView(overlay); }
            catch (IllegalArgumentException ignored) { }
        }
        overlay = null;
        countdown = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
