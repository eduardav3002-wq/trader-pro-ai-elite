import com.traderproaielite.overlaydemo.DemoPolicy;
import com.traderproaielite.overlaydemo.DemoSignal;

public class DemoPolicyTest {
    private static void eq(Object expected, Object actual) {
        if (!expected.equals(actual)) throw new AssertionError("Esperado " + expected + ", obtido " + actual);
    }
    public static void main(String[] args) {
        eq(DemoSignal.NAO_OPERAR, DemoSignal.fromUntrustedString(null));
        eq(DemoSignal.NAO_OPERAR, DemoSignal.fromUntrustedString("COMPRA_REAL"));
        eq(DemoSignal.COMPRA, DemoSignal.fromUntrustedString("COMPRA"));
        eq(DemoSignal.NAO_OPERAR, DemoPolicy.effective(null, 100L, 101L));
        eq(DemoSignal.NAO_OPERAR, DemoPolicy.effective(DemoSignal.COMPRA, 100L, 99L));
        eq(DemoSignal.COMPRA, DemoPolicy.effective(DemoSignal.COMPRA, 100L, 60_099L));
        eq(DemoSignal.NAO_OPERAR, DemoPolicy.effective(DemoSignal.COMPRA, 100L, 60_100L));
        eq(DemoSignal.NAO_OPERAR, DemoPolicy.effective(DemoSignal.VENDA, 100L, 90_100L));
        eq(DemoSignal.NAO_OPERAR, DemoPolicy.effective(DemoSignal.NAO_OPERAR, 100L, 101L));
        eq(DemoSignal.AGUARDAR, DemoPolicy.effective(DemoSignal.AGUARDAR, 100L, 300L));
        System.out.println("10 verificacoes OK · estados e prazo de 60s (somente demonstracao)");
    }
}
