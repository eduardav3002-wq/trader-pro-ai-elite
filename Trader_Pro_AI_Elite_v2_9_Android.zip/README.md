# Trader Pro AI Elite — Smart Overlay Android v2.9 (SOMENTE DEMONSTRAÇÃO)

## O que mudou em relação à v2.8

A janela flutuante agora **aparece por aproximadamente 5 segundos e depois desaparece inteiramente**. Não sobra um cartão, ícone ou bolha sobre o gráfico. O serviço voluntariamente iniciado permanece identificado por uma notificação persistente do Android, que permite abrir o aplicativo ou desligá-lo.

O cartão reaparece por mais 5 segundos **apenas em mudanças importantes de estado**, não em cada atualização:

- Entrada em COMPRA ou VENDA, ou reversão entre elas — apenas sinal MANUAL de DEMONSTRAÇÃO.
- Entrada em NÃO OPERAR ao ocorrer um bloqueio / expiração.
- Entrada em AGUARDAR quando uma COMPRA ou VENDA é retirada.
- Mudança rotineira NÃO OPERAR → AGUARDAR não gera popup; estados repetidos também não geram popup.
- Na primeira ativação manual aparece NÃO OPERAR por 5 segundos, depois some.

**Regra de segurança que permanece:** COMPRA, VENDA e AGUARDAR simulados expiram após **60 segundos**, e o estado interno volta a NÃO OPERAR. Essa transição de segurança provoca um último popup de 5 segundos, mesmo quando a janela estava escondida. Ocultar a janela após 5 segundos NÃO significa que o estado foi validado ou permanece operacional: o aplicativo nunca recebe preço real.

**IMPORTANTE:** o Android v2.9 continua SEM cotações em tempo real, SEM sinais de mercado, SEM conexão ao Streamlit, SEM integração com corretora e SEM ordens. Os botões COMPRA / VENDA / AGUARDAR / NÃO OPERAR são apenas testes visuais. NÃO opere com base nessa demonstração.

## Atualizar usando somente o celular

A versão v2.8 do aplicativo não precisa ser alterada no Streamlit; apenas o aplicativo Android de demonstração será recompilado.

1. No GitHub do projeto `trader-pro-ai-elite`, na branch `main`, faça upload do arquivo **`Trader_Pro_AI_Elite_v2_9_Android.zip`** na raiz, SEM extrair, e confirme o commit.
2. Crie `.github/workflows/android_overlay_v29.yml` e cole o conteúdo integral do arquivo `android_overlay_v29.yml` que acompanha este pacote. Confirme o commit. O fluxo corrigido usa o SDK pré-instalado no runner, evitando o problema que tivemos na v2.8.
3. Na aba **Actions**, abra **Gerar APK Android v2.9 DEMO** e confirme `Success`. Em **Artifacts**, baixe o ZIP e extraia `app-debug.apk`.
4. Instale o `app-debug.apk` de seu próprio workflow. Se o Android recusar a atualização devido a **assinaturas diferentes do APK debug**, desinstale somente **Trader Pro AI · Overlay DEMO v2.8** e instale a v2.9. Isso não exclui o Streamlit ou o repositório. Depois, conceda novamente a permissão de sobreposição se for solicitado.

### Atenção

- Não renomeie o arquivo ZIP; o workflow procura exatamente o nome da v2.9.
- O APK ainda NÃO está compilado neste pacote: sua compilação real será confirmada pelo GitHub Actions.
- Ao ocultar o cartão, a notificação permanente do serviço continua disponível. É normal que não apareça uma bolha na tela.
- Algumas telas de aplicativos podem bloquear sobreposições por política do Android; não contorne restrições de segurança.
- Para testar as mudanças use os botões do aplicativo Android (não há detecção automática do mercado).

## Testes da lógica de 5 segundos

```bash
mkdir -p out
javac -encoding UTF-8 -d out app/src/main/java/com/traderproaielite/overlaydemo/DemoSignal.java app/src/main/java/com/traderproaielite/overlaydemo/DemoPolicy.java app/src/main/java/com/traderproaielite/overlaydemo/OverlayVisibilityPolicy.java tests/DemoPolicyTest.java tests/OverlayVisibilityPolicyTest.java
java -cp out DemoPolicyTest
java -cp out OverlayVisibilityPolicyTest
```

O teste puro Java cobre validade de 60s, janela de 5s, avisos críticos e supressão de repetições. Não equivale à compilação nem a teste de funcionamento em aparelho Android.
