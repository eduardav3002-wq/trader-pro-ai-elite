# Trader Pro AI Elite · Smart Overlay Android v3.0 — DOIS MODOS (DEMONSTRAÇÃO)

Esta versão evolui o Android v2.9 que já funcionou sobre outros aplicativos. **Não contém dados ao vivo**, não lê o gráfico da corretora, não envia ordens e não representa sinais financeiros reais. A versão Streamlit anterior permanece intacta.

## Seleção no próprio celular

Na tela inicial Android, após autorizar a sobreposição, escolha um dos dois botões em **Modo de exibição**:

- **⏱ TEMPORIZADO (padrão):** janela visível por aproximadamente 5 segundos; desaparece inteiramente e reaparece somente diante de mudança importante (COMPRA, VENDA, NÃO OPERAR ou cancelamento para AGUARDAR). Repetições não geram novos pop-ups.
- **▣ FIXO:** mantém o cartão sobre outros aplicativos até você tocar em `−` (minimizar para uma pequena bolha) ou `×` (encerrar). Você pode arrastar o cabeçalho. A bolha exibe o estado atual; mudanças não forçam a reabertura da janela minimizada.

O modo escolhido fica salvo localmente no Android e pode ser alterado enquanto o serviço está ativo. A mudança é aplicada no próximo ciclo de atualização (aproximadamente 250 ms), sem reiniciar o serviço.

**Em AMBOS os modos:** COMPRA, VENDA e AGUARDAR simulados expiram após 60 segundos de tempo monotônico. Então o estado muda para NÃO OPERAR mesmo quando a janela está fixa ou minimizada. No modo fixo, a janela não desaparece automaticamente; somente o estado muda. A notificação Android persistente permite voltar ao app ou desligar o serviço. Não há garantia de visibilidade sobre todas as telas, pois o Android e outros apps podem restringir sobreposições.

## Atualizar pelo celular, usando o GitHub

1. Faça upload, na raiz da branch `main` do repositório `trader-pro-ai-elite`, **do ZIP sem extrair** chamado `Trader_Pro_AI_Elite_v3_0_Android.zip`. Confirme o commit.
2. Crie o arquivo `.github/workflows/android_overlay_v30.yml` com todo o texto do arquivo `android_overlay_v30.yml` entregue junto ao pacote. Atenção ao recuo do YAML. Confirme o commit.
3. No GitHub, abra **Actions → Gerar APK Android v3.0 DEMO**. Somente se a execução concluir com `Success`, vá a **Artifacts**, baixe o arquivo gerado e extraia `app-debug.apk`.
4. Instale o APK no seu próprio aparelho. Caso o Android rejeite uma atualização por diferença na assinatura debug, desinstale apenas **Trader Pro AI · Overlay DEMO** e instale o novo APK. Isso não exclui seu site Streamlit. Habilite novamente a permissão **Aparecer sobre outros apps**, se necessário.

## Teste guiado

1. Escolha **TEMPORIZADO** e ative o painel. Teste uma COMPRA simulada: aparece por 5 s e some. Abra a calculadora para confirmar a sobreposição.
2. Volte ao app, escolha **FIXO** e toque em **Ativar painel (NÃO OPERAR)**. Abra a calculadora: o cartão deverá permanecer visível após 5 s. Arraste, minimize e toque na bolha para expandir.
3. Teste uma COMPRA simulada em FIXO. Após 60 s, o cartão deverá apresentar **NÃO OPERAR**, sem desaparecer sozinho.
4. Troque novamente para **TEMPORIZADO** e confira o desaparecimento em 5 s. Encerre pelo × ou pela notificação.

## Validação do código

A lógica pura Java foi testada com `javac` e as três classes de testes: `DemoPolicyTest`, `OverlayVisibilityPolicyTest` e `OverlayDisplayModeTest`. São **47 verificações de lógica**. Esses testes não substituem a compilação completa do APK nem um teste de interface em aparelho real. A compilação é realizada no seu GitHub Actions; nenhum APK pré-compilado está incluído.

## Segurança

O usuário deve iniciar e autorizar voluntariamente a janela. Não use a demonstração para tomar decisões reais de negociação. **NÃO OPERAR** é o estado seguro na ausência de um sinal de demonstração válido. A versão não possui integração com o Streamlit, mercado, corretora, rede ou automação de ordens.
