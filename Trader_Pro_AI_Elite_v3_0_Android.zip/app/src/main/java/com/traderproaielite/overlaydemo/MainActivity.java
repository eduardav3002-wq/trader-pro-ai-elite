package com.traderproaielite.overlaydemo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private TextView permissionStatus;
    private TextView modeStatus;
    private static final int REQUEST_NOTIFICATIONS = 28;
    private final int ink = Color.rgb(235, 241, 255);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9, 14, 29));
        getWindow().setNavigationBarColor(Color.rgb(9, 14, 29));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(9, 14, 29));
        LinearLayout base = new LinearLayout(this);
        base.setOrientation(LinearLayout.VERTICAL);
        base.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(base);

        TextView logo = text("◈ TRADER PRO AI ELITE", 25, ink, true);
        base.addView(logo);
        base.addView(text("ANDROID · SMART OVERLAY v3.0", 14, 0xFFB1A6FF, true));
        addSpace(base, 20);
        TextView warn = text("DEMONSTRAÇÃO · SEM COTAÇÕES AO VIVO · NÃO USAR PARA OPERAR", 16, 0xFFFFC76B, true);
        warn.setPadding(dp(15), dp(15), dp(15), dp(15));
        warn.setBackground(card(0xFF2A2530, 0xFFFFC76B));
        base.addView(warn);
        addSpace(base, 18);
        base.addView(text("Permissão necessária", 19, ink, true));
        permissionStatus = text("Verificando a permissão...", 14, 0xFFB9C7D9, false);
        base.addView(permissionStatus);
        base.addView(button("1 · Autorizar janela sobre outros apps", () -> {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            try { startActivity(permission); }
            catch (Exception e) { Toast.makeText(this, "Abra as permissões de sobreposição nas Configurações.", Toast.LENGTH_LONG).show(); }
        }));
        addSpace(base, 14);
        base.addView(text("Modo de exibição · escolha o seu", 19, ink, true));
        modeStatus = text("", 14, 0xFFB9C7D9, false);
        base.addView(modeStatus);
        base.addView(button("⏱ Temporizado · aparece por 5 segundos", () -> chooseMode(OverlayDisplayMode.TEMPORIZADO)));
        base.addView(button("▣ Fixo · permanece na tela", () -> chooseMode(OverlayDisplayMode.FIXO)));
        updateModeStatus();
        base.addView(button("2 · Ativar painel (NÃO OPERAR)", () -> showState(DemoSignal.NAO_OPERAR)));
        addSpace(base, 16);
        base.addView(text("Estados de teste (toque para alterar o painel)", 18, ink, true));
        base.addView(button("COMPRA · somente simulação", () -> showState(DemoSignal.COMPRA)));
        base.addView(button("VENDA · somente simulação", () -> showState(DemoSignal.VENDA)));
        base.addView(button("AGUARDAR · somente simulação", () -> showState(DemoSignal.AGUARDAR)));
        base.addView(button("NÃO OPERAR · estado seguro", () -> showState(DemoSignal.NAO_OPERAR)));
        addSpace(base, 14);
        base.addView(button("Desligar janela flutuante", () -> {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Painel encerrado.", Toast.LENGTH_SHORT).show();
        }));
        addSpace(base, 20);
        base.addView(text("Como testar", 19, ink, true));
        base.addView(text("Escolha TEMPORIZADO ou FIXO antes de ativar. TEMPORIZADO: o aviso aparece por aproximadamente 5 segundos, some inteiramente e só reaparece em mudanças importantes. FIXO: o cartão permanece sobre outros aplicativos até você minimizar (bolha) ou desligar (×); uma mudança atualiza o texto sem forçar a expansão da bolha. Em ambos os modos, o estado simulado expira em 60 segundos e volta a NÃO OPERAR. Avisos repetidos não reiniciam o prazo. A seleção fica salva neste aparelho.", 15, 0xFFC2CEE1, false));
        addSpace(base, 14);
        base.addView(text("Sem internet, integração com corretora, automação de ordens, leitura da tela ou alertas financeiros reais. Os botões são DEMONSTRAÇÕES MANUAIS: não há monitoramento automático de sinais. O Streamlit v2.7 não é alterado.", 13, 0xFF8D9AB3, false));
        setContentView(scroll);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        updateModeStatus();
        permissionStatus.setText(Settings.canDrawOverlays(this)
                ? "✓ Sobreposição autorizada. O painel pode aparecer em outros aplicativos."
                : "✕ Sobreposição ainda não autorizada. Habilite antes de ativar.");
    }

    private void chooseMode(OverlayDisplayMode mode) {
        getSharedPreferences(OverlayDisplayMode.PREFERENCES, MODE_PRIVATE).edit()
                .putString(OverlayDisplayMode.PREF_KEY, mode.name()).apply();
        updateModeStatus();
        Toast.makeText(this, mode == OverlayDisplayMode.FIXO
                ? "Modo FIXO selecionado · minimize ou feche quando quiser"
                : "Modo TEMPORIZADO selecionado · 5 segundos", Toast.LENGTH_SHORT).show();
        // Se o serviço já estiver ativo, ele observa a preferência e troca de modo
        // no próximo ciclo sem exigir nova permissão ou reinício.
    }

    private void updateModeStatus() {
        if (modeStatus == null) return;
        OverlayDisplayMode mode = OverlayDisplayMode.fromSetting(getSharedPreferences(
                OverlayDisplayMode.PREFERENCES, MODE_PRIVATE).getString(OverlayDisplayMode.PREF_KEY, null));
        modeStatus.setText(mode == OverlayDisplayMode.FIXO
                ? "✓ SELECIONADO: FIXO · só fecha ao minimizar ou desligar"
                : "✓ SELECIONADO: TEMPORIZADO · 5 segundos");
    }

    private void showState(DemoSignal state) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primeiro autorize a janela flutuante.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, OverlayService.class);
        intent.setAction(OverlayService.ACTION_SHOW);
        intent.putExtra(OverlayService.EXTRA_SIGNAL, state.name());
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
            Toast.makeText(this, "DEMO: " + (OverlayDisplayMode.fromSetting(getSharedPreferences(
                    OverlayDisplayMode.PREFERENCES, MODE_PRIVATE).getString(OverlayDisplayMode.PREF_KEY, null))
                    == OverlayDisplayMode.FIXO ? "janela fixa" : "janela por 5s"), Toast.LENGTH_SHORT).show();
        } catch (RuntimeException e) {
            Toast.makeText(this, "Não foi possível ativar. Confira as permissões do Android.", Toast.LENGTH_LONG).show();
        }
    }

    private Button button(String label, Runnable action) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(label);
        button.setTextSize(14);
        button.setTextColor(ink);
        button.setBackground(card(0xFF202A43, 0xFF424F75));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(10);
        button.setLayoutParams(lp);
        button.setOnClickListener(v -> action.run());
        return button;
    }
    private TextView text(String text, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(sp);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setLineSpacing(dp(4), 1f);
        return v;
    }
    private GradientDrawable card(int bg, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(bg); d.setCornerRadius(dp(16)); d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float px) { return (int) (px * getResources().getDisplayMetrics().density + .5f); }
    private void addSpace(LinearLayout l, int dp) { View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1, dp(dp))); }
}
