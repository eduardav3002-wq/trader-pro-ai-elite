# Trader Pro AI Elite v3.1 · Smart Overlay Android + ponte DEMO

Este projeto parte da v3.0 que foi testada no celular e preserva **TEMPORIZADO (5 s)** e **FIXO**. Adiciona uma ponte opcional com Supabase para que estados **SIMULADOS** publicados pelo Streamlit apareçam automaticamente na janela Android. **NÃO É um serviço de cotações nem produz sinais operáveis.**

## Como funciona

1. O Streamlit, **se o usuário autorizar com um PIN privado**, inicia um roteiro fictício COMPRA → AGUARDAR → VENDA → NÃO OPERAR. Ele envia um registro a cada 20 segundos enquanto a página estiver ativa.
2. Um projeto Supabase armazena somente o **último estado fictício**, identificado por evento, data e validade. A tabela é pública **somente para leitura** pelo aplicativo Android. Escrever exige a **chave secret no servidor Streamlit**.
3. Ao selecionar **Iniciar alertas DEMO automáticos**, o Android consulta esse registro por HTTPS aproximadamente a cada cinco segundos e usa a janela temporizada ou fixa. Repetições não reabrem o cartão.
4. Quando faltar rede, houver mensagens vencidas, formato incorreto ou dados inesperados, o estado é **NÃO OPERAR**. O serviço usa notificação persistente, pode ser encerrado pelo usuário e **não lê a tela da corretora**.

**Limitações:** a ponte depende de internet e de um projeto Supabase configurado. O publicador Streamlit pode parar quando a aba for suspensa ou fechada. Polling e sistemas móveis não garantem entrega imediata, especialmente sob economia de bateria. Não use em operações reais.

## Configuração no celular

### A · Implantar a interface Streamlit

Na raiz do repositório `trader-pro-ai-elite`, substitua `app.py` pelo novo `app.py` do pacote de atualização e adicione `bridge_v31.py`. Não duplique `app(5).py`. A página seguirá funcionando, mas mostrará a ponte como **desativada** até configurar as credenciais.

### B · Criar o canal de testes

1. Crie um projeto separado para **DEMONSTRAÇÃO** em [Supabase](https://supabase.com/).
2. Em **SQL Editor**, cole e execute todo o arquivo `BRIDGE_SUPABASE_V31.sql`, entregue junto ao pacote.
3. Copie a **Project URL** (formato `https://seuprojeto.supabase.co`), a chave **Publishable** (`sb_publishable_...`) e a chave **Secret** (`sb_secret_...`). As chaves têm permissões diferentes; **NUNCA coloque a Secret no GitHub, APK, chat ou Android**.
4. Na interface do Streamlit Community Cloud: **Manage app → Settings → Secrets**, salve (com valores reais):

```toml
BRIDGE_V31_URL = "https://SEU-PROJETO.supabase.co"
BRIDGE_V31_SECRET_KEY = "sb_secret_CHAVE_PRIVADA_SOMENTE_NO_SERVIDOR"
BRIDGE_V31_PIN = "UM-PIN-LONGO-ALEATORIO-E-PRIVADO"
```

A URL e o PIN devem ser definidos por você. Use um PIN difícil de adivinhar. **Não comite este bloco preenchido no GitHub.**

### C · Compilar o Android no GitHub Actions

1. Envie o ZIP `Trader_Pro_AI_Elite_v3_1_Android.zip`, **sem extrair**, à raiz do repositório na branch `main`.
2. Crie `.github/workflows/android_overlay_v31.yml` com o conteúdo do arquivo `android_overlay_v31.yml` fornecido.
3. Após o commit, abra **Actions → Gerar APK Android v3.1 DEMO**. A compilação só estará confirmada quando aparecer **Success** e um artefato com `app-debug.apk`.
4. Instale no seu aparelho. Como o APK é de depuração, pode ser preciso desinstalar **somente o aplicativo DEMO antigo** se a assinatura for diferente. Preserve o Streamlit.

### D · Testar a transmissão

1. No Android, autorize **Aparecer sobre outros apps**, escolha **TEMPORIZADO** ou **FIXO**, informe a **Project URL** e **somente a chave Publishable**, salve e toque em **3 · Iniciar alertas DEMO automáticos**.
2. No Streamlit, abra **🔔 Smart Alerts**, digite seu PIN privado e toque em **Autorizar emissor DEMO** e depois **Iniciar roteiro automático**.
3. Com a página Streamlit ativa, o Android deve consultar a sequência de estados. No temporizado, a janela aparece até 5 s por mudança importante; no fixo, permanece visível. A validade das mensagens é de 45 s.
4. Pare o roteiro pelo botão **Parar**. Em falha de rede, falta de dados novos ou mensagem expirada, confira a volta a **NÃO OPERAR**.

### Proteções técnicas

- HTTPS para URL estrita de projeto Supabase; somente uma tabela de um canal demo.
- A chave `sb_publishable_` do Android é de leitura, com privilégios SQL e RLS; não é credencial privada.
- A chave `sb_secret_` só fica em `st.secrets` no servidor Streamlit.
- Dados de demonstração restritos a `mode=DEMONSTRACAO`, `contract=WINZ26`, quatro estados permitidos, carimbo temporal e validade máxima 60 segundos.
- Respostas de rede limitadas a 8 KiB, timeouts definidos, nenhuma ordem ou integração de corretora.
- Continuidade do serviço depende de permissões e restrições de bateria do Android; o usuário pode desligá-lo a qualquer momento.

## Testes

Foram testadas as políticas Java no JVM (65 verificações) e a suíte Streamlit (244 testes aprovados e 1 ignorado). **Não houve compilação Android completa nem teste de rede Supabase nesta sessão**; esses passos ainda dependem do GitHub Actions e da configuração real da ponte.
