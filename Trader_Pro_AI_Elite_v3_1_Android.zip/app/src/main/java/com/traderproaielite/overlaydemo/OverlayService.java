package com.traderproaielite.overlaydemo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/** User-initiated native overlay. All trade-like states are VISUAL DEMOS. */
public final class OverlayService extends Service {
    public static final String ACTION_SHOW = "com.traderproaielite.overlaydemo.SHOW_DEMO";
    public static final String ACTION_START_BRIDGE = "com.traderproaielite.overlaydemo.START_BRIDGE_DEMO";
    public static final String ACTION_STOP = "com.traderproaielite.overlaydemo.STOP_DEMO";
    public static final String EXTRA_SIGNAL = "demo_signal";
    private static final String CHANNEL_ID = "demo_overlay_status_v30";
    private static final int NOTIFICATION_ID = 3009;
    private static final int BACKGROUND = 0xFF111C33;
    private static final int SECONDARY = 0xFFADB9D1;
    private final Handler tickHandler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private WindowManager.LayoutParams layoutParams;
    private LinearLayout overlay;
    private TextView countdown;
    private DemoSignal requested = DemoSignal.NAO_OPERAR;
    private long requestedAt = -1;
    private boolean minimized = false;
    private boolean activated = false;
    private long popupShownAt = -1L;
    private OverlayDisplayMode displayMode = OverlayDisplayMode.TEMPORIZADO;
    // Read-only demo polling. The service starts ONLY after an explicit user action.
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private boolean bridgeMode = false;
    private boolean requestInFlight = false;
    private String lastBridgeEvent = "";
    private long nextPollElapsed = 0L;
    private long remoteValidUntilElapsed = -1L;
    private static final long POLL_MS = 5_000L;
    private static final long RETRY_MS = 10_000L;


    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent == null || !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_START_BRIDGE.equals(intent.getAction())) {
            bridgeMode = true;
            lastBridgeEvent = "";
            remoteValidUntilElapsed = -1L;
            nextPollElapsed = 0L;
            displayMode = readMode();
            ensureForeground();
            long now = SystemClock.elapsedRealtime();
            activated = true;
            // Fail closed immediately while waiting for the first HTTPS response.
            requested = DemoSignal.NAO_OPERAR;
            requestedAt = -1L;
            if (displayMode == OverlayDisplayMode.FIXO) {
                if (overlay == null) showPopup(now);
                else renderOverlay();
            } else showPopup(now);
            tickHandler.removeCallbacks(expirationTick);
            tickHandler.postDelayed(expirationTick, 100L);
            return START_NOT_STICKY;
        }
        if (!ACTION_SHOW.equals(intent.getAction())) {
            stopSelf(); return START_NOT_STICKY;
        }
        // Explicitly entering manual DEMO cancels the remote polling mode.
        bridgeMode = false;
        remoteValidUntilElapsed = -1L;
        displayMode = readMode();
        ensureForeground();
        long now = SystemClock.elapsedRealtime();
        DemoSignal previous = DemoPolicy.effective(requested, requestedAt, now);
        DemoSignal incoming = DemoSignal.fromUntrustedString(intent.getStringExtra(EXTRA_SIGNAL));
        boolean firstActivation = !activated;
        activated = true;

        // IMPORTANT: identical states do not restart the 60-second validity window,
        // and do not resurface a popup that has already disappeared.
        if (firstActivation || incoming != previous) {
            requested = incoming;
            requestedAt = incoming == DemoSignal.NAO_OPERAR ? -1L : now;
            if (displayMode == OverlayDisplayMode.FIXO) {
                // Do not reopen a manually minimized fixed panel on every signal.
                if (overlay == null) showPopup(now);
                else renderOverlay();
            } else if (OverlayVisibilityPolicy.shouldPopup(previous, incoming, firstActivation)) {
                showPopup(now);
            } else {
                hidePopup();
            }
        }
        tickHandler.removeCallbacks(expirationTick);
        tickHandler.postDelayed(expirationTick, 250L);
        return START_NOT_STICKY;
    }

    private void ensureForeground() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Painel Android · DEMONSTRAÇÃO", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Aviso de que o painel de demonstração está ativo. Não contém sinais reais.");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 28, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 29, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Trader Pro AI · SOBREPOSIÇÃO DEMO")
                .setContentText(bridgeMode
                        ? "PONTE DEMO · sem cotações reais · desconecte quando quiser"
                        : (displayMode == OverlayDisplayMode.FIXO
                        ? "Modo FIXO · demonstração, sem sinais reais"
                        : "Modo TEMPORIZADO · janela de 5 segundos"))
                .setContentIntent(openPi)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                        "Desligar painel", stopPi).build());
        Notification notice = builder.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notice, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notice);
        }
    }

    private void showPopup(long now) {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        popupShownAt = now;
        minimized = false;
        if (overlay == null) createOverlay();
        else renderOverlay();
    }

    private void hidePopup() {
        popupShownAt = -1L;
        minimized = false;
        countdown = null;
        if (windowManager != null && overlay != null) {
            try { windowManager.removeView(overlay); }
            catch (IllegalArgumentException ignored) { }
        }
        overlay = null;
        // Keep layoutParams: when an important signal changes, restore the
        // popup at the same position where the user dragged it.
    }

    private void createOverlay() {
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        if (layoutParams == null) {
            layoutParams = new WindowManager.LayoutParams(
                    dp(280), WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            layoutParams.gravity = Gravity.TOP | Gravity.START;
            layoutParams.x = dp(16);
            layoutParams.y = dp(110);
        }
        renderOverlay();
        try { windowManager.addView(overlay, layoutParams); }
        catch (SecurityException | WindowManager.BadTokenException e) { stopSelf(); }
    }

    private void renderOverlay() {
        if (overlay == null) return;
        overlay.removeAllViews();
        DemoSignal state = DemoPolicy.effective(requested, requestedAt, SystemClock.elapsedRealtime());
        if (state == DemoSignal.NAO_OPERAR) requested = DemoSignal.NAO_OPERAR;
        int stroke = state.color;
        overlay.setBackground(background(BACKGROUND, stroke, 18));
        overlay.setPadding(dp(13), dp(11), dp(13), dp(12));
        if (minimized) {
            TextView bubble = label(state == DemoSignal.NAO_OPERAR ? "◈ NÃO OPERAR" : "◈ " + state.name(), 11, stroke, true);
            bubble.setGravity(Gravity.CENTER);
            overlay.addView(bubble, new LinearLayout.LayoutParams(-1, dp(34)));
            bubble.setOnTouchListener(new DragListener(true));
            resizeOverlay(dp(132));
            return;
        }
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView heading = label("◈ SMART ALERTS · DEMO", 12, SECONDARY, true);
        titleRow.addView(heading, new LinearLayout.LayoutParams(0, dp(32), 1f));
        heading.setOnTouchListener(new DragListener(false));
        TextView minimize = label("−", 24, 0xFFE8EEFD, true);
        minimize.setGravity(Gravity.CENTER);
        titleRow.addView(minimize, new LinearLayout.LayoutParams(dp(32), dp(38)));
        minimize.setOnClickListener(v -> { minimized = true; renderOverlay(); });
        TextView close = label("×", 24, 0xFFFFA6AE, true);
        close.setGravity(Gravity.CENTER);
        titleRow.addView(close, new LinearLayout.LayoutParams(dp(32), dp(38)));
        close.setOnClickListener(v -> stopSelf());
        overlay.addView(titleRow);
        TextView stateLabel = label(state.label, 21, state.color, true);
        overlay.addView(stateLabel);
        TextView detail = label(state.description, 13, 0xFFE0E7F5, false);
        detail.setPadding(0, dp(5), 0, dp(5));
        overlay.addView(detail);
        countdown = label("", 11, SECONDARY, false);
        overlay.addView(countdown);
        updateCountdown(state);
        resizeOverlay(dp(280));
    }

    private void resizeOverlay(int width) {
        if (layoutParams == null) return;
        layoutParams.width = width;
        if (windowManager != null && overlay.getWindowToken() != null) {
            windowManager.updateViewLayout(overlay, layoutParams);
        }
    }

    private void updateCountdown(DemoSignal state) {
        if (countdown == null || minimized) return;
        if (state == DemoSignal.NAO_OPERAR) {
            countdown.setText("SEM FEED AO VIVO · SEM ORDENS");
            return;
        }
        long remaining = Math.max(0L,
                DemoPolicy.TTL_MS - (SystemClock.elapsedRealtime() - requestedAt));
        countdown.setText("SIMULAÇÃO · expira em " + ((remaining + 999L) / 1000L) + "s");
    }

    /** Runs an HTTPS GET on a worker thread, never on the Android UI thread. */
    private void maybePoll(long nowElapsed) {
        if (!bridgeMode || requestInFlight || nowElapsed < nextPollElapsed) return;
        requestInFlight = true;
        nextPollElapsed = nowElapsed + POLL_MS;
        String url = getSharedPreferences("bridge_v31", MODE_PRIVATE).getString("url", "");
        String publicKey = getSharedPreferences("bridge_v31", MODE_PRIVATE).getString("publishable", "");
        ioExecutor.execute(() -> {
            SupabaseDemoClient.Event event = null;
            try { event = SupabaseDemoClient.fetch(url, publicKey); }
            catch (Exception ignored) { /* Network, API, JSON and expiry all fail closed. */ }
            final SupabaseDemoClient.Event accepted = event;
            tickHandler.post(() -> {
                requestInFlight = false;
                if (!bridgeMode) return;
                long current = SystemClock.elapsedRealtime();
                if (accepted == null) {
                    nextPollElapsed = current + RETRY_MS;
                    remoteValidUntilElapsed = -1L;
                    applyRemoteState(DemoSignal.NAO_OPERAR, -1L, current);
                } else {
                    if (!accepted.eventId.equals(lastBridgeEvent)) {
                        lastBridgeEvent = accepted.eventId;
                        long wallNow = System.currentTimeMillis();
                        long age = Math.max(0L, wallNow - accepted.issuedAtMs);
                        long remaining = Math.max(0L, accepted.expiresAtMs - wallNow);
                        remoteValidUntilElapsed = current + remaining;
                        applyRemoteState(accepted.state, age, current);
                    }
                }
            });
        });
    }

    private void applyRemoteState(DemoSignal next, long ageMs, long now) {
        if (!bridgeMode) return;
        DemoSignal previous = DemoPolicy.effective(requested, requestedAt, now);
        // Never leave an expired BUY/SELL visible after a transport error.
        if (next == DemoSignal.NAO_OPERAR) {
            requested = DemoSignal.NAO_OPERAR;
            requestedAt = -1L;
        } else {
            requested = next;
            requestedAt = now - Math.min(Math.max(ageMs,0L),DemoPolicy.TTL_MS);
        }
        if (displayMode == OverlayDisplayMode.FIXO) {
            if (overlay == null) showPopup(now);
            else renderOverlay();
        } else if (OverlayVisibilityPolicy.shouldPopup(previous,next,false)) {
            showPopup(now);
        } else if (previous != next) {
            hidePopup();
        }
    }

    private final Runnable expirationTick = new Runnable() {
        @Override public void run() {
            if (!Settings.canDrawOverlays(OverlayService.this)) { stopSelf(); return; }
            long now = SystemClock.elapsedRealtime();
            OverlayDisplayMode selected = readMode();
            if (selected != displayMode) {
                displayMode = selected;
                ensureForeground();
                // A mode selection is intentional. Reopen once to confirm the change.
                if (displayMode == OverlayDisplayMode.FIXO) showPopup(now);
                else if (minimized) hidePopup();
                else showPopup(now);
            }
            if (bridgeMode) {
                if (remoteValidUntilElapsed >= 0 && now >= remoteValidUntilElapsed) {
                    remoteValidUntilElapsed = -1L;
                    applyRemoteState(DemoSignal.NAO_OPERAR,-1L,now);
                }
                maybePoll(now);
            }
            DemoSignal effective = DemoPolicy.effective(requested, requestedAt, now);
            if (effective != requested) {
                DemoSignal previous = requested;
                requested = DemoSignal.NAO_OPERAR;
                requestedAt = -1L;
                // Expiration to NÃO OPERAR always occurs, even with a fixed window.
                if (displayMode == OverlayDisplayMode.FIXO) {
                    if (overlay == null) showPopup(now);
                    else renderOverlay(); // Keeps a manually minimized bubble minimized.
                } else if (OverlayVisibilityPolicy.shouldPopup(previous, requested, false)) {
                    showPopup(now);
                } else {
                    hidePopup();
                }
            }
            if (OverlayVisibilityPolicy.shouldHide(popupShownAt, now, displayMode)) {
                hidePopup();
            } else if (overlay != null) {
                updateCountdown(requested);
            }
            tickHandler.postDelayed(this, 250L);
        }
    };

    private OverlayDisplayMode readMode() {
        return OverlayDisplayMode.fromSetting(getSharedPreferences(
                OverlayDisplayMode.PREFERENCES, MODE_PRIVATE).getString(OverlayDisplayMode.PREF_KEY, null));
    }

    private TextView label(String value, int sizeSp, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(sizeSp);
        text.setTextColor(color);
        text.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return text;
    }

    private GradientDrawable background(int color, int border, int radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radiusDp));
        shape.setStroke(dp(1), border);
        return shape;
    }

    private int dp(float val) {
        return (int) (val * getResources().getDisplayMetrics().density + 0.5f);
    }

    private final class DragListener implements View.OnTouchListener {
        private final boolean togglesOnTap;
        private float rawX, rawY;
        private int originalX, originalY;
        private boolean dragged;

        DragListener(boolean togglesOnTap) { this.togglesOnTap = togglesOnTap; }
        @Override public boolean onTouch(View v, MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    rawX = ev.getRawX(); rawY = ev.getRawY();
                    originalX = layoutParams.x; originalY = layoutParams.y;
                    dragged = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float diffX = ev.getRawX() - rawX;
                    float diffY = ev.getRawY() - rawY;
                    if (Math.abs(diffX) > dp(7) || Math.abs(diffY) > dp(7)) dragged = true;
                    if (dragged) {
                        Point screen = new Point();
                        windowManager.getDefaultDisplay().getSize(screen);
                        layoutParams.x = Math.max(0, Math.min(screen.x - layoutParams.width,
                                originalX + Math.round(diffX)));
                        layoutParams.y = Math.max(0, Math.min(screen.y - dp(60),
                                originalY + Math.round(diffY)));
                        windowManager.updateViewLayout(overlay, layoutParams);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!dragged && togglesOnTap) {
                        minimized = false;
                        renderOverlay();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    return true;
                default:
                    return false;
            }
        }
    }

    @Override public void onDestroy() {
        bridgeMode = false;
        tickHandler.removeCallbacks(expirationTick);
        ioExecutor.shutdownNow();
        hidePopup();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
