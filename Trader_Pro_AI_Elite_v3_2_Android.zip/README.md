# Trader Pro AI Elite · Smart Overlay Android v3.2 (DEMO)

Esta atualização evolui o protótipo **v3.1 que já funcionou no celular**. Ela não envia ordens, não calcula sinais de mercado e não se conecta a uma corretora.

## Novidades

- Monitor de leitura da ponte: **CONECTANDO**, **CONECTADA**, **ATRASADA**, **INDISPONÍVEL** e **DESATIVADA**.
- Proteção adicional: eventos **novos** com idade estimada maior que 12 s não aparecem como COMPRA/VENDA; eventos já recebidos sem renovação por mais de 28 s retornam para NÃO OPERAR.
- Deduplicação pelo `event_id`, bloqueio de retrocessos cronológicos e proteção contra respostas de rede de sessões antigas.
- Histórico **local**, com até 50 mudanças ou falhas relevantes: horário de publicação, horário de recepção, idade estimada e duração do HTTP. A tela mostra os 20 mais recentes; o usuário pode compartilhar ou apagar o histórico.
- Mantidos os modos **TEMPORIZADO (5 segundos)** e **FIXO**, o retorno seguro NÃO OPERAR e a ponte Supabase existente (`trader_demo_alert_v31`).

## O que as medições significam

- `http_rtt_ms`: duração da consulta HTTPS até o retorno; **não** é a latência de publicação → Android.
- `idade_estimada_ms`: horário do recebimento no Android menos `issued_at` enviado pelo Streamlit. Depende de os relógios dos dois dispositivos/servidores estarem sincronizados. **Não equivale a latência garantida**.
- `recebido_utc`: instante em que o Android terminou de receber a resposta.
- Eventos duplicados não são registrados novamente; o histórico não é um log de cada consulta de 5 segundos.
- Sem confirmação de rede ou com dados vencidos, o painel mostra NÃO OPERAR.

## Compilar APK via GitHub no celular

1. Envie `Trader_Pro_AI_Elite_v3_2_Android.zip` à **raiz** da branch `main` do repositório `trader-pro-ai-elite`, sem extrair. Confirme o nome exato.
2. Crie `.github/workflows/android_overlay_v32.yml` e cole o arquivo de workflow fornecido fora deste ZIP.
3. Abra GitHub **Actions → Gerar APK Android v3.2 DEMO** e aguarde um resultado **Success**.
4. Na execução bem-sucedida, baixe o Artifact `Trader-Pro-AI-Elite-Android-v3.2-DEMO` e extraia `app-debug.apk`.
5. Instale no Android. Caso haja conflito de assinatura entre APKs de debug, poderá ser necessário desinstalar **apenas a versão DEMO anterior** e instalar a nova; isso apaga a configuração local da chave pública e histórico antigo. Tenha a URL e a `sb_publishable_` disponíveis para configurar novamente.

## Configuração e limites

A URL e a chave **pública** podem continuar as mesmas da v3.1. **Nunca** colocar `sb_secret_` no Android ou GitHub. Nenhuma alteração SQL é necessária. A sessão do Streamlit continua precisando estar aberta para publicar o roteiro automático fictício.

O APK **não foi compilado neste pacote localmente**: testes de regras passaram, mas o build Android completo precisa ser confirmado pelo GitHub Actions. Não utilizar para operar na B3.
