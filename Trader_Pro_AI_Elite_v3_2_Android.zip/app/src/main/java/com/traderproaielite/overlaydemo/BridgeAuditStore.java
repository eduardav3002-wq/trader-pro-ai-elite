package com.traderproaielite.overlaydemo;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.Instant;

/** Private, local, bounded DEMO audit: never records URL, keys, PIN or quotes. */
public final class BridgeAuditStore {
    private BridgeAuditStore() {}
    private static final String PREF = "bridge_v32_audit";
    private static final int MAX_EVENTS = 50;

    public static void setHealth(Context context, BridgeReliability.LinkState state,
                                 long rttMs, long ageMs) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("health", state.name())
                .putLong("checked_wall_ms", System.currentTimeMillis())
                .putLong("rtt_ms", rttMs)
                .putLong("age_ms", ageMs)
                .apply();
    }

    public static String diagnostic(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String health = p.getString("health", "DESATIVADO");
        long checked = p.getLong("checked_wall_ms", -1);
        long rtt = p.getLong("rtt_ms", -1);
        long age = p.getLong("age_ms", -1);
        StringBuilder out = new StringBuilder("Ponte DEMO: ").append(health);
        if (checked > 0) out.append("\nÚltima verificação: ").append(Instant.ofEpochMilli(checked));
        if (rtt >= 0) out.append("\nConsulta HTTP: ").append(rtt).append(" ms");
        if (age >= 0) out.append("\nIdade estimada do evento: ").append(age).append(" ms");
        out.append("\nConsulta HTTP ≠ latência de entrega. Idade depende do relógio do celular.");
        return out.toString();
    }

    public static void append(Context context, String outcome, DemoSignal signal, String eventId,
                              long issuedWallMs, long receivedWallMs, long ageMs, long rttMs) {
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        JSONArray previous;
        try { previous = new JSONArray(p.getString("items", "[]")); }
        catch (Exception ignored) { previous = new JSONArray(); }
        JSONObject row = new JSONObject();
        try {
            row.put("resultado", outcome);
            row.put("estado", signal.name());
            // Event id is only a short correlation prefix; no credentials are logged.
            row.put("evento", eventId == null ? "—" : eventId.substring(0, Math.min(8, eventId.length())));
            row.put("emitido_utc", issuedWallMs > 0 ? Instant.ofEpochMilli(issuedWallMs).toString() : "—");
            row.put("recebido_utc", Instant.ofEpochMilli(receivedWallMs).toString());
            row.put("idade_estimada_ms", ageMs);
            row.put("http_rtt_ms", rttMs);
            JSONArray updated = new JSONArray();
            int start = Math.max(0, previous.length() - (MAX_EVENTS - 1));
            for (int i=start; i<previous.length(); i++) updated.put(previous.get(i));
            updated.put(row);
            p.edit().putString("items", updated.toString()).apply();
        } catch (Exception ignored) { /* Audit must never interrupt fail-closed overlay. */ }
    }

    public static String recent(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray list = new JSONArray(p.getString("items", "[]"));
            if (list.length() == 0) return "Nenhum evento recebido nesta instalação.";
            StringBuilder out = new StringBuilder();
            int min = Math.max(0,list.length()-20);
            for (int i=list.length()-1;i>=min;i--) {
                JSONObject e = list.getJSONObject(i);
                out.append(e.optString("recebido_utc", "—"))
                   .append(" | ").append(e.optString("resultado", "—"))
                   .append(" | ").append(e.optString("estado", "—"))
                   .append(" | id ").append(e.optString("evento", "—"))
                   .append("\nEmitido: ").append(e.optString("emitido_utc", "—"))
                   .append(" | idade estimada: ").append(e.optLong("idade_estimada_ms", -1)).append("ms")
                   .append(" | HTTP: ").append(e.optLong("http_rtt_ms", -1)).append("ms\n\n");
            }
            return out.toString();
        } catch (Exception ignored) { return "Histórico local indisponível."; }
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("items").apply();
    }
}
