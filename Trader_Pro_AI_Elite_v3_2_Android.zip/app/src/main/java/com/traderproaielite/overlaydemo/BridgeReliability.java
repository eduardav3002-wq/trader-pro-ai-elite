package com.traderproaielite.overlaydemo;

/** Pure, deterministic safety rules for the DEMO transport (no orders or market feed). */
public final class BridgeReliability {
    private BridgeReliability() {}

    // New events older than 12 seconds are not surfaced as actionable-looking popups.
    public static final long MAX_NEW_EVENT_AGE_MS = 12_000L;
    // Streamlit's demo publisher targets one event every 20 seconds. After 28 seconds,
    // a previously received event is no longer considered a healthy ongoing feed.
    public static final long MAX_CURRENT_EVENT_AGE_MS = 28_000L;
    public static final long FUTURE_CLOCK_TOLERANCE_MS = 5_000L;

    public enum LinkState { CONECTANDO, CONECTADO, ATRASADO, INDISPONIVEL, DESATIVADO }

    public static long ageMs(long issuedAtWallMs, long receivedAtWallMs) {
        if (issuedAtWallMs <= 0 || receivedAtWallMs <= 0) return Long.MAX_VALUE;
        return Math.max(0L, receivedAtWallMs - issuedAtWallMs);
    }

    public static boolean isPromptEvent(long issuedAtWallMs, long receivedAtWallMs) {
        if (issuedAtWallMs <= 0 || receivedAtWallMs <= 0
                || issuedAtWallMs - receivedAtWallMs > FUTURE_CLOCK_TOLERANCE_MS) return false;
        return ageMs(issuedAtWallMs, receivedAtWallMs) <= MAX_NEW_EVENT_AGE_MS;
    }

    public static LinkState classifyGoodResponse(long issuedAtWallMs, long receivedAtWallMs) {
        return ageMs(issuedAtWallMs, receivedAtWallMs) <= MAX_CURRENT_EVENT_AGE_MS
                ? LinkState.CONECTADO : LinkState.ATRASADO;
    }

    public static boolean isDuplicate(String previousId, String incomingId) {
        return incomingId != null && incomingId.equals(previousId);
    }

    /** RTT: HTTP request elapsed time; this is NOT event delivery latency. */
    public static long roundTripMs(long startElapsedMs, long endElapsedMs) {
        return Math.max(0L, endElapsedMs - startElapsedMs);
    }
}
