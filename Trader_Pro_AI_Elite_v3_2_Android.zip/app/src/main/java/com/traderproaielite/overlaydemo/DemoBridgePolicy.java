package com.traderproaielite.overlaydemo;

/** Pure policy for the untrusted, PUBLIC, read-only demo channel. */
public final class DemoBridgePolicy {
    private DemoBridgePolicy() {}
    public static final String CHANNEL = "trader-demo-v31";
    public static final long MAX_LIFETIME_MS = 60_000L;
    public static final long FUTURE_TOLERANCE_MS = 5_000L;

    public static boolean accepts(String channel, String eventId, String status,
                                  String mode, String contract, long issuedAtMs,
                                  long expiresAtMs, long nowWallMs) {
        if (!CHANNEL.equals(channel) || eventId == null || !eventId.matches("[A-Za-z0-9-]{4,80}")) return false;
        if (!"DEMONSTRACAO".equals(mode) || !"WINZ26".equals(contract)) return false;
        if (status == null || !(status.equals("COMPRA") || status.equals("VENDA")
                || status.equals("AGUARDAR") || status.equals("NAO_OPERAR"))) return false;
        if (issuedAtMs <= 0 || expiresAtMs <= issuedAtMs) return false;
        long lifetime = expiresAtMs - issuedAtMs;
        if (lifetime > MAX_LIFETIME_MS) return false;
        if (issuedAtMs - nowWallMs > FUTURE_TOLERANCE_MS) return false;
        return expiresAtMs > nowWallMs;
    }

    public static boolean validProjectUrl(String raw) {
        return raw != null && raw.trim().matches("https://[a-zA-Z0-9-]{8,64}\\.supabase\\.co/?");
    }

    public static boolean validPublishableKey(String raw) {
        return raw != null && raw.trim().matches("sb_publishable_[a-zA-Z0-9_-]{16,}");
    }
}
