package com.traderproaielite.overlaydemo;

/** User-selected overlay behavior; default is the safer, unobtrusive timed mode. */
public enum OverlayDisplayMode {
    TEMPORIZADO,
    FIXO;

    public static final String PREFERENCES = "smart_overlay_preferences_v30";
    public static final String PREF_KEY = "display_mode";

    public static OverlayDisplayMode fromSetting(String value) {
        if (FIXO.name().equals(value)) return FIXO;
        return TEMPORIZADO;
    }
}
