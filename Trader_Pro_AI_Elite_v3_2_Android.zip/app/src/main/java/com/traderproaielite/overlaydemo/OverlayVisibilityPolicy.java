package com.traderproaielite.overlaydemo;

/**
 * Pure, deterministic policy for the DEMO overlay. Time arguments use monotonic
 * elapsed milliseconds, not wall clock time. A duplicate never starts a new popup.
 */
public final class OverlayVisibilityPolicy {
    public static final long POPUP_MS = 5_000L;
    private OverlayVisibilityPolicy() {}

    /**
     * First manual activation is shown once. Afterwards only material changes:
     * COMPRA/VENDA, a new risk block, or withdrawal of an active buy/sell signal.
     */
    public static boolean shouldPopup(DemoSignal previous, DemoSignal next, boolean firstActivation) {
        if (firstActivation) return true;
        if (previous == null || next == null || previous == next) return false;
        if (next == DemoSignal.AGUARDAR) {
            return previous == DemoSignal.COMPRA || previous == DemoSignal.VENDA;
        }
        return next == DemoSignal.COMPRA || next == DemoSignal.VENDA
                || next == DemoSignal.NAO_OPERAR;
    }

    /** Backward-compatible timed behavior, kept for the v2.9 tests. */
    public static boolean shouldHide(long shownAtElapsedMs, long nowElapsedMs) {
        return shouldHide(shownAtElapsedMs, nowElapsedMs, OverlayDisplayMode.TEMPORIZADO);
    }

    /** The fixed panel never disappears automatically, but a demo signal still expires at 60s. */
    public static boolean shouldHide(long shownAtElapsedMs, long nowElapsedMs, OverlayDisplayMode mode) {
        if (mode == OverlayDisplayMode.FIXO) return false;
        if (shownAtElapsedMs < 0) return false;
        // Clock anomalies fail closed: do not leave a popup visible indefinitely.
        if (nowElapsedMs < shownAtElapsedMs) return true;
        return nowElapsedMs - shownAtElapsedMs >= POPUP_MS;
    }
}
