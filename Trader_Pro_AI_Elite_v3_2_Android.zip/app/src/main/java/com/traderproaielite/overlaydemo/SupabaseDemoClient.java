package com.traderproaielite.overlaydemo;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.time.Instant;
import javax.net.ssl.HttpsURLConnection;

/** HTTPS read-only poller for the fixed, publicly readable DEMO channel. */
public final class SupabaseDemoClient {
    private SupabaseDemoClient() {}

    public static final class Event {
        public final String eventId;
        public final DemoSignal state;
        public final long issuedAtMs;
        public final long expiresAtMs;
        public Event(String eventId, DemoSignal state, long issuedAtMs, long expiresAtMs) {
            this.eventId=eventId; this.state=state;
            this.issuedAtMs=issuedAtMs; this.expiresAtMs=expiresAtMs;
        }
    }

    public static Event fetch(String urlInput, String key) throws Exception {
        if (!DemoBridgePolicy.validProjectUrl(urlInput)
                || !DemoBridgePolicy.validPublishableKey(key)) {
            throw new IllegalArgumentException("Configuração pública da ponte inválida.");
        }
        String root = urlInput.trim().replaceAll("/$", "");
        URL url = new URL(root + "/rest/v1/trader_demo_alert_v31"
                + "?select=channel_id,event_id,status,issued_at,expires_at,mode,contract"
                + "&channel_id=eq.trader-demo-v31&limit=1");
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(4000);
        connection.setReadTimeout(4000);
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("apikey", key);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Cache-Control", "no-cache,no-store");
        try {
            if (connection.getResponseCode() != 200) throw new IllegalStateException("Canal DEMO indisponível.");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (InputStream input = connection.getInputStream()) {
                byte[] buf = new byte[1024];
                int size, total=0;
                while ((size=input.read(buf)) != -1) {
                    total+=size;
                    if (total>8192) throw new IllegalStateException("Resposta muito grande.");
                    bytes.write(buf,0,size);
                }
            }
            JSONArray array = new JSONArray(bytes.toString("UTF-8"));
            if (array.length()!=1) throw new IllegalStateException("Canal sem registro único.");
            JSONObject row = array.getJSONObject(0);
            String channel = row.getString("channel_id");
            String eventId = row.getString("event_id");
            String state = row.getString("status");
            String mode = row.getString("mode");
            String contract = row.getString("contract");
            long issued=Instant.parse(row.getString("issued_at")).toEpochMilli();
            long expires=Instant.parse(row.getString("expires_at")).toEpochMilli();
            long now=System.currentTimeMillis();
            if (!DemoBridgePolicy.accepts(channel,eventId,state,mode,contract,issued,expires,now)) {
                throw new IllegalStateException("Alerta DEMO inválido ou vencido.");
            }
            return new Event(eventId,DemoSignal.fromUntrustedString(state),issued,expires);
        } finally {
            connection.disconnect();
        }
    }
}
