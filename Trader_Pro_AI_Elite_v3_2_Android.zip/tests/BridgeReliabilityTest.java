import com.traderproaielite.overlaydemo.BridgeReliability;

public class BridgeReliabilityTest {
    static int count;
    static void ok(boolean b,String label){count++; if(!b)throw new AssertionError(label);}
    public static void main(String[] args) {
        long now=1800000000000L;
        ok(BridgeReliability.isPromptEvent(now-5000,now),"5 sec prompt");
        ok(BridgeReliability.isPromptEvent(now-12000,now),"12 sec allowed");
        ok(!BridgeReliability.isPromptEvent(now-12001,now),"late new blocked");
        ok(!BridgeReliability.isPromptEvent(now+6000,now),"future refused");
        ok(BridgeReliability.isPromptEvent(now+4000,now),"small clock tolerance");
        ok(!BridgeReliability.isPromptEvent(0,now),"bad issue date");
        ok(!BridgeReliability.isPromptEvent(now,0),"bad receive date");
        ok(BridgeReliability.classifyGoodResponse(now-20000,now)==BridgeReliability.LinkState.CONECTADO,"20s current healthy");
        ok(BridgeReliability.classifyGoodResponse(now-28000,now)==BridgeReliability.LinkState.CONECTADO,"28s current healthy");
        ok(BridgeReliability.classifyGoodResponse(now-28001,now)==BridgeReliability.LinkState.ATRASADO,"29s current stale");
        ok(BridgeReliability.isDuplicate("abc","abc"),"dedupe");
        ok(!BridgeReliability.isDuplicate("abc","bcd"),"change");
        ok(!BridgeReliability.isDuplicate("abc",null),"null event");
        ok(BridgeReliability.roundTripMs(1000,1450)==450,"RTT duration");
        ok(BridgeReliability.roundTripMs(1500,1000)==0,"negative monotonic guard");
        ok(BridgeReliability.ageMs(now+1000,now)==0,"clock skew reported zero");
        System.out.println(count+" verificações OK · confiabilidade v3.2");
    }
}
