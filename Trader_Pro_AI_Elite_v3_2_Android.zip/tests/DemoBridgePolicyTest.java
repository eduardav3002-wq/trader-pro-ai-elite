import com.traderproaielite.overlaydemo.DemoBridgePolicy;

public class DemoBridgePolicyTest {
    static int count;
    static void check(boolean x,String why){count++;if(!x)throw new AssertionError(why);}
    public static void main(String[] a){
        long n=1_800_000_000_000L, i=n-2000, e=n+43_000;
        for(String status:new String[]{"COMPRA","VENDA","AGUARDAR","NAO_OPERAR"})
            check(DemoBridgePolicy.accepts("trader-demo-v31","ab12-3423",status,"DEMONSTRACAO","WINZ26",i,e,n),"demo state " + status);
        check(!DemoBridgePolicy.accepts("other","ab12-3423","COMPRA","DEMONSTRACAO","WINZ26",i,e,n),"wrong channel");
        check(!DemoBridgePolicy.accepts("trader-demo-v31","bad","COMPRA","DEMONSTRACAO","WINZ26",i,e,n),"bad id");
        check(!DemoBridgePolicy.accepts("trader-demo-v31","ab12-3423","COMPRA","FEED_AUTORIZADO","WINZ26",i,e,n),"not real feed");
        check(!DemoBridgePolicy.accepts("trader-demo-v31","ab12-3423","COMPRA","DEMONSTRACAO","WINX26",i,e,n),"ticker changed");
        check(!DemoBridgePolicy.accepts("trader-demo-v31","ab12-3423","UNKNOWN","DEMONSTRACAO","WINZ26",i,e,n),"bad state");
        check(!DemoBridgePolicy.accepts("trader-demo-v31","ab12-3423","COMPRA","DEMONSTRACAO","WINZ26",i,n,n),"expired");
        check(!DemoBridgePolicy.accepts("trader-demo-v31","ab12-3423","COMPRA","DEMONSTRACAO","WINZ26",n+6000,n+30000,n),"future");
        check(!DemoBridgePolicy.accepts("trader-demo-v31","ab12-3423","COMPRA","DEMONSTRACAO","WINZ26",n-100000,n+30000,n),"ttl too long");
        check(DemoBridgePolicy.validProjectUrl("https://abcdef123.supabase.co"),"valid host");
        check(!DemoBridgePolicy.validProjectUrl("https://abcdef123.supabase.co.evil.com"),"fake domain");
        check(!DemoBridgePolicy.validProjectUrl("http://abcdef123.supabase.co"),"https enforced");
        check(!DemoBridgePolicy.validProjectUrl("https://abcdef123.supabase.co/bad"),"no path");
        check(DemoBridgePolicy.validPublishableKey("sb_publishable_abcdefghijklmnopqrstuvwxyz"),"public key");
        check(!DemoBridgePolicy.validPublishableKey("sb_secret_abcdefghijklmnopqrstuvwxyz"),"secret forbidden android");
        System.out.println(count+" verificacoes OK · bridge demo security");
    }
}
