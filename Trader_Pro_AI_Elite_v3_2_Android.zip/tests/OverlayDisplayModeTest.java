import com.traderproaielite.overlaydemo.DemoSignal;
import com.traderproaielite.overlaydemo.DemoPolicy;
import com.traderproaielite.overlaydemo.OverlayDisplayMode;
import com.traderproaielite.overlaydemo.OverlayVisibilityPolicy;

/** JVM checks for user-selectable overlay: 5s popup versus persistent fixed panel. */
public class OverlayDisplayModeTest {
    private static int assertions;
    private static void check(boolean ok, String message) {
        assertions++;
        if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        check(OverlayDisplayMode.fromSetting(null) == OverlayDisplayMode.TEMPORIZADO, "default timed");
        check(OverlayDisplayMode.fromSetting("INVALID") == OverlayDisplayMode.TEMPORIZADO, "invalid setting safe default");
        check(OverlayDisplayMode.fromSetting("FIXO") == OverlayDisplayMode.FIXO, "fixed selection");
        check(OverlayDisplayMode.fromSetting("TEMPORIZADO") == OverlayDisplayMode.TEMPORIZADO, "timed selection");
        for (OverlayDisplayMode mode : OverlayDisplayMode.values()) {
            check(OverlayDisplayMode.fromSetting(mode.name()) == mode, "mode round-trip " + mode);
        }
        check(!OverlayVisibilityPolicy.shouldHide(100, 5099, OverlayDisplayMode.TEMPORIZADO), "timed before boundary");
        check(OverlayVisibilityPolicy.shouldHide(100, 5100, OverlayDisplayMode.TEMPORIZADO), "timed at 5s");
        check(OverlayVisibilityPolicy.shouldHide(100, 5200, OverlayDisplayMode.TEMPORIZADO), "timed after 5s");
        check(!OverlayVisibilityPolicy.shouldHide(100, 100_000, OverlayDisplayMode.FIXO), "fixed never auto hides");
        check(!OverlayVisibilityPolicy.shouldHide(-1, 100_000, OverlayDisplayMode.FIXO), "fixed no timestamp");
        check(!OverlayVisibilityPolicy.shouldHide(100, 99, OverlayDisplayMode.FIXO), "fixed not tied to popup clock");
        check(DemoPolicy.effective(DemoSignal.COMPRA, 100, 60_099) == DemoSignal.COMPRA, "TTL still active");
        check(DemoPolicy.effective(DemoSignal.COMPRA, 100, 60_100) == DemoSignal.NAO_OPERAR, "TTL expires in fixed too");
        check(DemoPolicy.effective(DemoSignal.VENDA, 100, 60_100) == DemoSignal.NAO_OPERAR, "sell also expires");
        check(!OverlayVisibilityPolicy.shouldPopup(DemoSignal.COMPRA, DemoSignal.COMPRA, false), "duplicate suppressed");
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.COMPRA, DemoSignal.NAO_OPERAR, false), "risk change");
        System.out.println(assertions + " verificacoes OK · modos temporizado/fixo, TTL e seguranca (DEMO)");
    }
}
