import com.traderproaielite.overlaydemo.OverlayVisibilityPolicy;
import com.traderproaielite.overlaydemo.DemoSignal;

/** Pure JVM checks; no Android SDK needed. */
public class OverlayVisibilityPolicyTest {
    private static int assertions;
    private static void check(boolean actual, boolean expected, String label) {
        assertions++;
        if (actual != expected) throw new AssertionError(label + ": expected " + expected + ", got " + actual);
    }
    public static void main(String[] args) {
        // Initial activation always shows a safety status once.
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.NAO_OPERAR, DemoSignal.NAO_OPERAR, true),true,"first activation");
        check(OverlayVisibilityPolicy.shouldHide(100L, 5099L), false,"before 5 sec");
        check(OverlayVisibilityPolicy.shouldHide(100L, 5100L), true,"at 5 sec");
        check(OverlayVisibilityPolicy.shouldHide(100L, 6000L), true,"after 5 sec");
        check(OverlayVisibilityPolicy.shouldHide(-1L, 6000L), false,"already hidden");
        check(OverlayVisibilityPolicy.shouldHide(100L, 99L), true,"clock reversal fail closed");
        // Repeated states should not create spam or restart the timer.
        for (DemoSignal s : DemoSignal.values()) {
            check(OverlayVisibilityPolicy.shouldPopup(s,s,false),false,"duplicate " + s);
        }
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.NAO_OPERAR,DemoSignal.COMPRA,false),true,"buy");
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.COMPRA,DemoSignal.VENDA,false),true,"reversal");
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.VENDA,DemoSignal.NAO_OPERAR,false),true,"risk block");
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.COMPRA,DemoSignal.AGUARDAR,false),true,"buy revoked");
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.VENDA,DemoSignal.AGUARDAR,false),true,"sell revoked");
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.NAO_OPERAR,DemoSignal.AGUARDAR,false),false,"routine awaiting");
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.AGUARDAR,DemoSignal.COMPRA,false),true,"wait to buy");
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.AGUARDAR,DemoSignal.NAO_OPERAR,false),true,"wait to block");
        check(OverlayVisibilityPolicy.shouldPopup(null,DemoSignal.COMPRA,false),false,"invalid old state");
        check(OverlayVisibilityPolicy.shouldPopup(DemoSignal.COMPRA,null,false),false,"invalid next state");
        System.out.println(assertions+" verificacoes OK · visibilidade de 5s e mudancas importantes (DEMO)");
    }
}
