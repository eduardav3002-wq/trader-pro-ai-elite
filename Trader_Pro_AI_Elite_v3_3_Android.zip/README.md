# Trader Pro AI Elite · Smart Overlay Android v3.3 (DEMONSTRAÇÃO)

Protótipo Android complementar à ponte Streamlit + Supabase já usada nas versões 3.1/3.2. Não é um sistema para decisões financeiras reais, não lê cotações da bolsa, não prevê movimentos e não envia ordens.

## O que mudou em relação à v3.2

1. **Falhas classificadas:** `SEM_REDE_LOCAL`, `DNS_INDISPONIVEL`, `TIMEOUT`, `TLS_FALHOU`, `HTTP_NAO_AUTORIZADO`, `HTTP_LIMITE_REQUISICOES`, `HTTP_SERVIDOR`, `HTTP_OUTRO`, `SEM_REGISTRO`, `EVENTO_VENCIDO`, `RESPOSTA_INVALIDA`, `CONFIGURACAO_INVALIDA`, `FALHA_DE_REDE` e `SEM_NOVA_PUBLICACAO`.
2. **Tentativas graduais de recuperação:** a leitura normal continua em torno de 5 segundos; após falhas, nova tentativa em 5, 8, 15 ou 30 segundos, com limite máximo de 30 segundos. Não garante tempo de entrega, especialmente se o Android limitar o serviço em segundo plano.
3. **Proteção de retomada:** guarda **somente** o último identificador e horário de emissão de evento público, nunca a chave privada; uma mensagem repetida ou anterior não reabre COMPRA/VENDA quando o app é reiniciado.
4. **Sem nova publicação:** se o mesmo evento ficar velho (mais de 28 segundos) mas o Supabase responder, o diagnóstico passa para `SEM_NOVA_PUBLICACAO` e `NÃO OPERAR`.
5. **Histórico auditável:** até 50 eventos no dispositivo, com resumo e compartilhamento do CSV em texto; preserva os registros locais v3.2 quando uma atualização mantém os dados do app.
6. **Modos mantidos:** temporizado por ~5 segundos ou fixo, com alerta de demonstração vencendo após até 60 segundos.

## Instalação pelo GitHub usando apenas o celular

1. Envie `Trader_Pro_AI_Elite_v3_3_Android.zip` para a **raiz** da branch `main` do repositório, sem extrair nem renomear.
2. Crie `.github/workflows/android_overlay_v33.yml` e cole o conteúdo do arquivo YAML fornecido separadamente.
3. Faça os commits e abra **Actions → Gerar APK Android v3.3 DEMO**. Só prossiga se a execução estiver verde.
4. Em **Artifacts**, baixe `Trader-Pro-AI-Elite-Android-v3.3-DEMO`, extraia o `app-debug.apk` e instale.
5. Se a assinatura de debug mudar, talvez seja necessário desinstalar apenas o app DEMO anterior. Isso pode apagar as configurações locais e o histórico; exporte os registros antes e tenha a URL e a chave **pública** do Supabase para configurar novamente.

A tabela `public.trader_demo_alert_v31` e os Secrets do Streamlit **não precisam ser alterados**. Não cole a chave `sb_secret_` no Android ou GitHub.

## Teste em 3 partes

**1. Fluxo normal:** mantenha o roteiro fictício no Streamlit e a ponte Android ligados. Confira identificadores novos em COMPRA, AGUARDAR, VENDA e NÃO OPERAR.

**2. Falha de rede:** ative o modo avião por alguns segundos. Deve aparecer `NÃO OPERAR`, com motivo como `SEM_REDE_LOCAL`, `DNS_INDISPONIVEL` ou `TIMEOUT`, dependendo do estado da conexão. Ao retornar a rede, não deve reaparecer um evento velho; a próxima mudança válida será aceita.

**3. Publicação interrompida:** deixe a conexão Android funcionando, mas pare o roteiro Streamlit. Após o prazo sem novos eventos, deve aparecer `SEM_NOVA_PUBLICACAO` ou `EVENTO_VENCIDO` (dependendo do momento da leitura). Reinicie o roteiro e confira recuperação com identificador novo.

Exporte o histórico pelo botão **Compartilhar CSV do histórico DEMO**. Nenhuma senha, URL completa, PIN ou chave é incluída nesse histórico; verifique qualquer outro conteúdo antes de compartilhar.

## Limitações explícitas

- `http_rtt_ms` mede apenas a consulta HTTP. A idade do alerta depende de relógios sincronizados e **não** é latência de entrega certificada.
- O serviço em primeiro plano pode sofrer limitações do Android, da bateria ou da rede. Não há garantia de notificações de tempo crítico.
- `SEM_REDE_LOCAL` só aparece quando o Android consegue detectar ausência de rede ativa; uma rede Wi-Fi sem internet pode produzir `TIMEOUT`, `DNS_INDISPONIVEL` ou outro erro.
- Um estado `NÃO OPERAR` nunca equivale a fechamento de uma posição real; o protótipo não controla a corretora.
- Testes Java de políticas são locais. A compilação integral do APK e sua execução em um aparelho precisam ser verificadas no GitHub Actions e no celular.
