import com.traderproaielite.overlaydemo.BridgeRecoveryPolicy;

public class BridgeRecoveryPolicyTest {
    static int n=0;
    static void yes(boolean b,String why){n++;if(!b)throw new AssertionError(why);}
    static final long NOW=1_800_000_000_000L;
    public static void main(String[] args){
        yes(BridgeRecoveryPolicy.nextPollDelayMs(0)==5000L,"normal poll");
        yes(BridgeRecoveryPolicy.nextPollDelayMs(1)==5000L,"first error");
        yes(BridgeRecoveryPolicy.nextPollDelayMs(2)==8000L,"second error");
        yes(BridgeRecoveryPolicy.nextPollDelayMs(3)==15000L,"third error");
        yes(BridgeRecoveryPolicy.nextPollDelayMs(4)==30000L,"fourth error");
        yes(BridgeRecoveryPolicy.nextPollDelayMs(90)==30000L,"bounded retry");
        yes(BridgeRecoveryPolicy.classify("",-1,"abc12345",NOW-2500,NOW)==BridgeRecoveryPolicy.Delivery.NOVO_VALIDO,"first fresh");
        yes(BridgeRecoveryPolicy.classify("abc12345",NOW-2500,"abc12345",NOW-2500,NOW)==BridgeRecoveryPolicy.Delivery.REPETIDO,"same id blocked");
        yes(BridgeRecoveryPolicy.classify("abc12345",NOW-2500,"older",NOW-3000,NOW)==BridgeRecoveryPolicy.Delivery.ANTERIOR_OU_REPLAY,"older timestamp blocked");
        yes(BridgeRecoveryPolicy.classify("abc12345",NOW-2500,"different",NOW-2500,NOW)==BridgeRecoveryPolicy.Delivery.ANTERIOR_OU_REPLAY,"same second blocked");
        yes(BridgeRecoveryPolicy.classify("abc12345",NOW-2500,"bcd45678",NOW-12500,NOW)==BridgeRecoveryPolicy.Delivery.ANTERIOR_OU_REPLAY,"time rewind blocked");
        yes(BridgeRecoveryPolicy.classify("abc12345",NOW-18000,"new67890",NOW-13000,NOW)==BridgeRecoveryPolicy.Delivery.NOVO_ATRASADO,"late recovery blocked");
        yes(BridgeRecoveryPolicy.classify("abc12345",NOW-18000,"new67890",NOW-3000,NOW)==BridgeRecoveryPolicy.Delivery.NOVO_VALIDO,"new fresh after downtime allowed");
        yes(BridgeRecoveryPolicy.classify("",-1,null,NOW-3000,NOW)==BridgeRecoveryPolicy.Delivery.NOVO_ATRASADO,"missing id rejected");
        yes(BridgeRecoveryPolicy.classify("",-1,"newid",NOW+6000,NOW)==BridgeRecoveryPolicy.Delivery.NOVO_ATRASADO,"future event rejected");
        yes(BridgeRecoveryPolicy.classify("",-1,"newid",NOW+4000,NOW)==BridgeRecoveryPolicy.Delivery.NOVO_VALIDO,"clock tolerance");
        yes(BridgeRecoveryPolicy.classify("old-id",NOW-9000,"newid",NOW-2000,NOW)==BridgeRecoveryPolicy.Delivery.NOVO_VALIDO,"new id after restart");
        System.out.println(n+" verificacoes OK · recuperacao v3.3");
    }
}
