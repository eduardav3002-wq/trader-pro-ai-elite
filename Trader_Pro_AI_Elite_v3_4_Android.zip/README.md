# Trader Pro AI Elite · Smart Overlay Android v3.4 (DEMONSTRAÇÃO)

Atualização incremental da v3.3 aprovada no teste de desconexão. Não usa cotações reais, não prevê movimentos e não envia ordens. Não use os estados fictícios para tomar decisões financeiras.

## Mudanças
- Callback da rede padrão do Android: invalida o estado em perda/troca de rede, solicita consulta imediata na volta e descarta resposta iniciada na rede anterior. Se o callback falhar, resta a consulta periódica. Uma requisição em andamento pode atrasar a retomada.
- Mesmo evento não recupera a ponte após falha ou reinício; exige novo ID, emissão posterior, validade e idade de até 12 s. Consultas normais ~5 s; falhas com espera progressiva de 5/8/15/30 s.
- Prazo de validade na ponte: menor entre expiração informada pelo servidor e 28 s desde emissão estimada, limitado por relógio monotônico local após recebimento. Modo manual mantém 60 s. Sem mensagem nova, NÃO OPERAR.
- Diagnóstico visual colorido, idade estimada e HTTP RTT. Heartbeat em memória ~5 s e desatualizado a partir de 15 s; se o processo reiniciar não exibe saúde persistida como atual. Mostra economia de bateria ativa/desativada, sem solicitar exceções de bateria.
- Histórico local até 150 eventos (CSV com mesmo formato). Configuração, cursor e histórico anteriores são preservados se a instalação mantiver dados.

## Instalação pelo celular
1. Envie Trader_Pro_AI_Elite_v3_4_Android.zip à raiz da branch main, sem extrair.
2. Crie .github/workflows/android_overlay_v34.yml com o conteúdo do YAML separado.
3. Actions → Gerar APK Android v3.4 DEMO. Só prossiga após Success.
4. Artifacts → Trader-Pro-AI-Elite-Android-v3.4-DEMO. Extraia e instale app-debug.apk.
5. Se houver conflito de assinatura, exporte o histórico e guarde a URL/chave pública antes de desinstalar o APK anterior, pois os dados locais podem ser apagados. Não altere Streamlit, Supabase ou Secrets. Nunca use sb_secret_ no Android/GitHub.

## Teste de aceitação
- Ative modo FIXO e roteiro automático fictício do Streamlit. Ligue alertas DEMO; aguarde evento novo válido. Abra outro app e confira o painel e o contador.
- Desligue Wi-Fi e dados móveis. Confirme NÃO OPERAR; religue e confirme que a recuperação exige evento novo (log RECUPERADA_COM_EVENTO_NOVO). Repita com troca Wi-Fi/dados móveis.
- Pare roteiro sem desligar rede. Confira NÃO OPERAR no limite da validade e diagnóstico SEM_NOVA_PUBLICACAO ou EVENTO_VENCIDO. Reinicie roteiro e verifique novo ID.
- Com tela desligada por ~2 min, retorne ao aparelho. Não deve confiar em evento vencido. Confira diagnóstico e histórico. Teste também com economia de bateria ligada. Não há garantia de entrega com aparelho suspenso.
- Exporte o CSV e anote se a janela permanece fixa, se bloqueia após falhas e se o contador respeita a validade. Não compartilhe chaves.

## Validação e limites
155 verificações Java locais (8 classes), incluindo 16 novas; testes não executam callbacks Android, rede real, APK nem sistema operacional. Compilação Gradle e teste em aparelho ainda pendentes. O heartbeat indica execução recente, não serviço ininterrupto. Android pode suspender ou matar o processo; não há wake lock, reinício oculto ou garantia de latência. HTTP RTT não é latência total; idade é estimativa sujeita a relógios diferentes. O serviço não reinicia sozinho após ser encerrado. Sem sinal operacional, feed oficial ou conexão à corretora.
