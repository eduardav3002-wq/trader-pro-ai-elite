# Trader Pro AI Elite · Smart Reliability Engine Android v3.7 (DEMO)

Primeira etapa da v3.7, baseada no ZIP v3.4. Sem cotações reais, previsões, ordens ou recomendações operacionais. Não use estados fictícios para decisões financeiras.

## Alterações
- Evento vencido ou ausência de publicação: espera programada de 2 s entre consultas após resposta, em vez de backoff de até 30 s. Respostas repetidas/rejeitadas durante recuperação também usam 2 s. A validade do evento não aumenta.
- Falhas reais de transporte mantêm 5/8/15/30 s de espera. HTTP 429, 401/403 e configuração inválida: 30 s. A contagem é reiniciada na transição entre falha de publicação e transporte. O callback de rede existente pode antecipar consulta.
- Cadência normal continua 5 s após conclusão, sem consultas paralelas no mesmo ciclo. RTT, suspensão Android e tempo de processamento podem aumentar o intervalo real.
- CSV separado das últimas 600 tentativas concluídas durante a sessão ativa, inclusive falhas repetidas e respostas repetidas; registra hora UTC, classificação, motivo, prefixo do ID quando disponível, RTT e próxima espera programada. Respostas descartadas por mudança de rede têm espera -1; respostas de sessão encerrada não são registradas. Sem chaves nem URLs. Histórico anterior de até 150 eventos preservado; limpar histórico apaga ambos.
- Mantidos requisitos de novo ID, emissão posterior, idade máxima de 12 s para nova mensagem, limite de validade de 28 s ou expiração remota, bloqueio de repetição/replay e saída NÃO OPERAR. Mantida ponte HTTPS somente leitura, sem novas permissões.
- Ainda NÃO há sequência no servidor, recuperação de eventos intermediários, confirmação de recebimento ou leitura do histórico privado Supabase. A próxima etapa requer desenho de interface de auditoria com acesso restrito. O cliente continua lendo o último evento.

## Instalação
1. Exporte histórico da v3.4 e guarde suas configurações públicas privadamente antes da atualização.
2. Envie Trader_Pro_AI_Elite_v3_7_Android.zip à raiz da branch main, sem extrair. Preserve ZIP e workflow v3.4.
3. Crie .github/workflows/android_overlay_v37.yml usando YAML separado. Actions → Gerar APK Android v3.7 DEMO → Run workflow se necessário.
4. Só após Success, baixe Artifacts → Trader-Pro-AI-Elite-Android-v3.7-DEMO e extraia app-debug.apk. Mesmo applicationId, versionCode 37. O APK debug pode ter assinatura diferente. Se houver conflito, não desinstale sem exportar histórico e guardar configuração pública; desinstalação pode apagar dados. Nunca compartilhe chaves privadas.
5. Não altere Supabase nem Streamlit nesta etapa.

## Aceitação
- Repetir teste integrado de 3 minutos da v3.6, com Streamlit fechado, janela fixa e rede ligada. Exportar CSV de eventos e CSV de tentativas; comparar IDs com arquivo de servidor. Medir tempo entre primeira publicação após pausa e primeiro novo evento recebido, e verificar saída NÃO OPERAR no vencimento.
- Repetir teste de desconexão real, mudança Wi-Fi/dados, tela bloqueada e economia de bateria; verificar recuperação somente com mensagem nova válida.
- Testar 15 minutos com publicação de 10 s, comparar histórico do servidor e Android, verificar limites e consumo. Não confundir sucesso técnico com assertividade financeira.

## Validação local
184 verificações em 8 classes Java puras, incluindo 29 novas verificações de recuperação e limites. Executado com Java 21 local; workflow usa Java 17. SDK Android/Gradle indisponíveis neste ambiente: APK, integração Android, rede, armazenamento e comportamento real ainda não testados. Diagnóstico de 2 s pode aumentar tráfego/bateria quando o publicador permanece desligado; desligue ponte DEMO quando não estiver testando. Nenhuma garantia de entrega ou funcionamento com o aparelho suspenso.
