# Trader Pro AI Elite · Android Smart Recovery v3.8 (DEMO)

Base: ZIP v3.7 fornecido. Preserva a janela flutuante, ponte v3.1, validade, bloqueio de replay, tentativas, histórico e permissões anteriores. Não contém feed real, integração com corretoras ou execução de ordens. Todos os estados são simulação.

## Recuperação histórica
- GET HTTPS /rest/v1/rpc/trader_recuperar_v38 com p_apos e p_limite=100, usando somente a chave publishable existente. Sem escrita remota ou novas permissões.
- Trabalhador separado do fluxo ao vivo. Consulta a cada 10 s após resposta, 2 s se página cheia e 30 s após falha. Retoma quando a rede volta; Android pode suspender a execução.
- Página inteira validada: sequência estritamente crescente acima do cursor, sem IDs repetidos na página, contrato WINZ26, estado conhecido, validade coerente e somente_auditoria=true. Eventos vencidos são válidos apenas como registros históricos. Não há chamada ao método de exibição do painel a partir do fluxo histórico.
- Cursor e CSV persistidos juntos, por projeto Supabase, preservados após fechar/reabrir e ao limpar histórico de sinais. Retenção local das últimas 1000 linhas; exporte antes de exceder esse limite. IDs completos no CSV histórico; registros ao vivo permanecem no CSV antigo de prefixos. A recuperação é de todos os eventos históricos após o cursor, inclusive os recebidos ao vivo; não é uma lista exclusiva de eventos perdidos.
- Falha histórica tem diagnóstico próprio; não invalida por si só um evento ao vivo que passou nas regras da v3.7. Falha na ponte ao vivo continua em NÃO OPERAR. Histórico não renova nem reabre alerta, nem altera o cursor ao vivo.
- Não garante entrega: sequência pode ter lacunas ou inserções fora da ordem de commit, servidor pode ter dados ausentes, retenção local é limitada, e o cursor não detecta reinicialização da sequência no mesmo projeto. Verificar unicidade de event_id no servidor e estabilidade da sequência antes de homologar. Se a sequência for reinicializada, não reutilize o cursor sem migração explícita. Não aumentar exposição de dados privados para permitir RPC.

## Instalação e teste
1. Antes de instalar, exporte os históricos v3.7 e guarde as configurações públicas privadamente. Verifique que o RPC permite somente acesso ao histórico fictício autorizado com papel anon; SQL Editor administrativo não comprova acesso via API. Nunca use secret ou service_role no Android.
2. Envie o ZIP v3.8 à raiz main, sem extrair. Preserve os ZIPs e workflows anteriores. Crie .github/workflows/android_overlay_v38.yml com o YAML separado. Actions > Gerar APK Android v3.8 DEMO > Run workflow (se necessário).
3. Somente após Success, baixe Artifacts > Trader-Pro-AI-Elite-Android-v3.8-DEMO, extraia app-debug.apk. Mesmo applicationId, versionCode 38. Assinaturas debug podem divergir entre builds. Se houver conflito, não desinstale antes de exportar e guardar a configuração; dados locais podem ser perdidos.
4. Ative ponte DEMO. Confira diagnóstico Histórico v3.8, sequência e CSV de recuperação. Com os 3 eventos de teste, espere sequência 3 e três linhas se não houver publicação nova. Reabra, confira ausência de novas linhas repetidas.
5. Execute publicação exclusivamente DEMO, janela fixa, Streamlit fechado; desligue a rede por 30 s, religue, compare CSV histórico e histórico do servidor; confira que registros antigos não reabrem a janela e que o estado seguro aparece ao perder validade da ponte. Teste reinício, paginação com >100 registros, rede alterada e 15 min de resistência. Não confunda recuperação histórica com recebimento de alertas em tempo real.

## Validação local
Testes Java puros executados com --release 17. Não houve SDK Android/Gradle local: APK, persistência em dispositivo, API real, permissões e comportamento do Android ainda dependem de compilação e testes. A versão é candidata DEMO, não homologada para uso financeiro.
