package com.traderproaielite.overlaydemo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.text.InputType;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private final android.os.Handler diagnosticsHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable liveDiagnostics = new Runnable() {
        @Override public void run() {
            if (bridgeHealthStatus != null) bridgeHealthStatus.setText(BridgeAuditStore.diagnostic(MainActivity.this));
            diagnosticsHandler.postDelayed(this, 2000L);
        }
    };
    private TextView permissionStatus;
    private TextView modeStatus;
    private TextView bridgeHealthStatus;
    private TextView bridgeHistory;
    private EditText projectField;
    private EditText publicKeyField;
    private static final int REQUEST_NOTIFICATIONS = 28;
    private final int ink = Color.rgb(235, 241, 255);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9, 14, 29));
        getWindow().setNavigationBarColor(Color.rgb(9, 14, 29));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(9, 14, 29));
        LinearLayout base = new LinearLayout(this);
        base.setOrientation(LinearLayout.VERTICAL);
        base.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(base);

        TextView logo = text("◈ TRADER PRO AI ELITE", 25, ink, true);
        base.addView(logo);
        base.addView(text("ANDROID · SMART OVERLAY v3.8", 14, 0xFFB1A6FF, true));
        addSpace(base, 20);
        TextView warn = text("DEMONSTRAÇÃO · SEM COTAÇÕES AO VIVO · NÃO USAR PARA OPERAR", 16, 0xFFFFC76B, true);
        warn.setPadding(dp(15), dp(15), dp(15), dp(15));
        warn.setBackground(card(0xFF2A2530, 0xFFFFC76B));
        base.addView(warn);
        addSpace(base, 18);
        base.addView(text("Permissão necessária", 19, ink, true));
        permissionStatus = text("Verificando a permissão...", 14, 0xFFB9C7D9, false);
        base.addView(permissionStatus);
        base.addView(button("1 · Autorizar janela sobre outros apps", () -> {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            try { startActivity(permission); }
            catch (Exception e) { Toast.makeText(this, "Abra as permissões de sobreposição nas Configurações.", Toast.LENGTH_LONG).show(); }
        }));
        addSpace(base, 14);
        base.addView(text("Modo de exibição · escolha o seu", 19, ink, true));
        modeStatus = text("", 14, 0xFFB9C7D9, false);
        base.addView(modeStatus);
        base.addView(button("⏱ Temporizado · aparece por 5 segundos", () -> chooseMode(OverlayDisplayMode.TEMPORIZADO)));
        base.addView(button("▣ Fixo · permanece na tela", () -> chooseMode(OverlayDisplayMode.FIXO)));
        updateModeStatus();
        base.addView(button("2 · Ativar painel (NÃO OPERAR)", () -> showState(DemoSignal.NAO_OPERAR)));
        addSpace(base, 20);
        base.addView(text("📡 Ponte com Streamlit · DEMONSTRAÇÃO", 19, ink, true));
        base.addView(text("O Streamlit envia estados FICTÍCIOS para um canal Supabase. "
                + "O Android consulta alterações enquanto você deixa este painel ativo. "
                + "Sem feed oficial, sem ordens e sem sinal utilizável para operar.",
                13, 0xFFBBC7D9, false));
        projectField = new EditText(this);
        projectField.setSingleLine(true);
        projectField.setTextColor(ink);
        projectField.setHintTextColor(0xFF8695AF);
        projectField.setTextSize(13);
        projectField.setHint("https://seuprojeto.supabase.co");
        projectField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        projectField.setText(getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("url",""));
        base.addView(projectField);
        publicKeyField = new EditText(this);
        publicKeyField.setSingleLine(true);
        publicKeyField.setTextColor(ink);
        publicKeyField.setHintTextColor(0xFF8695AF);
        publicKeyField.setTextSize(13);
        publicKeyField.setHint("sb_publishable_... (CHAVE PÚBLICA, nunca secret)");
        publicKeyField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        publicKeyField.setText(getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("publishable",""));
        base.addView(publicKeyField);
        base.addView(button("Salvar endereço e chave pública", () -> saveBridgeSettings()));
        base.addView(button("3 · Iniciar alertas DEMO automáticos", () -> startBridge()));
        base.addView(text("ATENÇÃO: NÃO cole chaves sb_secret_ no Android. "
                + "Sem conexão, a saída segura será NÃO OPERAR. "
                + "Consulta DEMO: ~5s normal, ~2s após evento vencido; entrega não garantida.",
                12, 0xFFFFCB83, false));
        addSpace(base, 16);
        base.addView(text("🛡️ Diagnóstico e recuperação · v3.8", 19, ink, true));
        bridgeHealthStatus = text("", 13, 0xFFB9C7D9, false);
        base.addView(bridgeHealthStatus);
        base.addView(text("Monitor local: mostra atividade recente do serviço, não garante funcionamento contínuo. Economia de bateria pode atrasar a ponte.",12,0xFFB9C7D9,false));
        base.addView(text("📋 Últimos recebimentos DEMO (máximo 150 registros locais)", 16, ink, true));
        bridgeHistory = text("", 11, 0xFFBCCCE0, false);
        base.addView(bridgeHistory);
        base.addView(button("↻ Atualizar diagnóstico e histórico", () -> updateBridgeDiagnostics()));
        base.addView(button("Compartilhar histórico DEMO (texto)", () -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_SUBJECT, "Trader Pro AI Elite · Auditoria DEMO v3.8");
            share.putExtra(Intent.EXTRA_TEXT, BridgeAuditStore.recent(this));
            startActivity(Intent.createChooser(share, "Compartilhar auditoria DEMO"));
        }));
        base.addView(button("Compartilhar CSV do histórico DEMO", () -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/csv");
            share.putExtra(Intent.EXTRA_SUBJECT, "Auditoria Smart Bridge DEMO v3.8.csv");
            share.putExtra(Intent.EXTRA_TEXT, BridgeAuditStore.exportCsv(this));
            startActivity(Intent.createChooser(share, "Compartilhar CSV de diagnóstico"));
        }));
        base.addView(button("Compartilhar CSV de tentativas v3.8", () -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/csv");
            share.putExtra(Intent.EXTRA_SUBJECT, "Tentativas Smart Bridge DEMO v3.8.csv");
            share.putExtra(Intent.EXTRA_TEXT, BridgeAuditStore.exportAttempts(this));
            startActivity(Intent.createChooser(share, "Compartilhar tentativas DEMO"));
        }));
        base.addView(button("Compartilhar CSV de recuperação v3.8 (auditoria)", () -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/csv");
            share.putExtra(Intent.EXTRA_SUBJECT, "Recuperacao_DEMO_v38.csv");
            share.putExtra(Intent.EXTRA_TEXT, HistoryRecoveryStore.exportCsv(this, savedProjectUrl()));
            startActivity(Intent.createChooser(share, "Compartilhar recuperação histórica"));
        }));
        base.addView(text("Histórico recuperado não gera alertas. O cursor e CSV v3.8 são preservados ao limpar o histórico de sinais.",12,0xFFFFCA8A,false));
        base.addView(button("Limpar histórico local de sinais", () -> {
            BridgeAuditStore.clear(this);
            updateBridgeDiagnostics();
            Toast.makeText(this,"Histórico local limpo.",Toast.LENGTH_SHORT).show();
        }));
        base.addView(text("A idade do evento é estimada pelo relógio do celular. Falhas são identificadas por tipo e recuperadas apenas com novos eventos válidos. "
                + "O tempo HTTP mede apenas a consulta, não o atraso total de entrega. "
                + "Avisos iniciais acima de 12s e eventos sem renovação acima de 28s vão para NÃO OPERAR.",
                12, 0xFFFFCA8A, false));
        updateBridgeDiagnostics();
        addSpace(base, 16);
        base.addView(text("Estados de teste (toque para alterar o painel)", 18, ink, true));
        base.addView(button("COMPRA · somente simulação", () -> showState(DemoSignal.COMPRA)));
        base.addView(button("VENDA · somente simulação", () -> showState(DemoSignal.VENDA)));
        base.addView(button("AGUARDAR · somente simulação", () -> showState(DemoSignal.AGUARDAR)));
        base.addView(button("NÃO OPERAR · estado seguro", () -> showState(DemoSignal.NAO_OPERAR)));
        addSpace(base, 14);
        base.addView(button("Desligar janela flutuante", () -> {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Painel encerrado.", Toast.LENGTH_SHORT).show();
        }));
        addSpace(base, 20);
        base.addView(text("Como testar", 19, ink, true));
        base.addView(text("Escolha TEMPORIZADO ou FIXO antes de ativar. TEMPORIZADO: o aviso aparece por aproximadamente 5 segundos, some inteiramente e só reaparece em mudanças importantes. FIXO: o cartão permanece sobre outros aplicativos até você minimizar (bolha) ou desligar (×); uma mudança atualiza o texto sem forçar a expansão da bolha. No modo manual, o estado simulado expira em 60 segundos. Na ponte, vale o menor prazo entre a expiração remota e 28 segundos desde a emissão estimada. Ambos voltam a NÃO OPERAR. Avisos repetidos não reiniciam o prazo. A seleção fica salva neste aparelho.", 15, 0xFFC2CEE1, false));
        addSpace(base, 14);
        base.addView(text("Com a ponte configurada, este aplicativo consulta APENAS um roteiro fictício publicado pelo Streamlit. O modo manual continua disponível. Sem conexão com corretora, sem dados reais e sem envio de ordens. A ponte depende de um projeto Supabase configurado separadamente.", 13, 0xFF8D9AB3, false));
        setContentView(scroll);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        diagnosticsHandler.removeCallbacks(liveDiagnostics);
        diagnosticsHandler.post(liveDiagnostics);
        updateModeStatus();
        updateBridgeDiagnostics();
        permissionStatus.setText(Settings.canDrawOverlays(this)
                ? "✓ Sobreposição autorizada. O painel pode aparecer em outros aplicativos."
                : "✕ Sobreposição ainda não autorizada. Habilite antes de ativar.");
    }

    @Override protected void onPause() {
        diagnosticsHandler.removeCallbacks(liveDiagnostics);
        super.onPause();
    }

    private String savedProjectUrl() { return getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("url", ""); }

    private void updateBridgeDiagnostics() {
        if (bridgeHealthStatus != null)
            bridgeHealthStatus.setText(BridgeAuditStore.diagnostic(this)+HistoryRecoveryStore.diagnostic(this,savedProjectUrl()));
        if (bridgeHistory != null)
            bridgeHistory.setText(BridgeAuditStore.recent(this));
    }

    private void chooseMode(OverlayDisplayMode mode) {
        getSharedPreferences(OverlayDisplayMode.PREFERENCES, MODE_PRIVATE).edit()
                .putString(OverlayDisplayMode.PREF_KEY, mode.name()).apply();
        updateModeStatus();
        Toast.makeText(this, mode == OverlayDisplayMode.FIXO
                ? "Modo FIXO selecionado · minimize ou feche quando quiser"
                : "Modo TEMPORIZADO selecionado · 5 segundos", Toast.LENGTH_SHORT).show();
        // Se o serviço já estiver ativo, ele observa a preferência e troca de modo
        // no próximo ciclo sem exigir nova permissão ou reinício.
    }

    private void updateModeStatus() {
        if (modeStatus == null) return;
        OverlayDisplayMode mode = OverlayDisplayMode.fromSetting(getSharedPreferences(
                OverlayDisplayMode.PREFERENCES, MODE_PRIVATE).getString(OverlayDisplayMode.PREF_KEY, null));
        modeStatus.setText(mode == OverlayDisplayMode.FIXO
                ? "✓ SELECIONADO: FIXO · só fecha ao minimizar ou desligar"
                : "✓ SELECIONADO: TEMPORIZADO · 5 segundos");
    }

    private void showState(DemoSignal state) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Primeiro autorize a janela flutuante.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, OverlayService.class);
        intent.setAction(OverlayService.ACTION_SHOW);
        intent.putExtra(OverlayService.EXTRA_SIGNAL, state.name());
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
            Toast.makeText(this, "DEMO: " + (OverlayDisplayMode.fromSetting(getSharedPreferences(
                    OverlayDisplayMode.PREFERENCES, MODE_PRIVATE).getString(OverlayDisplayMode.PREF_KEY, null))
                    == OverlayDisplayMode.FIXO ? "janela fixa" : "janela por 5s"), Toast.LENGTH_SHORT).show();
        } catch (RuntimeException e) {
            Toast.makeText(this, "Não foi possível ativar. Confira as permissões do Android.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean saveBridgeSettings() {
        String url = projectField.getText().toString().trim();
        String key = publicKeyField.getText().toString().trim();
        if (!DemoBridgePolicy.validProjectUrl(url) || !DemoBridgePolicy.validPublishableKey(key)) {
            Toast.makeText(this,"Endereço ou chave PUBLISHABLE inválidos. NUNCA use secret aqui.",Toast.LENGTH_LONG).show();
            return false;
        }
        // Changing the public project must not inherit the last event cursor of another project.
        String previousUrl = getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("url", "");
        if (!url.equals(previousUrl)) BridgeAuditStore.clearCursor(this);
        getSharedPreferences("bridge_v31",MODE_PRIVATE).edit()
                .putString("url",url).putString("publishable",key).apply();
        Toast.makeText(this,"Configuração pública salva neste celular.",Toast.LENGTH_SHORT).show();
        return true;
    }

    private void startBridge() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this,"Primeiro autorize a sobreposição.",Toast.LENGTH_LONG).show();
            return;
        }
        if (!saveBridgeSettings()) return;
        Intent intent = new Intent(this, OverlayService.class);
        intent.setAction(OverlayService.ACTION_START_BRIDGE);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
            Toast.makeText(this,"Ponte DEMO ativa. Sem dados = NÃO OPERAR.",Toast.LENGTH_LONG).show();
            updateBridgeDiagnostics();
        } catch (RuntimeException ex) {
            Toast.makeText(this,"Android não conseguiu ativar o monitoramento.",Toast.LENGTH_LONG).show();
        }
    }

    private Button button(String label, Runnable action) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(label);
        button.setTextSize(14);
        button.setTextColor(ink);
        button.setBackground(card(0xFF202A43, 0xFF424F75));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(10);
        button.setLayoutParams(lp);
        button.setOnClickListener(v -> action.run());
        return button;
    }
    private TextView text(String text, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(sp);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setLineSpacing(dp(4), 1f);
        return v;
    }
    private GradientDrawable card(int bg, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(bg); d.setCornerRadius(dp(16)); d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float px) { return (int) (px * getResources().getDisplayMetrics().density + .5f); }
    private void addSpace(LinearLayout l, int dp) { View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1, dp(dp))); }
}
