package com.traderproaielite.overlaydemo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** History is audit-only. It cannot produce a live DemoSignal or refresh a popup. */
public final class HistoryRecoveryPolicy {
    private HistoryRecoveryPolicy() {}
    public static final int PAGE = 100;
    public static final int RETAIN = 1000;
    public static final long NORMAL_MS = 10_000L, MORE_MS = 2_000L, FAILURE_MS = 30_000L;
    public static final class Row {
        public final long sequence, issued, expires;
        public final String id, contract, state;
        public final boolean auditOnly;
        public Row(long sequence, String id, String contract, String state, long issued, long expires, boolean auditOnly) {
            this.sequence=sequence; this.id=id; this.contract=contract; this.state=state;
            this.issued=issued; this.expires=expires; this.auditOnly=auditOnly;
        }
    }
    public static boolean validPage(long cursor, List<Row> rows) {
        if (cursor<0 || rows==null || rows.size()>PAGE) return false;
        long previous=cursor; Set<String> ids=new HashSet<>();
        for(Row r: rows) {
            if (r==null || r.sequence<=previous || !r.auditOnly || !"WINZ26".equals(r.contract)
                    || r.id==null || !r.id.matches("[A-Za-z0-9-]{4,80}") || !ids.add(r.id)
                    || !("COMPRA".equals(r.state)||"VENDA".equals(r.state)||"AGUARDAR".equals(r.state)||"NAO_OPERAR".equals(r.state))
                    || r.issued<=0 || r.expires<=r.issued || r.expires-r.issued>DemoBridgePolicy.MAX_LIFETIME_MS) return false;
            previous=r.sequence;
        }
        return true;
    }
    /** IDs already retained locally must not reappear at a newer sequence. */
    public static boolean distinctFromRetained(String csv, List<Row> rows) {
        if (csv==null || rows==null) return false;
        Set<String> ids=new HashSet<>();
        for(String line:csv.split("\n")) {
            if(line.isEmpty()) continue;
            String[] fields=line.split(",",-1);
            if(fields.length!=8 || !ids.add(fields[1])) return false;
        }
        for(Row row:rows) if(row==null || !ids.add(row.id)) return false;
        return true;
    }
    public static long sequenceGaps(long cursor,List<Row> rows) {
        if(!validPage(cursor,rows)) throw new IllegalArgumentException("invalid audit page");
        long gaps=0, previous=cursor;
        for(Row row:rows) { gaps+=row.sequence-previous-1; previous=row.sequence; }
        return gaps;
    }
    public static long nextCursor(long cursor,List<Row> rows) {
        if(!validPage(cursor,rows)) throw new IllegalArgumentException("invalid audit page");
        return rows.isEmpty()?cursor:rows.get(rows.size()-1).sequence;
    }
    public static long nextDelay(boolean success,int count) {
        return !success?FAILURE_MS:count==PAGE?MORE_MS:NORMAL_MS;
    }
}
