package com.traderproaielite.overlaydemo;

import android.content.Context;
import android.content.SharedPreferences;
import java.time.Instant;
import java.util.List;
import java.util.Locale;

/** Independent per-project audit cursor. Cursor and bounded CSV are committed together. */
public final class HistoryRecoveryStore {
    private HistoryRecoveryStore() {}
    private static final String HEADER="sequencia,event_id,contrato,estado_historico,emitido_utc,expira_utc,recuperado_utc,somente_auditoria\n";
    private static SharedPreferences prefs(Context c,String url) {
        String host=DemoBridgePolicy.validProjectUrl(url)?url.trim().toLowerCase(Locale.ROOT).replace("https://","").replace("/",""):"sem_projeto";
        return c.getSharedPreferences("history_v38_"+host,Context.MODE_PRIVATE);
    }
    public static long cursor(Context c,String url) { return prefs(c,url).getLong("cursor",0L); }
    public static synchronized boolean append(Context c,String url,long expected,List<HistoryRecoveryPolicy.Row> rows) {
        SharedPreferences p=prefs(c,url);
        if(p.getLong("cursor",0L)!=expected||!HistoryRecoveryPolicy.validPage(expected,rows)) return false;
        if(rows.isEmpty()) return true;
        String retained=p.getString("csv","");
        if(!HistoryRecoveryPolicy.distinctFromRetained(retained,rows)) return false;
        String[] previous=retained.split("\n");
        StringBuilder out=new StringBuilder();
        for(int i=Math.max(0,previous.length-(HistoryRecoveryPolicy.RETAIN-rows.size()));i<previous.length;i++)
            if(!previous[i].isEmpty()) out.append(previous[i]).append('\n');
        String received=Instant.now().toString();
        for(HistoryRecoveryPolicy.Row row:rows) out.append(row.sequence).append(',').append(row.id).append(',')
            .append(row.contract).append(',').append(row.state).append(',').append(Instant.ofEpochMilli(row.issued)).append(',')
            .append(Instant.ofEpochMilli(row.expires)).append(',').append(received).append(",true\n");
        return p.edit().putString("csv",out.toString()).putLong("cursor",HistoryRecoveryPolicy.nextCursor(expected,rows))
            .putLong("total",p.getLong("total",0L)+rows.size())
            .putLong("pages_v39",p.getLong("pages_v39",0L)+1)
            .putLong("gaps_v39",p.getLong("gaps_v39",0L)+HistoryRecoveryPolicy.sequenceGaps(expected,rows))
            .putString("last_append_v39",received).commit();
    }
    public static void status(Context c,String url,String status) {
        SharedPreferences p=prefs(c,url);
        p.edit().putString("status",status).putString("checked",Instant.now().toString())
            .putLong("checks_v39",p.getLong("checks_v39",0L)+1)
            .putLong("failures_v39",p.getLong("failures_v39",0L)+(status.startsWith("FALHA_")?1:0)).apply();
    }
    public static String diagnostic(Context c,String url) {
        SharedPreferences p=prefs(c,url);
        return "\n\nHistórico v3.9 (somente auditoria): "+p.getString("status","NÃO CONSULTADO")
            +"\nÚltima sequência: "+p.getLong("cursor",0L)+" · linhas incorporadas: "+p.getLong("total",0L)
            +"\nDesde v3.9: consultas "+p.getLong("checks_v39",0L)+" · páginas gravadas "+p.getLong("pages_v39",0L)
            +" · falhas "+p.getLong("failures_v39",0L)+" · saltos de sequência "+p.getLong("gaps_v39",0L)
            +"\nÚltima gravação v3.9: "+p.getString("last_append_v39","—")
            +"\nÚltima consulta histórica: "+p.getString("checked","—")+"\nCSV: últimas 1000 linhas. Não representa alertas ao vivo.";
    }
    public static String exportCsv(Context c,String url) { return HEADER+prefs(c,url).getString("csv",""); }
}
