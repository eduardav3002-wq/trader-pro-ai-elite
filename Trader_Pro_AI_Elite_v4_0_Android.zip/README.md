# Trader Pro AI Elite · Android v4.0 — recuperação de histórico DEMO

Correção baseada no ZIP v3.9 original. Sem alterações no Supabase, sem novas permissões Android, mesmo applicationId, versionCode 40, mesmas preferências de sessão e ponte, mesmo RPC `trader_recuperar_v38`. Não há integração com corretora, mercado real ou envio de ordens.

## Alterações
- Preserva as preferências históricas `history_v38_*` como origem e não as apaga. Na primeira página nova validada, grava um snapshot conjunto de cursor, CSV e contadores em AtomicFile por projeto. Confere a leitura após gravação. Se não houver snapshot, lê o legado; falha na leitura de snapshot existente não reinicia o cursor. Últimas 1000 linhas, como antes.
- Separa falhas de cursor divergente, página inválida, cache inválido, ID duplicado, leitura, gravação atômica, verificação da gravação e falha interna. Falhas HTTP continuam separadas. Nenhuma chave, resposta bruta ou URL completa é exibida. O código não descarta registros para forçar a sincronização.
- Valida o CSV legado, a sequência final e o isolamento de auditoria antes de avançar. Lacunas de sequência são contabilizadas, mas não provam perda nem são reparadas automaticamente. Não há detecção automática de reset de sequência no servidor. A recuperação não emite alertas.
- A causa original do erro no aparelho permanece indeterminada. Esta versão substitui o mecanismo de gravação e melhora o diagnóstico; a correção efetiva deve ser comprovada no dispositivo. Não retorna ao APK antigo após nova gravação sem reconciliar o histórico, pois a v3.9 não lê o snapshot v4.0.

## Instalação pelo GitHub (não desinstale a v3.9)
1. Exporte os CSVs de recuperação e de tentativas da v3.9 antes da atualização. Guarde a configuração pública do Supabase em privado.
2. Envie `Trader_Pro_AI_Elite_v4_0_Android.zip` sem extrair à raiz do repositório. Crie `.github/workflows/android_overlay_v40.yml` com o conteúdo do YAML fornecido separadamente. Preserve o projeto anterior.
3. Execute Actions > Gerar APK Android v4.0 DEMO. Após Success, baixe Artifacts > Trader-Pro-AI-Elite-Android-v4.0-DEMO e extraia app-debug.apk.
4. Instale por cima da v3.9. Se houver conflito de assinatura, pare: não desinstale nem limpe os dados. Assinaturas debug de builds em runners diferentes podem divergir. O CSV exportado não restaura automaticamente preferências.
5. Confira o diagnóstico e a sequência antiga. Inicie a publicação DEMO no servidor e os alertas pelo botão 3 no Android; aguarde 30 segundos e atualize o diagnóstico. Compare com o servidor; a sequência deve alcançar pelo menos 81 se os dados de teste permanecerem. Exporte CSV e compare IDs, não apenas contagem. Se houver falha, envie print do novo código específico. Não use a demo em negociações reais.

## Validação
11 classes de teste Java puro, 253 verificações aprovadas. O novo teste usa 76 registros sintéticos e os cinco registros pendentes do SQL real, além de duplicatas, cache inválido, cursor divergente, lacunas e limite de retenção. Não reproduz o armazenamento real do celular nem prova correção da causa original. O APK não foi compilado neste ambiente (sem Android SDK/Gradle); o workflow compila e testa no GitHub. Ainda falta testar atualização preservando dados, recuperação, retomada e resistência no aparelho. Feed real, calendário, testes fora da amostra e homologação financeira são etapas separadas.
