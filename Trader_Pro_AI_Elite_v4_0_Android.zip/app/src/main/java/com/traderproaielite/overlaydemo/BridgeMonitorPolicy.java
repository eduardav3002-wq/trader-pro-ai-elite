package com.traderproaielite.overlaydemo;

/** Pure monitor rules; local elapsed time controls expiry even if wall time changes. */
public final class BridgeMonitorPolicy {
    private BridgeMonitorPolicy() {}
    public static final long HEARTBEAT_MS = 5_000L;
    public static final long HEARTBEAT_STALE_MS = 15_000L;
    public static long validityMs(long issued, long expires, long receivedWall) {
        if (issued <= 0 || expires <= receivedWall || !BridgeReliability.isPromptEvent(issued, receivedWall)) return 0;
        return Math.max(0L, Math.min(expires - receivedWall,
                BridgeReliability.MAX_CURRENT_EVENT_AGE_MS - BridgeReliability.ageMs(issued, receivedWall)));
    }
    public static boolean keepRepeated(boolean awaitingRecovery, long validUntil, long now) {
        return !awaitingRecovery && validUntil > now;
    }
    public static boolean heartbeatFresh(long last, long now) {
        return last >= 0 && now >= last && now-last < HEARTBEAT_STALE_MS;
    }
    public static long secondsRemaining(long deadline, long now) {
        return deadline <= now ? 0 : (deadline-now+999L)/1000L;
    }
}
