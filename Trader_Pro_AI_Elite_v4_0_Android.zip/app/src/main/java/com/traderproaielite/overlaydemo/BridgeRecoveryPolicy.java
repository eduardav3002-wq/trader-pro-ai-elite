package com.traderproaielite.overlaydemo;

/** Stateless decisions shared by foreground polling and JVM tests. */
public final class BridgeRecoveryPolicy {
    private BridgeRecoveryPolicy() {}
    public static final long POLL_NORMAL_MS = 5_000L;
    public static final long POLL_STALE_MS = 2_000L;
    private static final long[] BACKOFF = {5_000L, 8_000L, 15_000L, 30_000L};

    public enum Delivery { NOVO_VALIDO, REPETIDO, ANTERIOR_OU_REPLAY, NOVO_ATRASADO }

    /** Consecutive failed requests only; reset to zero when HTTPS returns valid fresh content. */
    public static long nextPollDelayMs(int failureCount) {
        if (failureCount <= 0) return POLL_NORMAL_MS;
        return BACKOFF[Math.min(failureCount - 1, BACKOFF.length - 1)];
    }

    /** A stale publication is not a transport outage. Keep a bounded fast retry. */
    public static boolean publicationFailure(BridgeFailure reason) {
        return reason == BridgeFailure.EVENTO_VENCIDO || reason == BridgeFailure.SEM_NOVA_PUBLICACAO;
    }

    public static int nextFailureCount(int previous, BridgeFailure oldReason, BridgeFailure newReason) {
        return publicationFailure(oldReason) != publicationFailure(newReason)
                ? 1 : Math.min(1000, Math.max(0, previous) + 1);
    }

    public static long nextPollDelayMs(int failureCount, BridgeFailure reason) {
        if (publicationFailure(reason)) return POLL_STALE_MS;
        // Respect throttling and avoid hammering invalid credentials/configuration.
        if (reason == BridgeFailure.HTTP_LIMITE_REQUISICOES
                || reason == BridgeFailure.HTTP_NAO_AUTORIZADO
                || reason == BridgeFailure.CONFIGURACAO_INVALIDA) return 30_000L;
        return nextPollDelayMs(failureCount);
    }

    public static long responsePollDelayMs(boolean awaitingRecovery) {
        return awaitingRecovery ? POLL_STALE_MS : POLL_NORMAL_MS;
    }

    public static Delivery classify(String previousId, long previousIssuedAtMs,
                                    String incomingId, long incomingIssuedAtMs, long nowWallMs) {
        if (incomingId == null || incomingId.isEmpty() || incomingIssuedAtMs <= 0) return Delivery.NOVO_ATRASADO;
        if (incomingId.equals(previousId)) return Delivery.REPETIDO;
        // Never present an event issued earlier than an already-seen message, even after restart.
        if (previousIssuedAtMs > 0 && incomingIssuedAtMs <= previousIssuedAtMs)
            return Delivery.ANTERIOR_OU_REPLAY;
        if (!BridgeReliability.isPromptEvent(incomingIssuedAtMs, nowWallMs))
            return Delivery.NOVO_ATRASADO;
        return Delivery.NOVO_VALIDO;
    }
}
