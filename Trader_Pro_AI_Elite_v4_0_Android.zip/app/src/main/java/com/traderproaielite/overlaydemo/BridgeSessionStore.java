package com.traderproaielite.overlaydemo;

import android.content.Context;
import android.content.SharedPreferences;
import java.time.Instant;

/** Stores user intent, not a live signal. No boot receiver or trading execution. */
public final class BridgeSessionStore {
    private BridgeSessionStore() {}
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences("bridge_session_v39",Context.MODE_PRIVATE); }
    public static boolean wanted(Context c) { return prefs(c).getBoolean("wanted",false); }
    public static boolean setWanted(Context c,boolean active) { return prefs(c).edit().putBoolean("wanted",active).commit(); }
    public static void started(Context c,boolean resumed) {
        SharedPreferences p=prefs(c);
        p.edit().putLong("starts",p.getLong("starts",0)+1)
          .putLong("resumes",p.getLong("resumes",0)+(resumed?1:0))
          .putString("last_start",Instant.now().toString()).apply();
    }
    public static String diagnostic(Context c) {
        SharedPreferences p=prefs(c);
        return "\nSessão DEMO: "+(wanted(c)?"retomada habilitada ao abrir":"desativada")
            +"\nInícios: "+p.getLong("starts",0)+" · retomadas: "+p.getLong("resumes",0)
            +"\nÚltimo início: "+p.getString("last_start","—");
    }
}
