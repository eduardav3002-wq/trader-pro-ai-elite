package com.traderproaielite.overlaydemo;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** History is audit-only. It cannot produce a live DemoSignal or refresh a popup. */
public final class HistoryRecoveryPolicy {
    private HistoryRecoveryPolicy() {}
    public static final int PAGE = 100;
    public static final int RETAIN = 1000;
    public static final long NORMAL_MS = 10_000L, MORE_MS = 2_000L, FAILURE_MS = 30_000L;
    public static final class Row {
        public final long sequence, issued, expires;
        public final String id, contract, state;
        public final boolean auditOnly;
        public Row(long sequence, String id, String contract, String state, long issued, long expires, boolean auditOnly) {
            this.sequence=sequence; this.id=id; this.contract=contract; this.state=state;
            this.issued=issued; this.expires=expires; this.auditOnly=auditOnly;
        }
    }
    public static boolean validPage(long cursor, List<Row> rows) {
        if (cursor<0 || rows==null || rows.size()>PAGE) return false;
        long previous=cursor; Set<String> ids=new HashSet<>();
        for(Row r: rows) {
            if (r==null || r.sequence<=previous || !r.auditOnly || !"WINZ26".equals(r.contract)
                    || r.id==null || !r.id.matches("[A-Za-z0-9-]{4,80}") || !ids.add(r.id)
                    || !("COMPRA".equals(r.state)||"VENDA".equals(r.state)||"AGUARDAR".equals(r.state)||"NAO_OPERAR".equals(r.state))
                    || r.issued<=0 || r.expires<=r.issued || r.expires-r.issued>DemoBridgePolicy.MAX_LIFETIME_MS) return false;
            previous=r.sequence;
        }
        return true;
    }
    public enum AppendStatus {
        OK, CURSOR_DIVERGENTE, PAGINA_INVALIDA, CACHE_INVALIDO, ID_DUPLICADO
    }
    public static final class Plan {
        public final AppendStatus status;
        public final long cursor, gaps;
        public final String csv;
        private Plan(AppendStatus status,long cursor,long gaps,String csv) {
            this.status=status; this.cursor=cursor; this.gaps=gaps; this.csv=csv;
        }
    }
    /** Pure, non-destructive plan. No cursor movement on a failed validation. */
    public static Plan plan(long actual,long expected,String retained,List<Row> rows,String recovered) {
        if(actual!=expected) return new Plan(AppendStatus.CURSOR_DIVERGENTE,actual,0,retained);
        if(!validPage(expected,rows)) return new Plan(AppendStatus.PAGINA_INVALIDA,actual,0,retained);
        if(retained==null) return new Plan(AppendStatus.CACHE_INVALIDO,actual,0,retained);
        List<String> previous=new ArrayList<>(); Set<String> ids=new HashSet<>();
        long last=0;
        try {
            Instant.parse(recovered);
            for(String line:retained.split("\n")) {
                if(line.isEmpty()) continue;
                String[] f=line.split(",",-1);
                if(f.length!=8 || !"true".equals(f[7]) || !ids.add(f[1])) throw new IllegalArgumentException();
                long seq=Long.parseLong(f[0]);
                Row old=new Row(seq,f[1],f[2],f[3],Instant.parse(f[4]).toEpochMilli(),Instant.parse(f[5]).toEpochMilli(),true);
                Instant.parse(f[6]);
                if(!validPage(last,java.util.Collections.singletonList(old))) throw new IllegalArgumentException();
                last=seq; previous.add(line);
            }
            if(last!=actual || previous.size()>RETAIN) throw new IllegalArgumentException();
        } catch(RuntimeException e) { return new Plan(AppendStatus.CACHE_INVALIDO,actual,0,retained); }
        for(Row row:rows) if(!ids.add(row.id)) return new Plan(AppendStatus.ID_DUPLICADO,actual,0,retained);
        if(rows.isEmpty()) return new Plan(AppendStatus.OK,actual,0,retained);
        StringBuilder out=new StringBuilder();
        for(int i=Math.max(0,previous.size()-(RETAIN-rows.size()));i<previous.size();i++) out.append(previous.get(i)).append('\n');
        for(Row row:rows) out.append(row.sequence).append(',').append(row.id).append(',')
            .append(row.contract).append(',').append(row.state).append(',').append(Instant.ofEpochMilli(row.issued)).append(',')
            .append(Instant.ofEpochMilli(row.expires)).append(',').append(recovered).append(",true\n");
        return new Plan(AppendStatus.OK,nextCursor(actual,rows),sequenceGaps(actual,rows),out.toString());
    }
    /** IDs already retained locally must not reappear at a newer sequence. */
    public static boolean distinctFromRetained(String csv, List<Row> rows) {
        if (csv==null || rows==null) return false;
        Set<String> ids=new HashSet<>();
        for(String line:csv.split("\n")) {
            if(line.isEmpty()) continue;
            String[] fields=line.split(",",-1);
            if(fields.length!=8 || !ids.add(fields[1])) return false;
        }
        for(Row row:rows) if(row==null || !ids.add(row.id)) return false;
        return true;
    }
    public static long sequenceGaps(long cursor,List<Row> rows) {
        if(!validPage(cursor,rows)) throw new IllegalArgumentException("invalid audit page");
        long gaps=0, previous=cursor;
        for(Row row:rows) { gaps+=row.sequence-previous-1; previous=row.sequence; }
        return gaps;
    }
    public static long nextCursor(long cursor,List<Row> rows) {
        if(!validPage(cursor,rows)) throw new IllegalArgumentException("invalid audit page");
        return rows.isEmpty()?cursor:rows.get(rows.size()-1).sequence;
    }
    public static long nextDelay(boolean success,int count) {
        return !success?FAILURE_MS:count==PAGE?MORE_MS:NORMAL_MS;
    }
}
