package com.traderproaielite.overlaydemo;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.AtomicFile;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;
import java.util.Locale;

/** Audit-only storage. The legacy v3.8/v3.9 preferences are never erased. */
public final class HistoryRecoveryStore {
    private HistoryRecoveryStore() {}
    private static final String HEADER="sequencia,event_id,contrato,estado_historico,emitido_utc,expira_utc,recuperado_utc,somente_auditoria\n";
    private static String host(String url) {
        return DemoBridgePolicy.validProjectUrl(url)?url.trim().toLowerCase(Locale.ROOT).replace("https://","").replace("/",""):"sem_projeto";
    }
    private static SharedPreferences prefs(Context c,String url) {
        return c.getSharedPreferences("history_v38_"+host(url),Context.MODE_PRIVATE);
    }
    private static AtomicFile file(Context c,String url) {
        return new AtomicFile(new File(c.getFilesDir(),"history_v40_"+host(url)+".json"));
    }
    private static final class Snapshot {
        final long cursor,total,pages,gaps; final String csv,last;
        Snapshot(long cursor,long total,long pages,long gaps,String csv,String last) {
            this.cursor=cursor;this.total=total;this.pages=pages;this.gaps=gaps;this.csv=csv;this.last=last;
        }
        String encode() throws Exception {
            return new JSONObject().put("version",1).put("cursor",cursor).put("total",total).put("pages",pages)
                .put("gaps",gaps).put("csv",csv).put("last",last).toString();
        }
        static Snapshot decode(String data) throws Exception {
            JSONObject j=new JSONObject(data);
            if(j.getInt("version")!=1) throw new IllegalArgumentException();
            Snapshot s=new Snapshot(j.getLong("cursor"),j.getLong("total"),j.getLong("pages"),j.getLong("gaps"),j.getString("csv"),j.getString("last"));
            if(s.cursor<0||s.total<0||s.pages<0||s.gaps<0||s.csv.length()>300000) throw new IllegalArgumentException();
            return s;
        }
    }
    private static Snapshot legacy(Context c,String url) {
        SharedPreferences p=prefs(c,url);
        return new Snapshot(p.getLong("cursor",0L),p.getLong("total",0L),p.getLong("pages_v39",0L),p.getLong("gaps_v39",0L),p.getString("csv",""),p.getString("last_append_v39","—"));
    }
    private static Snapshot read(Context c,String url) throws Exception {
        AtomicFile f=file(c,url);
        try { return Snapshot.decode(new String(f.readFully(),StandardCharsets.UTF_8)); }
        catch(FileNotFoundException e) {
            File base=f.getBaseFile();
            if(base.exists()||new File(base.getPath()+".bak").exists()) throw e;
            return legacy(c,url);
        }
    }
    public static synchronized long cursor(Context c,String url) {
        try { return read(c,url).cursor; }
        catch(Exception e) { throw new IllegalStateException("FALHA_LEITURA_HISTORICO",e); }
    }
    public static synchronized String append(Context c,String url,long expected,List<HistoryRecoveryPolicy.Row> rows) {
        final Snapshot old;
        try { old=read(c,url); } catch(Exception e) { return "FALHA_LEITURA_HISTORICO"; }
        String received=Instant.now().toString();
        HistoryRecoveryPolicy.Plan plan=HistoryRecoveryPolicy.plan(old.cursor,expected,old.csv,rows,received);
        if(plan.status!=HistoryRecoveryPolicy.AppendStatus.OK) return "FALHA_"+plan.status.name();
        if(rows.isEmpty()) return "SEM NOVAS LINHAS";
        Snapshot next=new Snapshot(plan.cursor,old.total+rows.size(),old.pages+1,old.gaps+plan.gaps,plan.csv,received);
        AtomicFile f=file(c,url); FileOutputStream stream=null;
        String encoded;
        try {
            encoded=next.encode();
            stream=f.startWrite(); stream.write(encoded.getBytes(StandardCharsets.UTF_8));
            stream.getFD().sync(); f.finishWrite(stream); stream=null;
        } catch(Exception e) {
            if(stream!=null) f.failWrite(stream);
            return "FALHA_GRAVACAO_ATOMICA";
        }
        try {
            Snapshot verified=Snapshot.decode(new String(f.readFully(),StandardCharsets.UTF_8));
            if(!encoded.equals(verified.encode())) return "FALHA_VERIFICACAO_GRAVACAO";
        } catch(Exception e) { return "FALHA_VERIFICACAO_GRAVACAO"; }
        return "PÁGINA INCORPORADA ("+rows.size()+")";
    }
    public static synchronized void status(Context c,String url,String status) {
        SharedPreferences p=prefs(c,url);
        p.edit().putString("status",status).putString("checked",Instant.now().toString())
            .putLong("checks_v40",p.getLong("checks_v40",0L)+1)
            .putLong("failures_v40",p.getLong("failures_v40",0L)+(status.startsWith("FALHA_")?1:0)).apply();
    }
    public static synchronized String diagnostic(Context c,String url) {
        SharedPreferences p=prefs(c,url);
        String prefix="\n\nHistórico v4.0 (somente auditoria): "+p.getString("status","NÃO CONSULTADO")
            +"\nDesde v4.0: consultas "+p.getLong("checks_v40",0L)+" · falhas "+p.getLong("failures_v40",0L)
            +"\nÚltima consulta histórica: "+p.getString("checked","—");
        try {
            Snapshot s=read(c,url);
            return prefix+"\nÚltima sequência: "+s.cursor+" · linhas incorporadas: "+s.total
                +"\nPáginas gravadas desde v3.9: "+s.pages+" · saltos de sequência "+s.gaps
                +"\nÚltima gravação: "+s.last+"\nCSV: últimas 1000 linhas. Não representa alertas ao vivo.";
        } catch(Exception e) { return prefix+"\nFALHA_LEITURA_HISTORICO — cursor não reiniciado; preserve os dados."; }
    }
    public static synchronized String exportCsv(Context c,String url) {
        try { return HEADER+read(c,url).csv; }
        catch(Exception e) { throw new IllegalStateException("FALHA_LEITURA_HISTORICO",e); }
    }
}
