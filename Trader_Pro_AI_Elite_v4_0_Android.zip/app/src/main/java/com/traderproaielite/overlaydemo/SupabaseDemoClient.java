package com.traderproaielite.overlaydemo;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.time.Instant;
import javax.net.ssl.HttpsURLConnection;

/** HTTPS read-only DEMO transport with distinct, sanitized failure types. */
public final class SupabaseDemoClient {
    private SupabaseDemoClient() {}
    public static final class BridgeException extends Exception {
        public final BridgeFailure reason;
        BridgeException(BridgeFailure reason) { super(reason.name()); this.reason = reason; }
    }

    public static final class Event {
        public final String eventId;
        public final DemoSignal state;
        public final long issuedAtMs;
        public final long expiresAtMs;
        public Event(String eventId, DemoSignal state, long issuedAtMs, long expiresAtMs) {
            this.eventId = eventId; this.state = state;
            this.issuedAtMs = issuedAtMs; this.expiresAtMs = expiresAtMs;
        }
    }

    public static Event fetch(String urlInput, String key) throws BridgeException {
        if (!DemoBridgePolicy.validProjectUrl(urlInput)
                || !DemoBridgePolicy.validPublishableKey(key)) {
            throw new BridgeException(BridgeFailure.CONFIGURACAO_INVALIDA);
        }
        HttpsURLConnection connection = null;
        try {
            String root = urlInput.trim().replaceAll("/$", "");
            URL endpoint = new URL(root + "/rest/v1/trader_demo_alert_v31"
                    + "?select=channel_id,event_id,status,issued_at,expires_at,mode,contract"
                    + "&channel_id=eq.trader-demo-v31&limit=1");
            connection = (HttpsURLConnection) endpoint.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(4000);
            connection.setReadTimeout(4000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("apikey", key);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Cache-Control", "no-cache,no-store");
            int http = connection.getResponseCode();
            if (http != 200) throw new BridgeException(BridgeFailure.fromHttp(http));
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (InputStream input = connection.getInputStream()) {
                byte[] buf = new byte[1024];
                int size, total = 0;
                while ((size = input.read(buf)) != -1) {
                    total += size;
                    if (total > 8192) throw new BridgeException(BridgeFailure.RESPOSTA_INVALIDA);
                    bytes.write(buf, 0, size);
                }
            }
            JSONArray rows = new JSONArray(bytes.toString("UTF-8"));
            if (rows.length() != 1) throw new BridgeException(BridgeFailure.SEM_REGISTRO);
            JSONObject row = rows.getJSONObject(0);
            String channel = row.getString("channel_id");
            String eventId = row.getString("event_id");
            String state = row.getString("status");
            String mode = row.getString("mode");
            String contract = row.getString("contract");
            long issued = Instant.parse(row.getString("issued_at")).toEpochMilli();
            long expires = Instant.parse(row.getString("expires_at")).toEpochMilli();
            long now = System.currentTimeMillis();
            if (expires <= now) throw new BridgeException(BridgeFailure.EVENTO_VENCIDO);
            if (!DemoBridgePolicy.accepts(channel, eventId, state, mode, contract, issued, expires, now)) {
                throw new BridgeException(BridgeFailure.RESPOSTA_INVALIDA);
            }
            return new Event(eventId, DemoSignal.fromUntrustedString(state), issued, expires);
        } catch (BridgeException e) {
            throw e;
        } catch (Exception e) {
            // Exception text may reveal hostnames/response details; expose only a safe error code.
            throw new BridgeException(BridgeFailure.fromException(e));
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
