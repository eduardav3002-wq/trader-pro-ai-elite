package com.traderproaielite.overlaydemo;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;

/** GET to the STABLE audit-only RPC; no writes, no private key, no redirects. */
public final class SupabaseHistoryClient {
    private SupabaseHistoryClient() {}
    public static List<HistoryRecoveryPolicy.Row> fetch(String url,String key,long cursor) throws SupabaseDemoClient.BridgeException {
        if (!DemoBridgePolicy.validProjectUrl(url)||!DemoBridgePolicy.validPublishableKey(key)||cursor<0)
            throw new SupabaseDemoClient.BridgeException(BridgeFailure.CONFIGURACAO_INVALIDA);
        HttpsURLConnection c=null;
        try {
            URL endpoint=new URL(url.trim().replaceAll("/$", "")+"/rest/v1/rpc/trader_recuperar_v38?p_apos="+cursor+"&p_limite="+HistoryRecoveryPolicy.PAGE);
            c=(HttpsURLConnection)endpoint.openConnection();
            c.setRequestMethod("GET"); c.setConnectTimeout(4000); c.setReadTimeout(4000);
            c.setInstanceFollowRedirects(false); c.setRequestProperty("apikey",key);
            c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Cache-Control","no-cache,no-store");
            int http=c.getResponseCode();
            if(http!=200) throw new SupabaseDemoClient.BridgeException(BridgeFailure.fromHttp(http));
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(InputStream in=c.getInputStream()) {
                byte[] buf=new byte[2048]; int n,total=0;
                while((n=in.read(buf))!=-1) {
                    total+=n; if(total>131072) throw new SupabaseDemoClient.BridgeException(BridgeFailure.RESPOSTA_INVALIDA);
                    bytes.write(buf,0,n);
                }
            }
            JSONArray data=new JSONArray(bytes.toString("UTF-8"));
            if(data.length()>HistoryRecoveryPolicy.PAGE) throw new SupabaseDemoClient.BridgeException(BridgeFailure.RESPOSTA_INVALIDA);
            List<HistoryRecoveryPolicy.Row> rows=new ArrayList<>();
            for(int i=0;i<data.length();i++) {
                JSONObject r=data.getJSONObject(i);
                Object seq=r.get("sequencia");
                if(!(seq instanceof Integer || seq instanceof Long)) throw new SupabaseDemoClient.BridgeException(BridgeFailure.RESPOSTA_INVALIDA);
                rows.add(new HistoryRecoveryPolicy.Row(((Number)seq).longValue(),r.getString("event_id"),r.getString("contrato"),r.getString("estado"),
                        Instant.parse(r.getString("emitido")).toEpochMilli(),Instant.parse(r.getString("expira")).toEpochMilli(),Boolean.TRUE.equals(r.get("somente_auditoria"))));
            }
            if(!HistoryRecoveryPolicy.validPage(cursor,rows)) throw new SupabaseDemoClient.BridgeException(BridgeFailure.RESPOSTA_INVALIDA);
            return rows;
        } catch(SupabaseDemoClient.BridgeException e) { throw e; }
        catch(Exception e) { throw new SupabaseDemoClient.BridgeException(BridgeFailure.fromException(e)); }
        finally { if(c!=null)c.disconnect(); }
    }
}
