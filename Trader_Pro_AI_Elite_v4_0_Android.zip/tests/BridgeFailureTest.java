import com.traderproaielite.overlaydemo.BridgeFailure;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.net.ConnectException;
import javax.net.ssl.SSLHandshakeException;

public class BridgeFailureTest {
    static int n=0;
    static void yes(boolean b,String why){n++;if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        yes(BridgeFailure.fromHttp(401)==BridgeFailure.HTTP_NAO_AUTORIZADO,"401");
        yes(BridgeFailure.fromHttp(403)==BridgeFailure.HTTP_NAO_AUTORIZADO,"403");
        yes(BridgeFailure.fromHttp(404)==BridgeFailure.HTTP_OUTRO,"404");
        yes(BridgeFailure.fromHttp(429)==BridgeFailure.HTTP_LIMITE_REQUISICOES,"429");
        yes(BridgeFailure.fromHttp(500)==BridgeFailure.HTTP_SERVIDOR,"500");
        yes(BridgeFailure.fromHttp(503)==BridgeFailure.HTTP_SERVIDOR,"503");
        yes(BridgeFailure.fromException(new SocketTimeoutException())==BridgeFailure.TIMEOUT,"timeout");
        yes(BridgeFailure.fromException(new UnknownHostException())==BridgeFailure.DNS_INDISPONIVEL,"DNS");
        yes(BridgeFailure.fromException(new SSLHandshakeException("x"))==BridgeFailure.TLS_FALHOU,"TLS");
        yes(BridgeFailure.fromException(new ConnectException())==BridgeFailure.FALHA_DE_REDE,"connect");
        yes(BridgeFailure.fromException(new IllegalStateException())==BridgeFailure.RESPOSTA_INVALIDA,"format");
        for (BridgeFailure reason:BridgeFailure.values()) {
           yes(reason.description()!=null && !reason.description().isEmpty(),"description " + reason);
           yes(!reason.description().contains("sb_secret_"),"no secret " + reason);
        }
        System.out.println(n+" verificacoes OK · categorias de falha v3.3");
    }
}
