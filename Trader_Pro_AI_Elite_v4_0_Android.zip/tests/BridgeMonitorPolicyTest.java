import com.traderproaielite.overlaydemo.BridgeMonitorPolicy;
public class BridgeMonitorPolicyTest {
 static int n=0;
 static void yes(boolean value,String name){n++;if(!value)throw new AssertionError(name);}
 public static void main(String[] args){
   long now=1_800_000_000_000L;
   yes(BridgeMonitorPolicy.validityMs(now-2000,now+58000,now)==26000,"freshness cap");
   yes(BridgeMonitorPolicy.validityMs(now-2000,now+3000,now)==3000,"remote expiry earlier");
   yes(BridgeMonitorPolicy.validityMs(now-12001,now+3000,now)==0,"late new message");
   yes(BridgeMonitorPolicy.validityMs(now-1000,now,now)==0,"expired at delivery");
   yes(BridgeMonitorPolicy.validityMs(now+4000,now+60000,now)==28000,"clock tolerance bounded");
   yes(BridgeMonitorPolicy.validityMs(now+6000,now+60000,now)==0,"future rejected");
   yes(BridgeMonitorPolicy.keepRepeated(false,3000,2999),"duplicate does not invalidate active message");
   yes(!BridgeMonitorPolicy.keepRepeated(true,3000,2999),"no recovery on duplicate");
   yes(!BridgeMonitorPolicy.keepRepeated(false,3000,3000),"deadline exclusive");
   yes(!BridgeMonitorPolicy.keepRepeated(true,-1,10),"restart requires new message");
   yes(!BridgeMonitorPolicy.heartbeatFresh(-1,100),"process not confirmed");
   yes(BridgeMonitorPolicy.heartbeatFresh(100,15099),"fresh heartbeat");
   yes(!BridgeMonitorPolicy.heartbeatFresh(100,15100),"stale heartbeat");
   yes(!BridgeMonitorPolicy.heartbeatFresh(100,99),"clock rewind");
   yes(BridgeMonitorPolicy.secondsRemaining(3001,1000)==3,"round up");
   yes(BridgeMonitorPolicy.secondsRemaining(1000,1000)==0,"expired zero");
   System.out.println(n+" verificacoes OK · monitor v3.4");
 }
}
