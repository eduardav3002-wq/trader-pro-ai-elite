import com.traderproaielite.overlaydemo.HistoryRecoveryPolicy;
import com.traderproaielite.overlaydemo.HistoryRecoveryPolicy.*;
import java.util.*;
import java.time.Instant;
public class HistoryAppendPlanTest {
    static int n=0;
    static void yes(boolean b,String why){n++;if(!b)throw new AssertionError(why);}
    static final String NOW="2026-11-25T20:50:00Z";
    static Row row(long seq,String id){return new Row(seq,id,"WINZ26","AGUARDAR",1000,21000,true);}
    static Plan plan(long actual,long expected,String csv,List<Row> rows){return HistoryRecoveryPolicy.plan(actual,expected,csv,rows,NOW);}
    public static void main(String[] args){
        List<Row> first=new ArrayList<>();for(int i=1;i<=76;i++)first.add(row(i,"event-"+i));
        Plan initial=plan(0,0,"",first);
        yes(initial.status==AppendStatus.OK&&initial.cursor==76,"legacy sample setup");
        // Five real pending IDs and timings from SQL export, with synthetic legacy 76 rows.
        String[] ids={"185db3da-11b1-425d-b096-3f1fac7fcd91","d7134bda-682c-44f8-b27b-acdffc44c1a7","f62eb0ac-6b2d-4e97-9e4d-6dd09042fdeb","f1764e73-85f0-41aa-99dd-dc8948bc194d","0bdc0999-367c-4cbb-a4dc-5e69f358a0c9"};
        String[] states={"COMPRA","AGUARDAR","VENDA","NAO_OPERAR","COMPRA"};
        String[] issued={"20:46:03","20:46:37","20:46:57","20:47:35","20:48:32"};
        List<Row> pending=new ArrayList<>();
        for(int i=0;i<5;i++){long t=Instant.parse("2026-11-25T"+issued[i]+"Z").toEpochMilli();pending.add(new Row(77+i,ids[i],"WINZ26",states[i],t,t+45000,true));}
        Plan next=plan(76,76,initial.csv,pending);
        yes(next.status==AppendStatus.OK&&next.cursor==81,"76 to 81");
        yes(next.csv.startsWith(initial.csv),"preserves historical lines exactly");
        yes(next.csv.split("\n").length==81,"81 retained");
        yes(next.gaps==0,"no gaps");
        yes(next.csv.contains(ids[4]),"last ID saved");
        yes(plan(81,76,next.csv,pending).status==AppendStatus.CURSOR_DIVERGENTE,"stale fetch rejected");
        yes(plan(76,76,initial.csv,List.of(row(77,"event-1"))).status==AppendStatus.ID_DUPLICADO,"duplicate retained ID");
        yes(plan(76,76,"broken",pending).status==AppendStatus.CACHE_INVALIDO,"corrupt legacy rejected");
        yes(plan(76,76,"",pending).status==AppendStatus.CACHE_INVALIDO,"missing local data rejected");
        yes(plan(76,76,initial.csv,List.of(row(76,"event-77"))).status==AppendStatus.PAGINA_INVALIDA,"old page rejected");
        yes(plan(81,81,next.csv,List.of()).csv.equals(next.csv),"empty page preserves history");
        yes(plan(76,76,initial.csv,List.of(row(79,"event-79"))).gaps==2,"gaps counted");
        String csv=next.csv; long cursor=81;
        for(int k=0;k<11;k++){List<Row> page=new ArrayList<>();for(int i=1;i<=100;i++)page.add(row(cursor+i,"event-"+(cursor+i)));Plan p=plan(cursor,cursor,csv,page);yes(p.status==AppendStatus.OK,"page "+k);csv=p.csv;cursor=p.cursor;}
        yes(csv.split("\n").length==1000&&cursor==1181,"bounded retention");
        yes(plan(cursor,cursor,csv,List.of()).status==AppendStatus.OK,"retained tail valid");
        System.out.println("HistoryAppendPlanTest: "+n+" verificações OK");
    }
}
