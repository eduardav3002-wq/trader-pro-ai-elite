import com.traderproaielite.overlaydemo.HistoryRecoveryPolicy;
import com.traderproaielite.overlaydemo.HistoryRecoveryPolicy.Row;
import java.util.*;
public class HistoryRecoveryPolicyTest {
    static int n=0;
    static void yes(boolean b,String why){n++;if(!b)throw new AssertionError(why);}
    static Row row(long seq,String id){return new Row(seq,id,"WINZ26","COMPRA",1000,16000,true);}
    public static void main(String[] args){
        List<Row> page=Arrays.asList(row(1,"id-1"),row(2,"id-2"),row(3,"id-3"));
        yes(HistoryRecoveryPolicy.validPage(0,page),"initial expired events audit only");
        yes(HistoryRecoveryPolicy.nextCursor(0,page)==3,"advance cursor");
        yes(HistoryRecoveryPolicy.nextCursor(3,Collections.emptyList())==3,"empty page preserves cursor");
        yes(!HistoryRecoveryPolicy.validPage(3,page),"replay rejected");
        yes(HistoryRecoveryPolicy.validPage(2,page.subList(2,3)),"selective recovery");
        yes(!HistoryRecoveryPolicy.validPage(0,Arrays.asList(row(2,"id-2"),row(1,"id-1"))),"out of order");
        yes(!HistoryRecoveryPolicy.validPage(0,Arrays.asList(row(1,"id-1"),row(1,"id-2"))),"duplicate sequence");
        yes(!HistoryRecoveryPolicy.validPage(0,Arrays.asList(row(1,"id-1"),row(2,"id-1"))),"duplicate ID in page");
        yes(HistoryRecoveryPolicy.validPage(3,Arrays.asList(row(5,"id-5"))),"sequence gaps allowed; not proof of completeness");
        yes(!HistoryRecoveryPolicy.validPage(0,Arrays.asList(new Row(1,"id-1","WINZ26","VENDA",1000,16000,false))),"non audit row blocked");
        yes(!HistoryRecoveryPolicy.validPage(0,Arrays.asList(new Row(1,"id-1","OTHER","VENDA",1000,16000,true))),"wrong contract");
        yes(!HistoryRecoveryPolicy.validPage(0,Arrays.asList(new Row(1,"id-1","WINZ26","INVALID",1000,16000,true))),"wrong state");
        yes(!HistoryRecoveryPolicy.validPage(0,Arrays.asList(new Row(1,"id-1","WINZ26","VENDA",1000,1000,true))),"invalid expiry");
        yes(!HistoryRecoveryPolicy.validPage(0,Arrays.asList(new Row(1,"id-1","WINZ26","VENDA",1000,100000,true))),"invalid lifetime");
        yes(!HistoryRecoveryPolicy.validPage(0,Arrays.asList(row(1,"bad,ID"))),"invalid ID");
        yes(!HistoryRecoveryPolicy.validPage(-1,page),"negative cursor");
        List<Row> full=new ArrayList<>(); for(int i=1;i<=100;i++)full.add(row(i,"event-"+i));
        yes(HistoryRecoveryPolicy.validPage(0,full),"full page");
        yes(HistoryRecoveryPolicy.nextCursor(0,full)==100,"full cursor");
        full.add(row(101,"event-101")); yes(!HistoryRecoveryPolicy.validPage(0,full),"over limit rejected");
        yes(HistoryRecoveryPolicy.nextDelay(true,100)==2000,"drain pagination");
        yes(HistoryRecoveryPolicy.nextDelay(true,0)==10000,"normal cadence");
        yes(HistoryRecoveryPolicy.nextDelay(false,100)==30000,"failure backoff");
        try { HistoryRecoveryPolicy.nextCursor(3,page); throw new AssertionError("replay accepted"); } catch(IllegalArgumentException expected){n++;}
        System.out.println("HistoryRecoveryPolicyTest: "+n+" verificações OK");
    }
}
