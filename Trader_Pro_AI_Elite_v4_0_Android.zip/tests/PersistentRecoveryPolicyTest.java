import com.traderproaielite.overlaydemo.HistoryRecoveryPolicy;
import com.traderproaielite.overlaydemo.HistoryRecoveryPolicy.Row;
import com.traderproaielite.overlaydemo.BridgeRecoveryPolicy;
import java.util.*;
public class PersistentRecoveryPolicyTest {
    static int n=0;
    static void yes(boolean b,String why){n++;if(!b)throw new AssertionError(why);}
    static Row row(long seq,String id){return new Row(seq,id,"WINZ26","AGUARDAR",1000,21000,true);}
    static String persist(String previous,List<Row> rows){
        StringBuilder out=new StringBuilder(previous);
        for(Row r:rows)out.append(r.sequence).append(',').append(r.id).append(",WINZ26,AGUARDAR,1970-01-01T00:00:01Z,1970-01-01T00:00:21Z,1970-01-01T00:01:00Z,true\n");
        return out.toString();
    }
    public static void main(String[] args){
        long cursor=76; String csv="";
        for(int page=0;page<3;page++){
            List<Row> rows=new ArrayList<>();
            int count=page<2?100:25;
            for(int i=1;i<=count;i++)rows.add(row(cursor+i,"event-"+(cursor+i)));
            yes(HistoryRecoveryPolicy.validPage(cursor,rows),"page ordered");
            yes(HistoryRecoveryPolicy.distinctFromRetained(csv,rows),"page distinct from previous pages");
            yes(HistoryRecoveryPolicy.sequenceGaps(cursor,rows)==0,"no observed gaps");
            csv=persist(csv,rows); cursor=HistoryRecoveryPolicy.nextCursor(cursor,rows);
            // Simulate restore of persisted cursor/CSV between pages (not an Android storage test).
            csv=new String(csv); cursor=Long.parseLong(Long.toString(cursor));
        }
        yes(cursor==301,"225 rows across three pages");
        yes(csv.split("\n").length==225,"225 retained rows");
        yes(!HistoryRecoveryPolicy.distinctFromRetained(csv,List.of(row(302,"event-100"))),"duplicate across pages rejected");
        yes(!HistoryRecoveryPolicy.validPage(cursor,List.of(row(301,"event-301"))),"replayed sequence rejected");
        yes(HistoryRecoveryPolicy.sequenceGaps(cursor,List.of(row(305,"event-305")))==3,"gap measured, not repaired");
        yes(!HistoryRecoveryPolicy.distinctFromRetained("malformed",List.of(row(302,"event-302"))),"malformed cache rejected");
        yes(HistoryRecoveryPolicy.nextCursor(cursor,List.of())==cursor,"empty page cannot reset persisted cursor");
        yes(HistoryRecoveryPolicy.nextDelay(true,100)==2000,"full page drains promptly");
        yes(HistoryRecoveryPolicy.distinctFromRetained(csv,List.of(row(302,"event-302"))),"new id accepted");
        System.out.println("PersistentRecoveryPolicyTest: "+n+" verificações OK");
    }
}
