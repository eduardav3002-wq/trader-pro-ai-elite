# Trader Pro AI Elite · Android v4.1 — Smart Adaptive Engine DEMO

Base: projeto Android v4.0, mesmo applicationId, permissões, preferências e armazenamento atômico de histórico (history_v40_*). versionCode 41, versionName 4.1.0-demo. Não há ordens, feed real ou integração de corretora.

## Alterações
- GET HTTPS somente leitura em `/rest/v1/rpc/trader_consultar_v41`, que deve retornar o objeto JSON controlador/evento/servidor_utc. Sem fallback para a tabela antiga. Chave pública existente, sem redirects, limite de resposta, timeout, falha segura.
- Distingue INATIVO, ENCERRAMENTO_PREVISTO (somente após confirmação explícita do servidor), CANCELADO, AGUARDANDO_PRIMEIRO, AGUARDANDO_ENCERRAMENTO e EMISSOR_INDISPONIVEL. Ausência de evento não prova encerramento. Após o prazo e tolerância de 15s sem confirmação, considera emissor indisponível.
- Consultas após resposta: 2s em sessão ativa; 20s inativo/encerrado/cancelado. Há tempo adicional HTTP e agendamento Android; erros de rede/HTTP mantêm backoff anterior; falha do emissor consulta a cada 2s. Recuperação histórica: 30s em repouso quando não há página cheia; 2s para páginas cheias, 10s normal. A nova sessão pode demorar até o próximo poll de repouso para ser percebida, e o primeiro evento pode ser perdido ao vivo, mas permanece recuperável para auditoria. O cursor histórico não aciona alertas.
- Valida canal, sessão, datas, validade de 15s, contrato WINZ26, modo DEMONSTRACAO e somente AGUARDAR/NAO_OPERAR. Não ativa evento após o fim previsto; limita validade com base também no relógio do servidor e tempo de requisição. Mantém proteção contra replays e bloqueio na falta de rede. Histórico anterior de COMPRA/VENDA continua apenas como auditoria; não é convertido em alertas novos pela RPC.
- Sem alteração de tabelas ou funções Supabase neste pacote: pressupõe que o controlador e RPC v4.1 foram instalados. Não inicia o emissor automaticamente; a sessão deve ser iniciada no SQL Editor pelo operador.

## Instalação pelo GitHub Actions
1. Exporte CSV histórico, recebimentos e tentativas da v4.0 antes de atualizar. Não limpe nem desinstale.
2. Envie o ZIP intacto para a raiz do repositório. Crie `.github/workflows/android_overlay_v41.yml` com o YAML fornecido. Preserve os workflows anteriores. Use os mesmos segredos ANDROID_KEYSTORE_BASE64 e ANDROID_KEYSTORE_PASSWORD e alias traderpro que assinaram a v4.0. Não envie as chaves pelo chat.
3. Actions > Gerar APK Android v4.1 DEMO assinado > Run workflow. Baixe o artefato após Success, extraia o APK assinado e instale por cima da v4.0. Se houver conflito de assinatura, pare; não desinstale. O CSV exportado não restaura automaticamente os dados locais.
4. Abra v4.1, inicie alertas, confira a recuperação histórica (espera-se pelo menos sequência 170 se as 11 publicações v4.1 foram gravadas na mesma sequência sem outros eventos/lacunas). Com emissor encerrado, diagnóstico deve indicar ENCERRAMENTO_PREVISTO e zero falhas consecutivas; janela NÃO OPERAR.
5. Teste uma nova sessão curta de 2 min com Streamlit fechado; confira recebimentos e histórico por ID. Compare término, perda ao vivo, e recuperação. Não inicie sessões duplicadas. Teste rede desligada e reconexão antes da resistência de 30 min. A meta de latência média <2s e entrega 100% ainda não foi comprovada. Poll de repouso pode perder o primeiro evento; relatar separadamente.

## Validação local
12 classes Java puro: 280 verificações passaram. Não foi possível compilar o APK neste ambiente (sem SDK Android/Gradle); não testamos parsing org.json, HTTP real, assinatura nem instalação no aparelho. O workflow executa testes e compila o APK assinado. O estado CANCELADO está previsto pelo cliente, mas a rotina de cancelamento do servidor não foi instalada neste passo. Exclusivamente DEMO.
