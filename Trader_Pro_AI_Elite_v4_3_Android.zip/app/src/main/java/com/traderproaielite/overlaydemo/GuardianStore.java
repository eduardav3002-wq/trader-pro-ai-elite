package com.traderproaielite.overlaydemo;

import android.content.Context;
import android.content.SharedPreferences;
import java.time.Instant;

/** New separate preference namespace; no secrets or signal payloads. Session-local counts. */
public final class GuardianStore {
    private GuardianStore() {}
    private static SharedPreferences p(Context c){return c.getSharedPreferences("guardian_v43",Context.MODE_PRIVATE);}
    public static void start(Context c){
        SharedPreferences s=p(c);
        boolean prior=s.getBoolean("open",false);
        s.edit().putBoolean("open",true).putString("start",Instant.now().toString())
            .putLong("unconfirmed",s.getLong("unconfirmed",0)+(prior?1:0))
            .putLong("gaps",0).putLong("max_gap",0).putLong("valid",0).putLong("failures",0)
            .putLong("critical",0).putLong("timeouts",0).putLong("recoveries",0)
            .putLong("screen_off",0).putLong("age_sum",0).putLong("age_max",0)
            .putString("end","—").putString("last_gap","—").putString("severity","NORMAL").commit();
    }
    public static void stop(Context c,boolean wanted){
        SharedPreferences s=p(c); if(!s.getBoolean("open",false)) return;
        s.edit().putBoolean("open",false).putString("end",(wanted?"SERVICO_ENCERRADO_COM_SESSAO_SOLICITADA":"ENCERRAMENTO_SOLICITADO")+" · "+Instant.now()).commit();
    }
    public static void gap(Context c,long duration){
        SharedPreferences s=p(c);
        s.edit().putLong("gaps",s.getLong("gaps",0)+1).putLong("max_gap",Math.max(duration,s.getLong("max_gap",0)))
            .putString("last_gap",Instant.now().toString()).putString("severity","CRITICA").apply();
    }
    public static void failure(Context c,BridgeFailure reason,int count){
        SharedPreferences s=p(c); GuardianPolicy.Severity level=GuardianPolicy.severity(reason,count);
        s.edit().putLong("failures",s.getLong("failures",0)+1)
            .putLong("critical",s.getLong("critical",0)+(level==GuardianPolicy.Severity.CRITICA?1:0))
            .putLong("timeouts",s.getLong("timeouts",0)+(reason==BridgeFailure.TIMEOUT?1:0))
            .putString("severity",level.name()).apply();
    }
    public static void valid(Context c,long age,boolean recovered){
        SharedPreferences s=p(c); android.os.PowerManager pm=(android.os.PowerManager)c.getSystemService(Context.POWER_SERVICE);
        s.edit().putLong("valid",s.getLong("valid",0)+1).putLong("recoveries",s.getLong("recoveries",0)+(recovered?1:0))
            .putLong("screen_off",s.getLong("screen_off",0)+(pm!=null&&!pm.isInteractive()?1:0))
            .putLong("age_sum",s.getLong("age_sum",0)+Math.max(0,age)).putLong("age_max",Math.max(age,s.getLong("age_max",0)))
            .putString("severity","NORMAL").apply();
    }
    public static String report(Context c){
        SharedPreferences s=p(c); long n=s.getLong("valid",0);
        String status=!BridgeSessionStore.wanted(c)?"DESATIVADO":(!BridgeAuditStore.live()?"SEM HEARTBEAT RECENTE · NÃO OPERAR":"HEARTBEAT RECENTE");
        return "Guardian v4.3 · DEMO\nEstado local: "+status+"\nÚltima classificação Guardian: "+s.getString("severity","NORMAL")+"\nInício: "+s.getString("start","—")+"\nFim do serviço: "+s.getString("end","—")
            +"\nSessões anteriores sem fechamento registrado: "+s.getLong("unconfirmed",0)
            +"\nIntervalos do loop ≥15s: "+s.getLong("gaps",0)+" · maior: "+s.getLong("max_gap",0)+"ms"
            +"\nÚltimo intervalo: "+s.getString("last_gap","—")
            +"\nEventos válidos nesta sessão: "+n+" · tela não interativa: "+s.getLong("screen_off",0)
            +"\nIdade estimada média/máxima: "+(n==0?"—":(s.getLong("age_sum",0)/n)+" / "+s.getLong("age_max",0)+"ms")
            +"\nOcorrências recordFailure: "+s.getLong("failures",0)+" · críticas: "+s.getLong("critical",0)+" · timeouts: "+s.getLong("timeouts",0)
            +"\nRecuperações por evento novo: "+s.getLong("recoveries",0)
            +"\nContagens locais não provam entrega integral; compare UUIDs com servidor. Intervalo não prova encerramento. Sem ordens/feed real.";
    }
}
