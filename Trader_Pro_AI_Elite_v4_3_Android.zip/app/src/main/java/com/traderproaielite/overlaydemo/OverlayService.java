package com.traderproaielite.overlaydemo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/** User-initiated native overlay. All trade-like states are VISUAL DEMOS. */
public final class OverlayService extends Service {
    public static final String ACTION_SHOW = "com.traderproaielite.overlaydemo.SHOW_DEMO";
    public static final String ACTION_START_BRIDGE = "com.traderproaielite.overlaydemo.START_BRIDGE_DEMO";
    public static final String ACTION_RESUME_BRIDGE = "com.traderproaielite.overlaydemo.RESUME_BRIDGE_DEMO";
    public static final String ACTION_STOP = "com.traderproaielite.overlaydemo.STOP_DEMO";
    public static final String EXTRA_SIGNAL = "demo_signal";
    private static final String CHANNEL_ID = "demo_overlay_status_v30";
    private static final int NOTIFICATION_ID = 3009;
    private static final int BACKGROUND = 0xFF111C33;
    private static final int SECONDARY = 0xFFADB9D1;
    private final Handler tickHandler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private WindowManager.LayoutParams layoutParams;
    private LinearLayout overlay;
    private TextView countdown;
    private TextView linkHealthText;
    private DemoSignal requested = DemoSignal.NAO_OPERAR;
    private long requestedAt = -1;
    private boolean minimized = false;
    private boolean activated = false;
    private long popupShownAt = -1L;
    private OverlayDisplayMode displayMode = OverlayDisplayMode.TEMPORIZADO;
    // Read-only demo polling. The service starts ONLY after an explicit user action.
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService historyExecutor = Executors.newSingleThreadExecutor();
    private boolean historyInFlight = false;
    private long nextHistoryElapsed = 0L;
    private boolean bridgeMode = false;
    private boolean emitterIdle = false;
    private boolean lastConfirmedIdle = false;
    private long ageSampleElapsed = -1L;
    private boolean requestInFlight = false;
    private String lastBridgeEvent = "";
    private String rejectedBridgeEvent = "";
    private long nextPollElapsed = 0L;
    private long remoteValidUntilElapsed = -1L;
    private long lastRemoteIssuedWallMs = -1L;
    private long latestAcceptedIssuedWallMs = -1L;
    private long bridgeGeneration = 0;
    private boolean lastRequestFailed = false;
    private boolean awaitingRecovery = false;
    private boolean recoveryAfterFault = false;
    private int consecutiveFailures = 0;
    private BridgeFailure lastFailureReason = BridgeFailure.NENHUMA;
    private BridgeFailure lastDiagnosticReason = BridgeFailure.NENHUMA;
    private BridgeReliability.LinkState linkState = BridgeReliability.LinkState.DESATIVADO;
    private long lastHttpRttMs = -1L;
    private long lastEventAgeMs = -1L;
    private ConnectivityManager connectivity;
    private ConnectivityManager.NetworkCallback networkCallback;
    private Network monitoredNetwork;
    private long networkEpoch = 0L;
    private long lastHeartbeat = -1L;
    private long guardianLastTick = -1L;

    private void startNetworkMonitor() {
        if (networkCallback != null) return;
        connectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity == null) return;
        monitoredNetwork = connectivity.getActiveNetwork();
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                if (!bridgeMode || networkCallback != this) return;
                if (!network.equals(monitoredNetwork)) {
                    if (monitoredNetwork != null) invalidateNetwork(BridgeFailure.FALHA_DE_REDE);
                    monitoredNetwork = network;
                    nextPollElapsed = 0L;
                    nextHistoryElapsed = 0L;
                    maybePoll(SystemClock.elapsedRealtime());
                }
            }
            @Override public void onLost(Network network) {
                if (!bridgeMode || networkCallback != this || !network.equals(monitoredNetwork)) return;
                monitoredNetwork = null;
                invalidateNetwork(BridgeFailure.SEM_REDE_LOCAL);
            }
        };
        try { connectivity.registerDefaultNetworkCallback(networkCallback, tickHandler); }
        catch (RuntimeException e) { networkCallback = null; } // periodic HTTPS remains active
    }

    private void stopNetworkMonitor() {
        if (networkCallback != null && connectivity != null) {
            try { connectivity.unregisterNetworkCallback(networkCallback); }
            catch (RuntimeException ignored) { }
        }
        networkCallback = null;
        monitoredNetwork = null;
        networkEpoch++;
    }

    private void invalidateNetwork(BridgeFailure reason) {
        networkEpoch++;
        long now = SystemClock.elapsedRealtime();
        recordFailure(reason, -1L, now, System.currentTimeMillis());
        updateLinkHealth();
    }


    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopExplicitly();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopExplicitly();
            return START_NOT_STICKY;
        }
        boolean resume=intent==null || ACTION_RESUME_BRIDGE.equals(intent.getAction());
        if (resume && !BridgeSessionStore.wanted(this)) { stopSelf(); return START_NOT_STICKY; }
        if (resume || ACTION_START_BRIDGE.equals(intent.getAction())) {
            if (resume && bridgeMode) return START_STICKY;
            if (!BridgeSessionStore.setWanted(this,true)) { stopSelf(); return START_NOT_STICKY; }
            if (bridgeMode) GuardianStore.stop(this,false);
            GuardianStore.start(this);
            guardianLastTick=-1L;
            BridgeSessionStore.started(this,resume);
            stopNetworkMonitor();
            bridgeGeneration++;
            requestInFlight = false;
            nextHistoryElapsed = 0L;
            bridgeMode = true;
            emitterIdle = false;
            lastConfirmedIdle = false;
            ageSampleElapsed = -1L;
            BridgeAuditStore.controllerState(null);
            lastRequestFailed = false;
            awaitingRecovery = true;
            recoveryAfterFault = false;
            consecutiveFailures = 0;
            lastFailureReason = BridgeFailure.NENHUMA;
            lastDiagnosticReason = BridgeFailure.NENHUMA;
            linkState = BridgeReliability.LinkState.CONECTANDO;
            lastHttpRttMs = -1L;
            lastEventAgeMs = -1L;
            lastRemoteIssuedWallMs = -1L;
            latestAcceptedIssuedWallMs = BridgeAuditStore.lastIssuedMs(this);
            BridgeAuditStore.setHealth(this, linkState, -1L, -1L, BridgeFailure.NENHUMA, 0);
            lastBridgeEvent = BridgeAuditStore.lastEventId(this);
            rejectedBridgeEvent = "";
            remoteValidUntilElapsed = -1L;
            nextPollElapsed = 0L;
            displayMode = readMode();
            ensureForeground();
            long now = SystemClock.elapsedRealtime();
            activated = true;
            // Fail closed immediately while waiting for the first HTTPS response.
            requested = DemoSignal.NAO_OPERAR;
            requestedAt = -1L;
            if (displayMode == OverlayDisplayMode.FIXO) {
                if (overlay == null) showPopup(now);
                else renderOverlay();
            } else showPopup(now);
            tickHandler.removeCallbacks(expirationTick);
            lastHeartbeat = -1L;
            BridgeAuditStore.clearHeartbeat(this);
            startNetworkMonitor();
            tickHandler.postDelayed(expirationTick, 100L);
            return START_STICKY;
        }
        if (!ACTION_SHOW.equals(intent.getAction())) {
            stopSelf(); return START_NOT_STICKY;
        }
        // Explicitly entering manual DEMO cancels the remote polling mode.
        if (bridgeMode) GuardianStore.stop(this,false);
        BridgeSessionStore.setWanted(this,false);
        bridgeMode = false;
        stopNetworkMonitor();
        BridgeAuditStore.clearHeartbeat(this);
        bridgeGeneration++;
        remoteValidUntilElapsed = -1L;
        linkState = BridgeReliability.LinkState.DESATIVADO;
        BridgeAuditStore.setHealth(this, linkState, -1L, -1L, BridgeFailure.NENHUMA, 0);
        displayMode = readMode();
        ensureForeground();
        long now = SystemClock.elapsedRealtime();
        DemoSignal previous = DemoPolicy.effective(requested, requestedAt, now);
        DemoSignal incoming = DemoSignal.fromUntrustedString(intent.getStringExtra(EXTRA_SIGNAL));
        boolean firstActivation = !activated;
        activated = true;

        // IMPORTANT: identical states do not restart the 60-second validity window,
        // and do not resurface a popup that has already disappeared.
        if (firstActivation || incoming != previous) {
            requested = incoming;
            requestedAt = incoming == DemoSignal.NAO_OPERAR ? -1L : now;
            if (displayMode == OverlayDisplayMode.FIXO) {
                // Do not reopen a manually minimized fixed panel on every signal.
                if (overlay == null) showPopup(now);
                else renderOverlay();
            } else if (OverlayVisibilityPolicy.shouldPopup(previous, incoming, firstActivation)) {
                showPopup(now);
            } else {
                hidePopup();
            }
        }
        tickHandler.removeCallbacks(expirationTick);
        tickHandler.postDelayed(expirationTick, 250L);
        return START_NOT_STICKY;
    }

    private void stopExplicitly() {
        BridgeSessionStore.setWanted(this,false);
        if (bridgeMode) GuardianStore.stop(this,false);
        stopSelf();
    }

    private void ensureForeground() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Painel Android · DEMONSTRAÇÃO", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Aviso de que o painel de demonstração está ativo. Não contém sinais reais.");
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 28, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 29, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Trader Pro AI · SOBREPOSIÇÃO DEMO")
                .setContentText(bridgeMode
                        ? "PONTE DEMO · sem cotações reais · desconecte quando quiser"
                        : (displayMode == OverlayDisplayMode.FIXO
                        ? "Modo FIXO · demonstração, sem sinais reais"
                        : "Modo TEMPORIZADO · janela de 5 segundos"))
                .setContentIntent(openPi)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                        "Desligar painel", stopPi).build());
        Notification notice = builder.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notice, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notice);
        }
    }

    private void showPopup(long now) {
        if (!Settings.canDrawOverlays(this)) { stopExplicitly(); return; }
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        popupShownAt = now;
        minimized = false;
        if (overlay == null) createOverlay();
        else renderOverlay();
    }

    private void hidePopup() {
        popupShownAt = -1L;
        minimized = false;
        countdown = null;
        linkHealthText = null;
        if (windowManager != null && overlay != null) {
            try { windowManager.removeView(overlay); }
            catch (IllegalArgumentException ignored) { }
        }
        overlay = null;
        // Keep layoutParams: when an important signal changes, restore the
        // popup at the same position where the user dragged it.
    }

    private void createOverlay() {
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        if (layoutParams == null) {
            layoutParams = new WindowManager.LayoutParams(
                    dp(280), WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            layoutParams.gravity = Gravity.TOP | Gravity.START;
            layoutParams.x = dp(16);
            layoutParams.y = dp(110);
        }
        renderOverlay();
        try { windowManager.addView(overlay, layoutParams); }
        catch (SecurityException | WindowManager.BadTokenException e) { stopSelf(); }
    }

    private void renderOverlay() {
        if (overlay == null) return;
        overlay.removeAllViews();
        DemoSignal state = DemoPolicy.effective(requested, requestedAt, SystemClock.elapsedRealtime());
        if (state == DemoSignal.NAO_OPERAR) requested = DemoSignal.NAO_OPERAR;
        int stroke = state.color;
        overlay.setBackground(background(BACKGROUND, stroke, 18));
        overlay.setPadding(dp(13), dp(11), dp(13), dp(12));
        if (minimized) {
            countdown = null;
            linkHealthText = null;
            TextView bubble = label(state == DemoSignal.NAO_OPERAR ? "◈ NÃO OPERAR" : "◈ " + state.name(), 11, stroke, true);
            bubble.setGravity(Gravity.CENTER);
            overlay.addView(bubble, new LinearLayout.LayoutParams(-1, dp(34)));
            bubble.setOnTouchListener(new DragListener(true));
            resizeOverlay(dp(132));
            return;
        }
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView heading = label("◈ SMART ALERTS v4.3 · DEMO", 12, SECONDARY, true);
        titleRow.addView(heading, new LinearLayout.LayoutParams(0, dp(32), 1f));
        heading.setOnTouchListener(new DragListener(false));
        TextView minimize = label("−", 24, 0xFFE8EEFD, true);
        minimize.setGravity(Gravity.CENTER);
        titleRow.addView(minimize, new LinearLayout.LayoutParams(dp(32), dp(38)));
        minimize.setOnClickListener(v -> { minimized = true; renderOverlay(); });
        TextView close = label("×", 24, 0xFFFFA6AE, true);
        close.setGravity(Gravity.CENTER);
        titleRow.addView(close, new LinearLayout.LayoutParams(dp(32), dp(38)));
        close.setOnClickListener(v -> stopExplicitly());
        overlay.addView(titleRow);
        TextView stateLabel = label(state.label, 21, state.color, true);
        overlay.addView(stateLabel);
        TextView detail = label(state.description, 13, 0xFFE0E7F5, false);
        detail.setPadding(0, dp(5), 0, dp(5));
        overlay.addView(detail);
        countdown = label("", 11, SECONDARY, false);
        overlay.addView(countdown);
        if (bridgeMode) {
            linkHealthText = label("", 10, 0xFF90A7C9, true);
            linkHealthText.setPadding(0,dp(4),0,0);
            overlay.addView(linkHealthText);
            updateLinkHealth();
        } else linkHealthText = null;
        updateCountdown(state);
        resizeOverlay(dp(280));
    }

    private void resizeOverlay(int width) {
        if (layoutParams == null) return;
        layoutParams.width = width;
        if (windowManager != null && overlay.getWindowToken() != null) {
            windowManager.updateViewLayout(overlay, layoutParams);
        }
    }

    private void updateCountdown(DemoSignal state) {
        if (countdown == null || minimized) return;
        if (state == DemoSignal.NAO_OPERAR) {
            countdown.setText("SEM FEED AO VIVO · SEM ORDENS");
            return;
        }
        long remaining = Math.max(0L,
                DemoPolicy.TTL_MS - (SystemClock.elapsedRealtime() - requestedAt));
        if (bridgeMode) remaining = Math.min(remaining, Math.max(0L, remoteValidUntilElapsed-SystemClock.elapsedRealtime()));
        countdown.setText("SIMULAÇÃO · validade " + ((remaining + 999L) / 1000L) + "s");
    }

    /** Only returns false when Android clearly has no active network with Internet capability. */
    private boolean hasNetworkConnection() {
        ConnectivityManager mgr=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if (mgr==null) return true; // Unknown: let HTTPS classify any error.
        Network active=mgr.getActiveNetwork();
        if (active==null) return false;
        NetworkCapabilities caps=mgr.getNetworkCapabilities(active);
        return caps!=null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private void recordHealth() {
        BridgeAuditStore.setHealth(this,linkState,lastHttpRttMs,lastEventAgeMs,
                lastDiagnosticReason,consecutiveFailures);
    }

    private void recordFailure(BridgeFailure reason,long rttMs,long nowElapsed,long receivedWall) {
        emitterIdle=false;
        boolean changed=!lastRequestFailed || reason!=lastFailureReason;
        lastRequestFailed=true;
        awaitingRecovery=true;
        recoveryAfterFault=true;
        consecutiveFailures=BridgeRecoveryPolicy.nextFailureCount(consecutiveFailures,lastFailureReason,reason);
        lastFailureReason=reason;
        GuardianStore.failure(this,reason,consecutiveFailures);
        lastDiagnosticReason=reason;
        lastHttpRttMs=rttMs;
        lastEventAgeMs=-1L;
        remoteValidUntilElapsed=-1L;
        lastRemoteIssuedWallMs=-1L;
        linkState=reason==BridgeFailure.EVENTO_VENCIDO || reason==BridgeFailure.SEM_NOVA_PUBLICACAO
                ? BridgeReliability.LinkState.ATRASADO : BridgeReliability.LinkState.INDISPONIVEL;
        nextPollElapsed=nowElapsed+GuardianPolicy.retry(consecutiveFailures,reason,lastConfirmedIdle);
        if(reason==BridgeFailure.EMISSOR_INDISPONIVEL) {
            linkState=BridgeReliability.LinkState.EMISSOR_INDISPONIVEL;
            nextPollElapsed=nowElapsed+AdaptiveEmitterPolicy.ACTIVE_MS;
        }
        recordHealth();
        if (changed) BridgeAuditStore.append(this,"FALHA_"+reason.name(),DemoSignal.NAO_OPERAR,
                null,-1L,receivedWall,-1L,rttMs,reason);
        applyRemoteState(DemoSignal.NAO_OPERAR,-1L,nowElapsed);
    }

    /** HTTPS polling runs off the main thread; only state changes surface a popup. */
    private void maybePoll(long nowElapsed) {
        if (!bridgeMode || requestInFlight || nowElapsed < nextPollElapsed) return;
        requestInFlight=true;
        nextPollElapsed=nowElapsed+BridgeRecoveryPolicy.POLL_NORMAL_MS;
        final long generation=bridgeGeneration;
        final long epoch=networkEpoch;
        String url=getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("url","");
        String publicKey=getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("publishable","");
        ioExecutor.execute(() -> {
            long started=SystemClock.elapsedRealtime();
            SupabaseDemoClient.Snapshot snapshot=null;
            BridgeFailure error=BridgeFailure.NENHUMA;
            try {
                if (!hasNetworkConnection()) error=BridgeFailure.SEM_REDE_LOCAL;
                else snapshot=SupabaseDemoClient.fetch(url,publicKey);
            } catch (SupabaseDemoClient.BridgeException ex) {
                error=ex.reason;
            } catch(Exception ex) {
                error=BridgeFailure.fromException(ex);
            }
            final long rtt=BridgeReliability.roundTripMs(started,SystemClock.elapsedRealtime());
            final SupabaseDemoClient.Snapshot response=snapshot;
            final SupabaseDemoClient.Event result=response==null?null:response.event;
            final BridgeFailure reason=error;
            tickHandler.post(() -> {
                if (!bridgeMode || generation!=bridgeGeneration) return;
                requestInFlight=false;
                if (!url.equals(getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("url",""))
                    || !publicKey.equals(getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("publishable",""))) return;
                if (epoch != networkEpoch) {
                    BridgeAuditStore.appendAttempt(this, System.currentTimeMillis(), "REDE_ALTERADA", reason, null, rtt, -1L);
                    return; // ignore response from the old network
                }
                long current=SystemClock.elapsedRealtime(), receivedWall=System.currentTimeMillis();
                guardianCheck(current);
                lastHttpRttMs=rtt;
                if (!hasNetworkConnection()) {
                    recordFailure(BridgeFailure.SEM_REDE_LOCAL,-1L,current,receivedWall);
                    BridgeAuditStore.appendAttempt(this,receivedWall,"FALHA",BridgeFailure.SEM_REDE_LOCAL,null,rtt,nextPollElapsed-current);
                    updateLinkHealth();
                    return;
                }
                if(response!=null) {
                    lastConfirmedIdle=AdaptiveEmitterPolicy.idle(response.state);
                    BridgeAuditStore.controllerState(response.state);
                }
                if(response!=null && result==null) {
                    AdaptiveEmitterPolicy.State state=response.state;
                    if(state==AdaptiveEmitterPolicy.State.EMISSOR_INDISPONIVEL) {
                        recordFailure(BridgeFailure.EMISSOR_INDISPONIVEL,rtt,current,receivedWall);
                    } else {
                        BridgeReliability.LinkState before=linkState;
                        emitterIdle=AdaptiveEmitterPolicy.idle(state);
                        linkState=state==AdaptiveEmitterPolicy.State.ENCERRADO
                            ? BridgeReliability.LinkState.ENCERRAMENTO_PREVISTO
                            : BridgeReliability.LinkState.valueOf(state.name());
                        lastRequestFailed=false; awaitingRecovery=true; recoveryAfterFault=false;
                        consecutiveFailures=0; lastFailureReason=BridgeFailure.NENHUMA;
                        lastDiagnosticReason=BridgeFailure.NENHUMA; lastEventAgeMs=-1L;
                        lastRemoteIssuedWallMs=-1L; remoteValidUntilElapsed=-1L;
                        nextPollElapsed=current+SmartReliabilityPolicy.controllerDelay(state);
                        if(before!=linkState) {
                            BridgeAuditStore.append(this,linkState.name(),DemoSignal.NAO_OPERAR,null,-1L,receivedWall,-1L,rtt,BridgeFailure.NENHUMA);
                            nextHistoryElapsed=0L;
                        }
                        recordHealth(); applyRemoteState(DemoSignal.NAO_OPERAR,-1L,current);
                    }
                    BridgeAuditStore.appendAttempt(this,receivedWall,linkState.name(),lastDiagnosticReason,null,rtt,nextPollElapsed-current);
                    updateLinkHealth(); return;
                }
                if (result==null) {
                    recordFailure(reason==BridgeFailure.NENHUMA ? BridgeFailure.RESPOSTA_INVALIDA : reason,
                            rtt,current,receivedWall);
                    BridgeAuditStore.appendAttempt(this,receivedWall,"FALHA",lastFailureReason,null,rtt,nextPollElapsed-current);
                    updateLinkHealth();
                    return;
                }
                if (result.expiresAtMs <= receivedWall) {
                    recordFailure(BridgeFailure.EVENTO_VENCIDO,rtt,current,receivedWall);
                    BridgeAuditStore.appendAttempt(this,receivedWall,"FALHA",BridgeFailure.EVENTO_VENCIDO,result.eventId,rtt,nextPollElapsed-current);
                    updateLinkHealth();
                    return;
                }
                if(emitterIdle) nextHistoryElapsed=0L;
                emitterIdle=false;
                boolean hadFailure=recoveryAfterFault;
                // Retain recovery status after repeated responses, even if HTTPS works.
                lastRequestFailed=false;
                lastFailureReason=BridgeFailure.NENHUMA;
                consecutiveFailures=0;
                nextPollElapsed=current+BridgeRecoveryPolicy.POLL_NORMAL_MS;
                lastHttpRttMs=rtt;
                lastRemoteIssuedWallMs=result.issuedAtMs;
                lastEventAgeMs=BridgeReliability.ageMs(result.issuedAtMs,receivedWall);
                ageSampleElapsed=current;
                BridgeRecoveryPolicy.Delivery decision=BridgeRecoveryPolicy.classify(
                        lastBridgeEvent,latestAcceptedIssuedWallMs,result.eventId,
                        result.issuedAtMs,receivedWall);
                BridgeReliability.LinkState previousHealth=linkState;
                linkState=BridgeReliability.classifyGoodResponse(result.issuedAtMs,receivedWall);
                lastDiagnosticReason=BridgeFailure.NENHUMA;
                if (decision==BridgeRecoveryPolicy.Delivery.ANTERIOR_OU_REPLAY) {
                    awaitingRecovery=true;
                    recoveryAfterFault=true;
                    remoteValidUntilElapsed=-1L;
                    linkState=BridgeReliability.LinkState.ATRASADO;
                    lastDiagnosticReason=BridgeFailure.RESPOSTA_INVALIDA;
                    if (!result.eventId.equals(rejectedBridgeEvent)) {
                        rejectedBridgeEvent=result.eventId;
                        BridgeAuditStore.append(this,"EVENTO_ANTERIOR_REJEITADO",result.state,
                                result.eventId,result.issuedAtMs,receivedWall,lastEventAgeMs,rtt,lastDiagnosticReason);
                    }
                    applyRemoteState(DemoSignal.NAO_OPERAR,-1L,current);
                } else if (decision==BridgeRecoveryPolicy.Delivery.NOVO_ATRASADO) {
                    awaitingRecovery=true;
                    recoveryAfterFault=true;
                    remoteValidUntilElapsed=-1L;
                    long candidate=Math.max(latestAcceptedIssuedWallMs,result.issuedAtMs);
                    if (!BridgeAuditStore.rememberEvent(this,result.eventId,candidate)) {
                        recordFailure(BridgeFailure.FALHA_ARMAZENAMENTO_LOCAL,rtt,current,receivedWall);
                        updateLinkHealth(); return;
                    }
                    lastBridgeEvent=result.eventId;
                    latestAcceptedIssuedWallMs=candidate;
                    rejectedBridgeEvent=result.eventId;
                    linkState=BridgeReliability.LinkState.ATRASADO;
                    lastDiagnosticReason=BridgeFailure.SEM_NOVA_PUBLICACAO;
                    BridgeAuditStore.append(this,"NOVO_EVENTO_ATRASADO",result.state,
                            result.eventId,result.issuedAtMs,receivedWall,lastEventAgeMs,rtt,lastDiagnosticReason);
                    applyRemoteState(DemoSignal.NAO_OPERAR,-1L,current);
                } else if (decision==BridgeRecoveryPolicy.Delivery.REPETIDO) {
                    // Same id never reopens or refreshes COMPRA/VENDA; stale repetition is fail-closed.
                    if (linkState==BridgeReliability.LinkState.ATRASADO
                            || result.eventId.equals(rejectedBridgeEvent)
                            || !BridgeMonitorPolicy.keepRepeated(awaitingRecovery,remoteValidUntilElapsed,current)) {
                        if (remoteValidUntilElapsed >= 0L) recoveryAfterFault=true;
                        remoteValidUntilElapsed=-1L;
                        awaitingRecovery=true;
                        linkState=BridgeReliability.LinkState.ATRASADO;
                        lastDiagnosticReason=BridgeFailure.SEM_NOVA_PUBLICACAO;
                        if (previousHealth!=BridgeReliability.LinkState.ATRASADO) {
                            BridgeAuditStore.append(this,"SEM_NOVA_PUBLICACAO",DemoSignal.NAO_OPERAR,
                                    result.eventId,result.issuedAtMs,receivedWall,lastEventAgeMs,rtt,lastDiagnosticReason);
                        }
                        applyRemoteState(DemoSignal.NAO_OPERAR,-1L,current);
                    }
                } else {
                    if (!BridgeAuditStore.rememberEvent(this,result.eventId,result.issuedAtMs)) {
                        recordFailure(BridgeFailure.FALHA_ARMAZENAMENTO_LOCAL,rtt,current,receivedWall);
                        updateLinkHealth(); return;
                    }
                    lastBridgeEvent=result.eventId;
                    rejectedBridgeEvent="";
                    latestAcceptedIssuedWallMs=result.issuedAtMs;
                    long remaining=BridgeMonitorPolicy.validityMs(result.issuedAtMs,result.expiresAtMs,receivedWall);
                    remoteValidUntilElapsed=current+remaining;
                    // Recovery is acknowledged only with a DIFFERENT valid, fresh event.
                    String label=hadFailure ? "RECUPERADA_COM_EVENTO_NOVO" : "NOVO_EVENTO_RECEBIDO";
                    BridgeAuditStore.append(this,label,result.state,result.eventId,
                            result.issuedAtMs,receivedWall,lastEventAgeMs,rtt,BridgeFailure.NENHUMA);
                    awaitingRecovery=false;
                    recoveryAfterFault=false;
                    GuardianStore.valid(this,lastEventAgeMs,hadFailure);
                    applyRemoteState(result.state,lastEventAgeMs,current);
                }
                nextPollElapsed=current+SmartReliabilityPolicy.activeDelay(lastEventAgeMs,awaitingRecovery);
                BridgeAuditStore.appendAttempt(this,receivedWall,decision.name(),lastDiagnosticReason,
                        result.eventId,rtt,nextPollElapsed-current);
                recordHealth();
                updateLinkHealth();
            });
        });
    }

    /** Historical recovery never calls applyRemoteState or touches the live cursor. */
    private void maybeRecoverHistory(long now) {
        if (!bridgeMode || historyInFlight || now < nextHistoryElapsed || !hasNetworkConnection()) return;
        final long generation=bridgeGeneration, epoch=networkEpoch;
        final String url=getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("url", "");
        final String key=getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("publishable", "");
        final long cursor;
        try { cursor=HistoryRecoveryStore.cursor(this,url); }
        catch(RuntimeException e) {
            HistoryRecoveryStore.status(this,url,"FALHA_LEITURA_HISTORICO");
            nextHistoryElapsed=now+HistoryRecoveryPolicy.FAILURE_MS; return;
        }
        historyInFlight=true;
        historyExecutor.execute(() -> {
            java.util.List<HistoryRecoveryPolicy.Row> rows=null;
            BridgeFailure failure=BridgeFailure.NENHUMA;
            try { rows=SupabaseHistoryClient.fetch(url,key,cursor); }
            catch(SupabaseDemoClient.BridgeException ex) { failure=ex.reason; }
            final java.util.List<HistoryRecoveryPolicy.Row> result=rows;
            final BridgeFailure reason=failure;
            tickHandler.post(() -> {
                historyInFlight=false;
                if (!bridgeMode || generation!=bridgeGeneration || epoch!=networkEpoch
                    || !url.equals(getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("url", ""))
                    || !key.equals(getSharedPreferences("bridge_v31",MODE_PRIVATE).getString("publishable", ""))) return;
                boolean ok=false;
                String status;
                if(result==null) status="FALHA_"+reason.name();
                else {
                    try { status=HistoryRecoveryStore.append(this,url,cursor,result); }
                    catch(RuntimeException ignored) { status="FALHA_INTERNA_HISTORICO"; }
                    ok=!status.startsWith("FALHA_");
                }
                HistoryRecoveryStore.status(this,url,status);
                nextHistoryElapsed=SystemClock.elapsedRealtime()+(emitterIdle && ok && result!=null && result.size()<HistoryRecoveryPolicy.PAGE ? AdaptiveEmitterPolicy.HISTORY_IDLE_MS : HistoryRecoveryPolicy.nextDelay(ok,result==null?0:result.size()));
            });
        });
    }

    private void updateLinkHealth() {
        if (linkHealthText == null) return;
        String note;
        switch (linkState) {
            case INATIVO: note="EMISSOR: INATIVO · NÃO OPERAR"; break;
            case ENCERRAMENTO_PREVISTO: note="ENCERRAMENTO PREVISTO · NÃO OPERAR"; break;
            case CANCELADO: note="EMISSOR CANCELADO · NÃO OPERAR"; break;
            case AGUARDANDO_PRIMEIRO: note="AGUARDANDO PRIMEIRA PUBLICAÇÃO"; break;
            case AGUARDANDO_ENCERRAMENTO: note="AGUARDANDO CONFIRMAÇÃO DO FIM"; break;
            case EMISSOR_INDISPONIVEL: note="EMISSOR INDISPONÍVEL · NÃO OPERAR"; break;
            case CONECTADO: note="PONTE: CONECTADA"; break;
            case ATRASADO: note="PONTE: ATRASADA · NÃO OPERAR"; break;
            case CONECTANDO: note="PONTE: CONECTANDO · NÃO OPERAR"; break;
            case INDISPONIVEL: note="PONTE: INDISPONÍVEL · NÃO OPERAR"; break;
            default: note="PONTE: DESATIVADA"; break;
        }
        if (lastDiagnosticReason!=BridgeFailure.NENHUMA)
            note+=" · "+lastDiagnosticReason.name();
        if (lastHttpRttMs>=0) note+=" · HTTP "+lastHttpRttMs+"ms";
        if (lastRemoteIssuedWallMs>0)
            note+=" · evento ≈"+(SmartReliabilityPolicy.ageAt(lastEventAgeMs,ageSampleElapsed,
                    SystemClock.elapsedRealtime())/1000)+"s";
        linkHealthText.setText(note);
        linkHealthText.setTextColor(linkState==BridgeReliability.LinkState.CONECTADO ? 0xFF75D6B0
                : linkState==BridgeReliability.LinkState.CONECTANDO ? 0xFFFFD28A : 0xFFFFA6AE);
    }

    private void applyRemoteState(DemoSignal next, long ageMs, long now) {
        if (!bridgeMode) return;
        DemoSignal previous = DemoPolicy.effective(requested, requestedAt, now);
        // Never leave an expired BUY/SELL visible after a transport error.
        if (next == DemoSignal.NAO_OPERAR) {
            requested = DemoSignal.NAO_OPERAR;
            requestedAt = -1L;
        } else {
            requested = next;
            requestedAt = now - Math.min(Math.max(ageMs,0L),DemoPolicy.TTL_MS);
        }
        if (displayMode == OverlayDisplayMode.FIXO) {
            if (overlay == null) showPopup(now);
            else renderOverlay();
        } else if (OverlayVisibilityPolicy.shouldPopup(previous,next,false)) {
            showPopup(now);
        } else if (previous != next) {
            hidePopup();
        }
    }

    // Runs on the same main looper: can detect a gap only when Android resumes execution.
    private void guardianCheck(long now) {
        long last=guardianLastTick;
        guardianLastTick=now;
        if (!GuardianPolicy.gap(last,now)) return;
        GuardianStore.gap(this,Math.max(0,now-last));
        remoteValidUntilElapsed=-1L;
        awaitingRecovery=true;
        recoveryAfterFault=true;
        lastRemoteIssuedWallMs=-1L;
        lastEventAgeMs=-1L;
        linkState=BridgeReliability.LinkState.ATRASADO;
        lastDiagnosticReason=BridgeFailure.SEM_NOVA_PUBLICACAO;
        recordHealth();
        BridgeAuditStore.append(this,"FALHA_GUARDIAN_INTERVALO_LOOP",DemoSignal.NAO_OPERAR,null,-1L,
                System.currentTimeMillis(),-1L,-1L,lastDiagnosticReason);
        applyRemoteState(DemoSignal.NAO_OPERAR,-1L,now);
        // Do not override an existing rate-limit/auth backoff or start a parallel request.
    }

    private final Runnable expirationTick = new Runnable() {
        @Override public void run() {
            if (!Settings.canDrawOverlays(OverlayService.this)) { stopExplicitly(); return; }
            long now = SystemClock.elapsedRealtime();
            OverlayDisplayMode selected = readMode();
            if (selected != displayMode) {
                displayMode = selected;
                ensureForeground();
                // A mode selection is intentional. Reopen once to confirm the change.
                if (displayMode == OverlayDisplayMode.FIXO) showPopup(now);
                else if (minimized) hidePopup();
                else showPopup(now);
            }
            if (bridgeMode) {
                guardianCheck(now);
                if (lastHeartbeat < 0 || now-lastHeartbeat >= BridgeMonitorPolicy.HEARTBEAT_MS) {
                    BridgeAuditStore.heartbeat(OverlayService.this,now);
                    lastHeartbeat=now;
                }
                if (remoteValidUntilElapsed >= 0 && now >= remoteValidUntilElapsed) {
                    remoteValidUntilElapsed = -1L;
                    awaitingRecovery=true;
                    recoveryAfterFault=true;
                    BridgeReliability.LinkState before=linkState;
                    linkState = BridgeReliability.LinkState.ATRASADO;
                    lastDiagnosticReason=BridgeFailure.SEM_NOVA_PUBLICACAO;
                    long expiryAge=SmartReliabilityPolicy.ageAt(lastEventAgeMs,ageSampleElapsed,now);
                    lastEventAgeMs=expiryAge; ageSampleElapsed=now;
                    recordHealth();
                    if (before!=BridgeReliability.LinkState.ATRASADO) {
                        BridgeAuditStore.append(OverlayService.this,"SEM_NOVA_PUBLICACAO",DemoSignal.NAO_OPERAR,
                                lastBridgeEvent,lastRemoteIssuedWallMs,System.currentTimeMillis(),
                                lastEventAgeMs,lastHttpRttMs,lastDiagnosticReason);
                    }
                    nextPollElapsed=Math.min(nextPollElapsed,now);
                    applyRemoteState(DemoSignal.NAO_OPERAR,-1L,now);
                }
                maybePoll(now);
                maybeRecoverHistory(now);
                updateLinkHealth();
            }
            DemoSignal effective = DemoPolicy.effective(requested, requestedAt, now);
            if (effective != requested) {
                DemoSignal previous = requested;
                requested = DemoSignal.NAO_OPERAR;
                requestedAt = -1L;
                // Expiration to NÃO OPERAR always occurs, even with a fixed window.
                if (displayMode == OverlayDisplayMode.FIXO) {
                    if (overlay == null) showPopup(now);
                    else renderOverlay(); // Keeps a manually minimized bubble minimized.
                } else if (OverlayVisibilityPolicy.shouldPopup(previous, requested, false)) {
                    showPopup(now);
                } else {
                    hidePopup();
                }
            }
            if (OverlayVisibilityPolicy.shouldHide(popupShownAt, now, displayMode)) {
                hidePopup();
            } else if (overlay != null) {
                updateCountdown(DemoPolicy.effective(requested,requestedAt,now));
            }
            tickHandler.postDelayed(this, 250L);
        }
    };

    private OverlayDisplayMode readMode() {
        return OverlayDisplayMode.fromSetting(getSharedPreferences(
                OverlayDisplayMode.PREFERENCES, MODE_PRIVATE).getString(OverlayDisplayMode.PREF_KEY, null));
    }

    private TextView label(String value, int sizeSp, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(sizeSp);
        text.setTextColor(color);
        text.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return text;
    }

    private GradientDrawable background(int color, int border, int radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radiusDp));
        shape.setStroke(dp(1), border);
        return shape;
    }

    private int dp(float val) {
        return (int) (val * getResources().getDisplayMetrics().density + 0.5f);
    }

    private final class DragListener implements View.OnTouchListener {
        private final boolean togglesOnTap;
        private float rawX, rawY;
        private int originalX, originalY;
        private boolean dragged;

        DragListener(boolean togglesOnTap) { this.togglesOnTap = togglesOnTap; }
        @Override public boolean onTouch(View v, MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    rawX = ev.getRawX(); rawY = ev.getRawY();
                    originalX = layoutParams.x; originalY = layoutParams.y;
                    dragged = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float diffX = ev.getRawX() - rawX;
                    float diffY = ev.getRawY() - rawY;
                    if (Math.abs(diffX) > dp(7) || Math.abs(diffY) > dp(7)) dragged = true;
                    if (dragged) {
                        Point screen = new Point();
                        windowManager.getDefaultDisplay().getSize(screen);
                        layoutParams.x = Math.max(0, Math.min(screen.x - layoutParams.width,
                                originalX + Math.round(diffX)));
                        layoutParams.y = Math.max(0, Math.min(screen.y - dp(60),
                                originalY + Math.round(diffY)));
                        windowManager.updateViewLayout(overlay, layoutParams);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!dragged && togglesOnTap) {
                        minimized = false;
                        renderOverlay();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    return true;
                default:
                    return false;
            }
        }
    }

    @Override public void onDestroy() {
        if (bridgeMode) GuardianStore.stop(this,BridgeSessionStore.wanted(this));
        bridgeGeneration++;
        bridgeMode = false;
        stopNetworkMonitor();
        BridgeAuditStore.clearHeartbeat(this);
        BridgeAuditStore.setHealth(this,BridgeReliability.LinkState.DESATIVADO,-1L,-1L,BridgeFailure.NENHUMA,0);
        tickHandler.removeCallbacks(expirationTick);
        ioExecutor.shutdownNow();
        historyExecutor.shutdownNow();
        hidePopup();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
