package com.traderproaielite.overlaydemo;

/** DEMO-only controller decisions. A missing publication never proves a planned stop. */
public final class AdaptiveEmitterPolicy {
    private AdaptiveEmitterPolicy() {}
    public static final long ACTIVE_MS=2000L, IDLE_MS=20000L, HISTORY_IDLE_MS=30000L;
    public enum State { INATIVO, EM_EXECUCAO, ENCERRADO, CANCELADO, AGUARDANDO_PRIMEIRO, AGUARDANDO_ENCERRAMENTO, EMISSOR_INDISPONIVEL }
    public static State classify(String state,long server,long start,long end,long actual,long last,int count,boolean event) {
        if (server<=0 || count<0) throw new IllegalArgumentException();
        if ("INATIVO".equals(state)) {
            if(event || count!=0) throw new IllegalArgumentException();
            return State.INATIVO;
        }
        if (start<=0 || end<=start || start>server || end-start>1800000L || (count==0 && last>0) || (count>0 && (last<start || last>=end || last>server))) throw new IllegalArgumentException();
        if ("ENCERRADO".equals(state) || "CANCELADO".equals(state)) {
            if(event || actual<start || actual>server || ("ENCERRADO".equals(state) && actual<end)) throw new IllegalArgumentException();
            return State.valueOf(state);
        }
        if (!"EM_EXECUCAO".equals(state) || actual>0) throw new IllegalArgumentException();
        if(server>=end) {
            if(event) throw new IllegalArgumentException();
            return server-end<=15000L ? State.AGUARDANDO_ENCERRAMENTO : State.EMISSOR_INDISPONIVEL;
        }
        if(event) {
            if(count==0) throw new IllegalArgumentException();
            return State.EM_EXECUCAO;
        }
        if(count==0 && server-start<=15000L) return State.AGUARDANDO_PRIMEIRO;
        return State.EMISSOR_INDISPONIVEL;
    }
    public static boolean idle(State state) {return state==State.INATIVO || state==State.ENCERRADO || state==State.CANCELADO;}
    public static long delay(State state) {return idle(state)?IDLE_MS:ACTIVE_MS;}
    public static long deadline(long expires,long end) {return Math.min(expires,end);}
    public static boolean safeState(String status) {return "AGUARDAR".equals(status)||"NAO_OPERAR".equals(status);}
}
