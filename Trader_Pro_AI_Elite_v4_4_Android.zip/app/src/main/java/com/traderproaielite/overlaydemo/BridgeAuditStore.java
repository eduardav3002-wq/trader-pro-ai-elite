package com.traderproaielite.overlaydemo;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.Instant;

/** Bounded private DEMO diagnostics. Does not store project URL, publishable key or PIN. */
public final class BridgeAuditStore {
    private BridgeAuditStore() {}
    private static final String PREF = "bridge_v32_audit"; // preserve v3.2 history
    private static final String CURSOR = "bridge_v33_cursor";
    private static final int MAX_EVENTS = 500;
    private static volatile long liveHeartbeat = -1L; // service and activity share this process

    public static String lastEventId(Context context) {
        return context.getSharedPreferences(CURSOR, Context.MODE_PRIVATE).getString("id", "");
    }
    public static long lastIssuedMs(Context context) {
        return context.getSharedPreferences(CURSOR, Context.MODE_PRIVATE).getLong("issued", -1L);
    }
    public static boolean rememberEvent(Context context, String id, long issuedMs) {
        if (id == null || id.isEmpty() || issuedMs <= 0) return false;
        return context.getSharedPreferences(CURSOR,Context.MODE_PRIVATE).edit()
                .putString("id", id).putLong("issued", issuedMs).commit();
    }
    public static boolean live() {
        return BridgeMonitorPolicy.heartbeatFresh(liveHeartbeat,android.os.SystemClock.elapsedRealtime());
    }
    public static void clearCursor(Context context) {
        context.getSharedPreferences(CURSOR,Context.MODE_PRIVATE).edit().clear().apply();
    }

    public static void setHealth(Context context, BridgeReliability.LinkState state,
                                 long rttMs, long ageMs, BridgeFailure cause, int consecutiveFailures) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("health", state.name())
                .putString("cause", cause.name())
                .putInt("consecutive_failures", consecutiveFailures)
                .putLong("checked_wall_ms", System.currentTimeMillis())
                .putLong("rtt_ms", rttMs)
                .putLong("age_ms", ageMs)
                .apply();
    }

    public static void heartbeat(Context context,long elapsed) {
        liveHeartbeat=elapsed;
    }
    public static void clearHeartbeat(Context context) {
        liveHeartbeat=-1L;
    }
    public static String diagnostic(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String health = p.getString("health","DESATIVADO");
        BridgeFailure cause;
        try { cause = BridgeFailure.valueOf(p.getString("cause","NENHUMA")); }
        catch (Exception ignored) { cause = BridgeFailure.RESPOSTA_INVALIDA; }
        long checked=p.getLong("checked_wall_ms",-1L), rtt=p.getLong("rtt_ms",-1L);
        long age=p.getLong("age_ms",-1L);
        long heartbeat=liveHeartbeat;
        boolean live=BridgeMonitorPolicy.heartbeatFresh(heartbeat,android.os.SystemClock.elapsedRealtime());
        android.os.PowerManager pm=(android.os.PowerManager)context.getSystemService(Context.POWER_SERVICE);
        String shownHealth=(!live && !"DESATIVADO".equals(health)) ? "MONITOR SEM CONFIRMAÇÃO · NÃO OPERAR" : health;
        StringBuilder s=new StringBuilder("Ponte DEMO: ").append(shownHealth)
                .append("\nMonitor local: ").append(live ? "heartbeat recente" : "sem heartbeat recente")
                .append("\nEconomia de bateria: ").append(pm==null ? "desconhecida" : pm.isPowerSaveMode() ? "ATIVA" : "desativada")
                .append("\nDiagnóstico: ").append(cause.description())
                .append("\nFalhas seguidas: ").append(p.getInt("consecutive_failures",0));
        if (checked>0) s.append("\nÚltima consulta: ").append(Instant.ofEpochMilli(checked));
        if (rtt>=0) s.append("\nConsulta HTTP: ").append(rtt).append(" ms");
        if (age>=0) s.append("\nIdade estimada da mensagem: ").append(age).append(" ms");
        s.append("\nIdade estimada ≠ latência total garantida. Relógios podem divergir.");
        return s.toString();
    }

    private static String lastControllerState="DESCONHECIDO";
    public static void controllerState(AdaptiveEmitterPolicy.State state) {
        lastControllerState=state==null ? "DESCONHECIDO" : state.name();
    }

    public static void append(Context context,String outcome,DemoSignal signal,String id,
                              long issued,long received,long age,long rtt,BridgeFailure reason) {
        SharedPreferences p=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        JSONArray previous;
        try { previous=new JSONArray(p.getString("items","[]")); }
        catch(Exception ignored) { previous=new JSONArray(); }
        JSONObject row=new JSONObject();
        try {
            row.put("resultado",outcome);
            row.put("motivo",reason.name());
            row.put("estado",signal.name());
            row.put("evento",id==null ? "—" : id.substring(0,Math.min(8,id.length())));
            row.put("emitido_utc",issued>0 ? Instant.ofEpochMilli(issued).toString() : "—");
            row.put("recebido_utc",Instant.ofEpochMilli(received).toString());
            row.put("idade_estimada_ms",age);
            row.put("http_rtt_ms",rtt);
            row.put("event_id",id==null ? "" : id);
            row.put("ultimo_estado_emissor",lastControllerState);
            android.os.PowerManager pm=(android.os.PowerManager)context.getSystemService(Context.POWER_SERVICE);
            row.put("tela_interativa",pm==null ? "DESCONHECIDO" : (pm.isInteractive()?"SIM":"NAO"));
            JSONArray bounded=new JSONArray();
            for(int i=Math.max(0,previous.length()-(MAX_EVENTS-1));i<previous.length();i++) bounded.put(previous.get(i));
            bounded.put(row);
            p.edit().putString("items",bounded.toString()).apply();
        } catch(Exception ignored) { /* Audit never interrupts a fail-closed overlay. */ }
    }

    private static JSONArray items(Context context) {
        try {return new JSONArray(context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("items","[]"));}
        catch(Exception ignored){return new JSONArray();}
    }

    public static String summary(Context context) {
        JSONArray list=items(context);
        int received=0, rejected=0, fails=0, recovered=0;
        int activeTimeout=0,idleTimeout=0,unknownTimeout=0;
        for(int i=0;i<list.length();i++) {
            JSONObject e=list.optJSONObject(i);
            if(e==null) continue;
            String outcome=e.optString("resultado","");
            if(outcome.equals("FALHA_TIMEOUT")) {
                String phase=e.optString("ultimo_estado_emissor", "DESCONHECIDO");
                if(phase.equals("INATIVO")||phase.equals("ENCERRADO")||phase.equals("CANCELADO")) idleTimeout++;
                else if(phase.equals("DESCONHECIDO")) unknownTimeout++;
                else activeTimeout++;
            }
            if(outcome.equals("NOVO_EVENTO_RECEBIDO")) received++;
            else if(outcome.equals("RECUPERADA_COM_EVENTO_NOVO")) recovered++;
            else if(outcome.startsWith("FALHA_") || outcome.equals("SEM_NOVA_PUBLICACAO")) fails++;
            else if(outcome.contains("REJEITADO") || outcome.contains("ATRASADO")) rejected++;
        }
        return "Amostra dos últimos " + list.length() + " registros · novos: " + received
                + " · recuperações: " + recovered + " · falhas: " + fails + " · rejeições: " + rejected
                + "\nTimeouts por último estado confirmado: ativo/transição " + activeTimeout
                + " · repouso " + idleTimeout + " · desconhecido " + unknownTimeout;
    }

    public static String recent(Context context) {
        JSONArray list=items(context);
        if(list.length()==0) return "Nenhum registro de auditoria ainda.";
        StringBuilder out=new StringBuilder(summary(context)).append("\n\n");
        for(int i=list.length()-1;i>=Math.max(0,list.length()-20);i--) {
            JSONObject e=list.optJSONObject(i); if(e==null)continue;
            out.append(e.optString("recebido_utc","—"))
                    .append(" | ").append(e.optString("resultado","—"))
                    .append(" | ").append(e.optString("estado","—"))
                    .append(" | id ").append(e.optString("evento","—"))
                    .append("\nMotivo: ").append(e.optString("motivo","—"))
                    .append(" | Idade: ").append(e.optLong("idade_estimada_ms",-1L))
                    .append("ms | HTTP: ").append(e.optLong("http_rtt_ms",-1L))
                    .append("ms\n\n");
        }
        return out.toString();
    }

    private static String csvCell(String raw) { return "\""+raw.replace("\"","\"\"")+"\""; }
    public static String exportCsv(Context context) {
        JSONArray list=items(context);
        StringBuilder csv=new StringBuilder("recebido_utc,emitido_utc,resultado,motivo,estado,event_id_prefix,idade_estimada_ms,http_rtt_ms,event_id,ultimo_estado_emissor,tela_interativa\n");
        for(int i=0;i<list.length();i++) {
            JSONObject e=list.optJSONObject(i); if(e==null)continue;
            String[] fields={e.optString("recebido_utc",""),e.optString("emitido_utc",""),
                    e.optString("resultado",""),e.optString("motivo",""),
                    e.optString("estado",""),e.optString("evento",""),
                    String.valueOf(e.optLong("idade_estimada_ms",-1L)),
                    String.valueOf(e.optLong("http_rtt_ms",-1L)),e.optString("event_id",""),
                    e.optString("ultimo_estado_emissor","DESCONHECIDO"),e.optString("tela_interativa","DESCONHECIDO")};
            for(int j=0;j<fields.length;j++) {if(j>0)csv.append(',');csv.append(csvCell(fields[j]));}
            csv.append('\n');
        }
        return csv.toString();
    }

    // Separate bounded trace: does not displace the existing event history.
    private static final int MAX_ATTEMPTS = 1000;
    private static final String ATTEMPT_HEADER = "utc,resultado,motivo,event_id_prefix,http_rtt_ms,proxima_espera_ms\n";
    public static void appendAttempt(Context context, long wall, String outcome, BridgeFailure reason,
                                     String id, long rtt, long delay) {
        try {
            SharedPreferences p=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
            String[] old=p.getString("attempts_v37", "").split("\n");
            StringBuilder out=new StringBuilder();
            for(int i=Math.max(0,old.length-(MAX_ATTEMPTS-1));i<old.length;i++)
                if(!old[i].isEmpty()) out.append(old[i]).append('\n');
            out.append(Instant.ofEpochMilli(wall)).append(',').append(outcome).append(',')
                .append(reason.name()).append(',')
                .append(id==null ? "—" : id.substring(0,Math.min(8,id.length())))
                .append(',').append(rtt).append(',').append(delay).append('\n');
            p.edit().putString("attempts_v37",out.toString()).apply();
        } catch(Exception ignored) { /* Diagnostics must not break the overlay. */ }
    }

    public static String exportAttempts(Context context) {
        return ATTEMPT_HEADER+context.getSharedPreferences(PREF,Context.MODE_PRIVATE)
                .getString("attempts_v37", "");
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove("items").remove("attempts_v37").apply();
    }
}
