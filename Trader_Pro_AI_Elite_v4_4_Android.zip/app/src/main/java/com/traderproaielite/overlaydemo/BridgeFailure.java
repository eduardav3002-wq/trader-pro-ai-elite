package com.traderproaielite.overlaydemo;

import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.net.ConnectException;
import java.io.IOException;
import javax.net.ssl.SSLException;

/** Diagnostic codes only; never expose credentials, full URLs or response bodies. */
public enum BridgeFailure {
    NENHUMA,
    SEM_REDE_LOCAL,
    DNS_INDISPONIVEL,
    TIMEOUT,
    TLS_FALHOU,
    HTTP_NAO_AUTORIZADO,
    HTTP_LIMITE_REQUISICOES,
    HTTP_SERVIDOR,
    HTTP_OUTRO,
    SEM_REGISTRO,
    EVENTO_VENCIDO,
    RESPOSTA_INVALIDA,
    CONFIGURACAO_INVALIDA,
    FALHA_DE_REDE,
    SEM_NOVA_PUBLICACAO,
    FALHA_ARMAZENAMENTO_LOCAL,
    EMISSOR_INDISPONIVEL;

    public static BridgeFailure fromHttp(int status) {
        if (status == 401 || status == 403) return HTTP_NAO_AUTORIZADO;
        if (status == 429) return HTTP_LIMITE_REQUISICOES;
        if (status >= 500) return HTTP_SERVIDOR;
        return HTTP_OUTRO;
    }

    public static BridgeFailure fromException(Exception problem) {
        if (problem instanceof SocketTimeoutException) return TIMEOUT;
        if (problem instanceof UnknownHostException) return DNS_INDISPONIVEL;
        if (problem instanceof SSLException) return TLS_FALHOU;
        if (problem instanceof ConnectException || problem instanceof IOException) return FALHA_DE_REDE;
        return RESPOSTA_INVALIDA;
    }

    public String description() {
        switch (this) {
            case EMISSOR_INDISPONIVEL: return "Sessao ativa sem publicacao valida ou encerramento nao confirmado";
            case NENHUMA: return "Sem falha registrada";
            case SEM_REDE_LOCAL: return "Nenhuma rede de internet disponível no Android";
            case DNS_INDISPONIVEL: return "Falha ao localizar o servidor (DNS)";
            case TIMEOUT: return "Consulta excedeu o tempo de espera";
            case TLS_FALHOU: return "Falha na conexão HTTPS segura";
            case HTTP_NAO_AUTORIZADO: return "Chave pública não autorizada (HTTP 401/403)";
            case HTTP_LIMITE_REQUISICOES: return "Servidor limitou requisições (HTTP 429)";
            case HTTP_SERVIDOR: return "Serviço remoto indisponível (HTTP 5xx)";
            case HTTP_OUTRO: return "Erro HTTP inesperado";
            case SEM_REGISTRO: return "Tabela não devolveu um único registro";
            case EVENTO_VENCIDO: return "Mensagem de demonstração expirada";
            case RESPOSTA_INVALIDA: return "Resposta inválida ou sem integridade";
            case CONFIGURACAO_INVALIDA: return "URL ou chave pública inválidas";
            case FALHA_DE_REDE: return "Falha de comunicação pela internet";
            case SEM_NOVA_PUBLICACAO: return "Conexão ativa, mas sem mensagem nova";
            case FALHA_ARMAZENAMENTO_LOCAL: return "Falha ao gravar cursor local; alerta bloqueado";
            default: return "Falha não identificada";
        }
    }
}
