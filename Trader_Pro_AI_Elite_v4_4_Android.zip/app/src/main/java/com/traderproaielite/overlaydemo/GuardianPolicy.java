package com.traderproaielite.overlaydemo;

/** DEMO only. A delayed loop is evidence of a gap, not proof of a crash. */
public final class GuardianPolicy {
    private GuardianPolicy() {}
    public static final long GAP_MS=15000L;
    public static boolean gap(long last,long now) {
        return last>=0 && (now<last || now-last>=GAP_MS);
    }
    public enum Severity { NORMAL, ALERTA, CRITICA }
    public static Severity severity(BridgeFailure reason,int consecutive) {
        if(reason==BridgeFailure.NENHUMA) return Severity.NORMAL;
        switch(reason) {
            case TLS_FALHOU: case HTTP_NAO_AUTORIZADO: case CONFIGURACAO_INVALIDA:
            case FALHA_ARMAZENAMENTO_LOCAL: case RESPOSTA_INVALIDA:
                return Severity.CRITICA;
            default: return consecutive>=3 ? Severity.CRITICA : Severity.ALERTA;
        }
    }
    public static long retry(int count,BridgeFailure reason,boolean idle) {
        // Keep v4.2 behavior; bound fast retry for repeated active transport failures.
        return SmartReliabilityPolicy.failureDelay(count,reason,idle);
    }
}
