package com.traderproaielite.overlaydemo;

/** v4.2: bounded retry, adaptive poll and monotonic age telemetry. DEMO only. */
public final class SmartReliabilityPolicy {
    private SmartReliabilityPolicy() {}
    public static long controllerDelay(AdaptiveEmitterPolicy.State state) {
        return AdaptiveEmitterPolicy.idle(state) ? 5000L : 2000L;
    }
    public static long activeDelay(long ageMs, boolean awaitingRecovery) {
        return awaitingRecovery || ageMs>=8000L ? 1000L : 2000L;
    }
    public static long failureDelay(int count, BridgeFailure reason, boolean lastConfirmedIdle) {
        // Respect rate limits, credential errors, TLS and other failures via original policy.
        if (!lastConfirmedIdle && (reason==BridgeFailure.TIMEOUT || reason==BridgeFailure.FALHA_DE_REDE)) {
            if(count<=1) return 750L;
            if(count==2) return 1500L;
            if(count==3) return 3000L;
        }
        return BridgeRecoveryPolicy.nextPollDelayMs(count,reason);
    }
    public static long ageAt(long ageAtSample, long sampleElapsed, long nowElapsed) {
        if(ageAtSample<0 || sampleElapsed<0 || nowElapsed<sampleElapsed) return -1L;
        long delta=nowElapsed-sampleElapsed;
        return ageAtSample>Long.MAX_VALUE-delta ? Long.MAX_VALUE : ageAtSample+delta;
    }
}
