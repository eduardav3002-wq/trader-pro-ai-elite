package com.traderproaielite.overlaydemo;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.time.Instant;
import javax.net.ssl.HttpsURLConnection;

/** HTTPS read-only DEMO transport with distinct, sanitized failure types. */
public final class SupabaseDemoClient {
    private SupabaseDemoClient() {}
    public static final class BridgeException extends Exception {
        public final BridgeFailure reason;
        BridgeException(BridgeFailure reason) { super(reason.name()); this.reason = reason; }
    }

    public static final class Event {
        public final String eventId;
        public final DemoSignal state;
        public final long issuedAtMs;
        public final long expiresAtMs;
        public Event(String eventId, DemoSignal state, long issuedAtMs, long expiresAtMs) {
            this.eventId = eventId; this.state = state;
            this.issuedAtMs = issuedAtMs; this.expiresAtMs = expiresAtMs;
        }
    }

    public static final class Snapshot {
        public final AdaptiveEmitterPolicy.State state;
        public final Event event;
        public Snapshot(AdaptiveEmitterPolicy.State state,Event event) {this.state=state;this.event=event;}
    }
    private static long time(JSONObject row,String field) throws Exception {
        if(!row.has(field)) throw new IllegalArgumentException();
        return row.isNull(field)?-1L:Instant.parse(row.getString(field)).toEpochMilli();
    }
    public static Snapshot fetch(String urlInput, String key) throws BridgeException {
        if (!DemoBridgePolicy.validProjectUrl(urlInput)
                || !DemoBridgePolicy.validPublishableKey(key)) {
            throw new BridgeException(BridgeFailure.CONFIGURACAO_INVALIDA);
        }
        long startedNanos=System.nanoTime();
        HttpsURLConnection connection = null;
        try {
            String root = urlInput.trim().replaceAll("/$", "");
            URL endpoint = new URL(root + "/rest/v1/rpc/trader_consultar_v41");
            connection = (HttpsURLConnection) endpoint.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(4000);
            connection.setReadTimeout(4000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("apikey", key);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Cache-Control", "no-cache,no-store");
            int http = connection.getResponseCode();
            if (http != 200) throw new BridgeException(BridgeFailure.fromHttp(http));
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (InputStream input = connection.getInputStream()) {
                byte[] buf = new byte[1024];
                int size, total = 0;
                while ((size = input.read(buf)) != -1) {
                    total += size;
                    if (total > 8192) throw new BridgeException(BridgeFailure.RESPOSTA_INVALIDA);
                    bytes.write(buf, 0, size);
                }
            }
            JSONObject data = new JSONObject(bytes.toString("UTF-8"));
            JSONObject control=data.getJSONObject("controle");
            long server=time(data,"servidor_utc"), now=System.currentTimeMillis();
            if(server<=0 || Math.abs(now-server)>10000L || !DemoBridgePolicy.CHANNEL.equals(control.getString("channel_id"))
                    || control.getInt("intervalo_segundos")!=10 || control.getInt("validade_segundos")!=15 || !data.has("evento"))
                throw new BridgeException(BridgeFailure.RESPOSTA_INVALIDA);
            String rawState=control.getString("estado");
            if(!"INATIVO".equals(rawState)) java.util.UUID.fromString(control.getString("session_id"));
            long start=time(control,"inicio"), end=time(control,"fim_previsto"), last=time(control,"ultima_publicacao");
            JSONObject row=data.isNull("evento")?null:data.getJSONObject("evento");
            AdaptiveEmitterPolicy.State state=AdaptiveEmitterPolicy.classify(rawState,server,start,end,time(control,"fim_real"),last,control.getInt("eventos_emitidos"),row!=null);
            if(row==null) return new Snapshot(state,null);
            String channel=row.getString("channel_id"), eventId=row.getString("event_id"), status=row.getString("status");
            long issued=time(row,"issued_at"), expires=time(row,"expires_at");
            if(!AdaptiveEmitterPolicy.safeState(status) || issued!=last || issued<start || issued>server || expires-issued!=15000L
                    || !DemoBridgePolicy.accepts(channel,eventId,status,row.getString("mode"),row.getString("contract"),issued,expires,now))
                throw new BridgeException(BridgeFailure.RESPOSTA_INVALIDA);
            long deadline=AdaptiveEmitterPolicy.deadline(expires,end);
            long elapsedMs=(System.nanoTime()-startedNanos+999999L)/1000000L;
            deadline=Math.min(deadline,now+Math.max(0L,deadline-server-elapsedMs));
            // Conservative local/server deadline; never add validity for clock skew.
            if(deadline<=now || deadline<=server) throw new BridgeException(BridgeFailure.EVENTO_VENCIDO);
            return new Snapshot(state,new Event(eventId,DemoSignal.fromUntrustedString(status),issued,deadline));
        } catch (BridgeException e) {
            throw e;
        } catch (Exception e) {
            // Exception text may reveal hostnames/response details; expose only a safe error code.
            throw new BridgeException(BridgeFailure.fromException(e));
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
