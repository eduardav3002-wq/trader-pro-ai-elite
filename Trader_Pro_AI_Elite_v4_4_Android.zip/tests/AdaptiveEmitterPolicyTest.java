import com.traderproaielite.overlaydemo.AdaptiveEmitterPolicy;
import static com.traderproaielite.overlaydemo.AdaptiveEmitterPolicy.State.*;
public class AdaptiveEmitterPolicyTest {
    static int n=0;
    static void yes(boolean b){n++;if(!b)throw new AssertionError("test "+n);}
    static void invalid(Runnable r){try{r.run();throw new AssertionError("expected invalid");}catch(IllegalArgumentException e){n++;}}
    public static void main(String[] args){
        long start=100000L,end=220000L;
        yes(AdaptiveEmitterPolicy.classify("INATIVO",start,-1,-1,-1,-1,0,false)==INATIVO);
        yes(AdaptiveEmitterPolicy.classify("EM_EXECUCAO",start+10000,start,end,-1,-1,0,false)==AGUARDANDO_PRIMEIRO);
        yes(AdaptiveEmitterPolicy.classify("EM_EXECUCAO",start+16000,start,end,-1,-1,0,false)==EMISSOR_INDISPONIVEL);
        yes(AdaptiveEmitterPolicy.classify("EM_EXECUCAO",start+12000,start,end,-1,start+10000,1,true)==EM_EXECUCAO);
        yes(AdaptiveEmitterPolicy.classify("EM_EXECUCAO",start+40000,start,end,-1,start+10000,1,false)==EMISSOR_INDISPONIVEL);
        yes(AdaptiveEmitterPolicy.classify("EM_EXECUCAO",end+1000,start,end,-1,end-10000,11,false)==AGUARDANDO_ENCERRAMENTO);
        yes(AdaptiveEmitterPolicy.classify("EM_EXECUCAO",end+16000,start,end,-1,end-10000,11,false)==EMISSOR_INDISPONIVEL);
        yes(AdaptiveEmitterPolicy.classify("ENCERRADO",end+1000,start,end,end+915,end-9000,11,false)==ENCERRADO);
        yes(AdaptiveEmitterPolicy.classify("CANCELADO",start+20000,start,end,start+19000,start+10000,1,false)==CANCELADO);
        invalid(()->AdaptiveEmitterPolicy.classify("ENCERRADO",end+1000,start,end,end-1,end-10000,11,false));
        invalid(()->AdaptiveEmitterPolicy.classify("ENCERRADO",end+1000,start,end,end,end-10000,11,true));
        invalid(()->AdaptiveEmitterPolicy.classify("EM_EXECUCAO",end,start,end,-1,end-10000,11,true));
        invalid(()->AdaptiveEmitterPolicy.classify("OUTRO",start+1000,start,end,-1,-1,0,false));
        invalid(()->AdaptiveEmitterPolicy.classify("EM_EXECUCAO",start+1000,start,end,-1,-1,0,true));
        invalid(()->AdaptiveEmitterPolicy.classify("EM_EXECUCAO",start+1000,start,end,-1,start+2000,1,true));
        yes(AdaptiveEmitterPolicy.delay(EM_EXECUCAO)==2000L);
        yes(AdaptiveEmitterPolicy.delay(ENCERRADO)==20000L);
        yes(AdaptiveEmitterPolicy.delay(INATIVO)==20000L);
        yes(AdaptiveEmitterPolicy.delay(EMISSOR_INDISPONIVEL)==2000L);
        yes(AdaptiveEmitterPolicy.deadline(end+10000,end)==end);
        yes(AdaptiveEmitterPolicy.deadline(end-10000,end)==end-10000);
        yes(AdaptiveEmitterPolicy.safeState("AGUARDAR"));yes(AdaptiveEmitterPolicy.safeState("NAO_OPERAR"));
        yes(!AdaptiveEmitterPolicy.safeState("COMPRA"));yes(!AdaptiveEmitterPolicy.safeState("VENDA"));
        System.out.println(n+" verificacoes OK · controlador adaptativo v4.1");
    }
}
