import com.traderproaielite.overlaydemo.*;
import static com.traderproaielite.overlaydemo.GuardianPolicy.*;
public class GuardianPolicyTest {
    static int n;
    static void check(boolean b){n++;if(!b)throw new AssertionError("test "+n);}
    public static void main(String[] args){
        check(!gap(-1,99999)); check(!gap(1000,15999)); check(gap(1000,16000));
        check(gap(1000,999)); check(gap(0,100000));
        check(severity(BridgeFailure.NENHUMA,0)==Severity.NORMAL);
        check(severity(BridgeFailure.TIMEOUT,1)==Severity.ALERTA);
        check(severity(BridgeFailure.TIMEOUT,3)==Severity.CRITICA);
        check(severity(BridgeFailure.TLS_FALHOU,1)==Severity.CRITICA);
        check(severity(BridgeFailure.HTTP_NAO_AUTORIZADO,1)==Severity.CRITICA);
        check(severity(BridgeFailure.FALHA_ARMAZENAMENTO_LOCAL,1)==Severity.CRITICA);
        check(retry(1,BridgeFailure.TIMEOUT,false)==750);
        check(retry(4,BridgeFailure.TIMEOUT,false)==30000);
        check(retry(1,BridgeFailure.HTTP_LIMITE_REQUISICOES,false)==30000);
        check(!BridgeMonitorPolicy.keepRepeated(true,-1,1000));
        System.out.println(n+" verificacoes OK · Guardian v4.3");
    }
}
