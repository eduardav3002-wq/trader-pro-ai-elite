import com.traderproaielite.overlaydemo.SessionReconcilePolicy;
import java.time.Instant;
public class SessionReconcilePolicyTest {
    static int n;
    static void check(boolean b){n++;if(!b)throw new AssertionError("test "+n);}
    static String id(int i){return String.format("%08d-1234-1234-1234-123456789abc",i);}
    static String t(long x){return Instant.ofEpochMilli(x).toString();}
    static final String H="sequencia,event_id,contrato,estado_historico,emitido_utc,expira_utc,recuperado_utc,somente_auditoria\n";
    static final String L="recebido_utc,emitido_utc,resultado,motivo,estado,event_id_prefix,idade_estimada_ms,http_rtt_ms,event_id,ultimo_estado_emissor,tela_interativa\n";
    static String h(int i,long a,long b,long c){return i+","+id(i)+",WINZ26,AGUARDAR,"+t(a)+","+t(b)+","+t(c)+",true\n";}
    static String l(int i,long a,long b,String outcome,String reason,String state){return "\""+String.join("\",\"",t(b),a<0?"—":t(a),outcome,reason,state,"prefix","100","50",i<0?"":id(i),"EM_EXECUCAO","SIM")+"\"\n";}
    static SessionReconcilePolicy.Report run(String h,String l,long expected){return SessionReconcilePolicy.reconcile(H+h,L+l,1000,10000,10,expected);}
    public static void main(String[] args){
        String h=h(11,2000,3000,2500)+h(12,4000,5000,6000)+h(13,6000,8000,7000)+h(14,9000,11000,9500);
        String first=l(11,2000,2200,"NOVO_EVENTO_RECEBIDO","NENHUMA","AGUARDAR");
        String fault=l(-1,-1,3500,"FALHA_SEM_REDE_LOCAL","SEM_REDE_LOCAL","NAO_OPERAR");
        String last=l(14,9000,9500,"RECUPERADA_COM_EVENTO_NOVO","NENHUMA","AGUARDAR");
        var r=run(h,first+fault+last,2);
        check(r.history==4);check(r.matched==2);check(r.missing==2);check(r.expiredOnIncorporation==1);check(!r.limited);check(r.details.toString().contains("true,COMUNICACAO"));check(r.details.toString().contains("false,COMUNICACAO"));check(r.summary().contains("50.00%"));
        r=run(h,first+fault+last,3);check(r.limited);check(r.summary().contains("NÃO CALCULADA"));
        r=run(h,first+first+last,3);check(r.duplicate==1&&r.limited);
        r=run(h,l(11,2000,3000,"NOVO_EVENTO_RECEBIDO","NENHUMA","AGUARDAR"),1);check(r.inconsistent==1&&r.limited);
        r=run(h,l(11,2000,2200,"NOVO_EVENTO_RECEBIDO","NENHUMA","VENDA"),1);check(r.inconsistent==1);
        r=run(h,last+l(99,9500,9600,"NOVO_EVENTO_RECEBIDO","NENHUMA","AGUARDAR"),2);check(r.unmatched==1&&r.limited);
        r=run(h(13,6000,8000,7000),"",0);check(r.gaps==1&&r.limited);
        r=run(h(11,500,900,3000)+h(12,11000,12000,13000),"",0);check(r.history==0&&r.summary().contains("NÃO CALCULADA"));
        r=run(h,first+l(11,2000,2400,"SEM_NOVA_PUBLICACAO","SEM_NOVA_PUBLICACAO","NAO_OPERAR")+last,2);check(r.logged==2&&r.duplicate==0);
        check(SessionReconcilePolicy.recoveryDuration(1000,1500)==500);check(SessionReconcilePolicy.recoveryDuration(-1,1500)==-1);check(SessionReconcilePolicy.recoveryDuration(2000,1500)==-1);
        try{run(h,"bad\n",0);throw new AssertionError();}catch(IllegalArgumentException expected){check(true);}
        System.out.println(n+" verificacoes OK · SessionReconcilePolicy");
    }
}
