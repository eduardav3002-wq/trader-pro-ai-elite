import com.traderproaielite.overlaydemo.*;
import static com.traderproaielite.overlaydemo.SmartReliabilityPolicy.*;
public class SmartReliabilityPolicyTest {
    static int n;
    static void check(boolean b){n++;if(!b)throw new AssertionError("test "+n);}
    public static void main(String[] args){
        check(controllerDelay(AdaptiveEmitterPolicy.State.ENCERRADO)==5000);
        check(controllerDelay(AdaptiveEmitterPolicy.State.INATIVO)==5000);
        check(controllerDelay(AdaptiveEmitterPolicy.State.CANCELADO)==5000);
        check(controllerDelay(AdaptiveEmitterPolicy.State.EM_EXECUCAO)==2000);
        check(activeDelay(7999,false)==2000);
        check(activeDelay(8000,false)==1000);
        check(activeDelay(0,true)==1000);
        check(failureDelay(1,BridgeFailure.TIMEOUT,false)==750);
        check(failureDelay(2,BridgeFailure.TIMEOUT,false)==1500);
        check(failureDelay(3,BridgeFailure.FALHA_DE_REDE,false)==3000);
        check(failureDelay(4,BridgeFailure.TIMEOUT,false)==30000);
        check(failureDelay(1,BridgeFailure.TIMEOUT,true)==5000);
        check(failureDelay(1,BridgeFailure.HTTP_LIMITE_REQUISICOES,false)==30000);
        check(failureDelay(1,BridgeFailure.HTTP_NAO_AUTORIZADO,false)==30000);
        check(failureDelay(1,BridgeFailure.CONFIGURACAO_INVALIDA,false)==30000);
        check(failureDelay(1,BridgeFailure.TLS_FALHOU,false)==5000);
        check(failureDelay(1,BridgeFailure.SEM_REDE_LOCAL,false)==5000);
        check(ageAt(1954,1000,16656)==17610);
        check(ageAt(-1,1000,16656)==-1);
        check(ageAt(10,-1,16656)==-1);
        check(ageAt(10,1000,999)==-1);
        check(ageAt(0,1000,1000)==0);
        check(ageAt(Long.MAX_VALUE,1000,1001)==Long.MAX_VALUE);
        check(BridgeRecoveryPolicy.classify("a",10000,"a",10000,11000)==BridgeRecoveryPolicy.Delivery.REPETIDO);
        check(BridgeMonitorPolicy.validityMs(10000,25000,25000)==0);
        check(!AdaptiveEmitterPolicy.safeState("COMPRA"));check(!AdaptiveEmitterPolicy.safeState("VENDA"));
        System.out.println(n+" verificacoes OK · Smart Reliability v4.2");
    }
}
