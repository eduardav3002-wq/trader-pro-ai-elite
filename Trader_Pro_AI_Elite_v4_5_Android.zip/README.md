# Trader Pro AI Elite · Android v4.5 — Adaptive Reliability DEMO

Atualização incremental sobre o código original v4.4.0; versionCode 45. Mesmo applicationId, alias de assinatura traderpro, permissões e namespaces de preferências. Não altera Supabase, RPC trader_consultar_v41, histórico, cursor, nem critérios de aceitação. Exclusivamente DEMO, sem dados de mercado, sem ordens.

## Mudanças v4.5
- Consulta em sessão ativa: preserva 1–2 s quando em recuperação ou fora da janela acelerada; reduz o intervalo após resposta válida para 750 ms quando idade estimada >=7 s, ou >=5 s com RTT >1,5 s. Intervalos não incluem HTTP, agendamento Android ou latência do servidor. Um único pedido ao vivo em voo, backoff e limites de autorização permanecem. Melhora de latência ainda não comprovada; pode aumentar consumo e chamadas.
- Guardian: contagem de eventos aceitos com idade estimada <=3 s, percentual separado por tela interativa/não interativa e contagem de HTTP >1,5 s entre eventos aceitos; estados de tela desconhecidos contabilizados separadamente. Sessões antigas/parciais não são usadas como amostra integral. Métricas não são taxa de entrega nem assertividade de trading. Limites 3 s e 1,5 s são metas diagnósticas, não critérios de aceitação.
- Conciliação e relatório Guardian existentes preservados. A nova qualidade aparece no diagnóstico e em Compartilhar relatório Guardian v4.5. Nenhuma alteração nas regras de validade, rejeição de repetição, recuperação de histórico ou segurança.

## Instalação e teste
1. Exporte os relatórios atuais; não desinstale, não limpe dados e não altere secrets.
2. Envie Trader_Pro_AI_Elite_v4_5_Android.zip à raiz do mesmo repositório main, sem extrair. Crie .github/workflows/android_overlay_v45.yml com o workflow fornecido.
3. Actions > Gerar APK Android v4.5 DEMO assinado > Run workflow se necessário. Somente após Success baixe Trader_Pro_AI_Elite_v4_5_DEMO_assinado. Instale o APK sobre a v4.4; pare se houver conflito de assinatura.
4. Confira histórico preservado e inicie nova sessão Android DEMO; depois inicie emissor v4.1 por 10 minutos. Tela interativa 2 min, não interativa 2 min, rede desligada 30 s, reconecte e mantenha até encerramento e recuperação histórica final. Anote horários. Exporte relatório Guardian e conciliação, CSV de recebimentos e recuperação. Compare UUIDs com servidor, e compare percentuais de idade em condições semelhantes à v4.4.
5. Não conectar corretora ou usar dinheiro real. Esta versão não mede lucratividade.

## Verificação local
16 classes de testes Java puro, 367 verificações passaram (24 novas). SDK Android, Gradle, assinatura e integração com celular/Supabase não testados neste ambiente. Workflow recompila e assina no GitHub.

---
## Referência da versão anterior (v4.4)
# Trader Pro AI Elite · Android v4.4 — Smart Reliability Engine DEMO

Derivado do ZIP v4.3 original. Mesmo applicationId, assinatura esperada, permissões, preferências, cursor, histórico history_v40_*. versionCode 44. Mantém namespace guardian_v43 para preservar contagem cumulativa de sessões não confirmadas. Sem alteração SQL, RPC trader_consultar_v41 e emissor DEMO v4.1 permanecem. Sem feed real, ordens ou corretora.

## Novidades
- Botão Compartilhar conciliação v4.4 (relatório + UUIDs): compara automaticamente UUIDs completos do CSV de recebimentos válidos com o histórico local de auditoria recuperado do servidor, na sessão local atual/última (início do serviço até agora ou fechamento registrado). Captura cursor histórico inicial. Distingue recebimento válido conciliado, ausência de registro válido, divergência de tempo/estado e recebimento sem par no recorte. Não usa prefixos como identidade. Relatório + CSV de detalhes em texto, sem credenciais. Eventos históricos jamais entram no caminho de alertas.
- Indica se os eventos sem recebimento válido já haviam vencido na incorporação histórica. Associa indícios temporais de comunicação, validade/emissão, armazenamento/configuração ou intervalo de loop aos eventos emitidos entre falha registrada e próximo recebimento válido/encerramento. Não atribui causalidade nem infere ausência de falha quando não há registro.
- Guardian mede intervalo monotônico da primeira ocorrência recordFailure até próximo evento válido (média, máximo e episódios completos). Não é tempo desde a religação da internet, nem mede episódios sem recuperação, nem todos os bloqueios que não passam por recordFailure.
- Relatório usa somente cache local (500 registros de recebimentos, 1000 históricos). Se detectar divergência de contagem, UUID duplicado, lacuna, recebimento sem par ou discrepância de estado/tempo, não calcula taxa. Mesmo sem lacuna detectada, taxa é provisória e não comprova completude do servidor, sincronia de relógios ou entrega visual. Eventos emitidos antes do início ficam fora do recorte; recebimentos desses eventos podem aparecer sem par. Se o histórico ainda estiver chegando, gere novamente. Sessão antiga sem baseline v4.4 não pode ser conciliada. Exporte antes de reiniciar o serviço ou limpar históricos. Não muda regras de validade, repetição, backoff, proteção de intervalo ou comportamento do overlay.

## Atualização pelo GitHub
1. Guarde CSVs e relatório Guardian atuais. Não desinstale nem limpe dados.
2. Envie Trader_Pro_AI_Elite_v4_4_Android.zip intacto à raiz do mesmo repositório. Crie .github/workflows/android_overlay_v44.yml com o arquivo fornecido. Preserve workflows antigos.
3. Actions > Gerar APK Android v4.4 DEMO assinado > Run workflow, se não iniciou automaticamente. Mesmos secrets e alias traderpro. Após Success baixe e instale sobre v4.3. Se houver conflito de assinatura, pare; não desinstale.
4. Verifique histórico >=572 na mesma base e saltos zero. Inicie alertas DEMO v4.4 antes de iniciar o emissor DEMO v4.1. Teste 10 minutos: 2 min tela ativa, 2 min tela não interativa, 30 s sem rede, religue e deixe completar. Anote horários das transições. Após encerramento do emissor, mantenha serviço ativo até histórico incorporar a última publicação. Compartilhe conciliação, relatório Guardian e CSVs. Confirme UUIDs com exportação independente do servidor. Não conecte corretora nem opere dinheiro real.

## Testes
15 classes de testes Java puro, 343 verificações passaram (21 novas). APK, assinatura, integração Android/Supabase e GitHub Actions não executados neste ambiente (sem SDK/Gradle). Workflow executará testes e tentará compilar/assinar. Candidata exclusivamente DEMO.
