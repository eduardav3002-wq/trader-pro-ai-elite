package com.traderproaielite.overlaydemo;

import java.util.Locale;

/** v4.5 DEMO: diagnostic targets, never permission to operate. */
public final class SessionQualityPolicy {
    private SessionQualityPolicy() {}
    public static final long AGE_TARGET_MS=3000L;
    public static final long RTT_TARGET_MS=1500L;
    public static boolean onTime(long age){return age>=0 && age<=AGE_TARGET_MS;}
    public static boolean slowHttp(long rtt){return rtt>RTT_TARGET_MS;}
    public static String percent(long hits,long total){
        return total<=0 || hits<0 || hits>total?"SEM AMOSTRA":String.format(Locale.ROOT,"%.2f%%",100.0*hits/total);
    }
    /** Only accelerate the existing healthy cadence, with a 750ms floor. No change to expiry/backoff. */
    public static long activeDelay(long age,long rtt,boolean recovery){
        long original=SmartReliabilityPolicy.activeDelay(age,recovery);
        if(recovery || age<0 || rtt<0)return original;
        // Publisher targets 10s: begin faster observation slightly before the next publication.
        return age>=7000L || (age>=5000L && slowHttp(rtt)) ? 750L : original;
    }
}
