import com.traderproaielite.overlaydemo.*;
import static com.traderproaielite.overlaydemo.SessionQualityPolicy.*;
public class SessionQualityPolicyTest {
    static int n;
    static void check(boolean b){n++;if(!b)throw new AssertionError("test "+n);}
    public static void main(String[] args){
        check(!onTime(-1));check(onTime(0));check(onTime(3000));check(!onTime(3001));
        check(!slowHttp(-1));check(!slowHttp(1500));check(slowHttp(1501));
        check(percent(3,4).equals("75.00%"));check(percent(0,0).equals("SEM AMOSTRA"));
        check(percent(5,4).equals("SEM AMOSTRA"));check(percent(-1,4).equals("SEM AMOSTRA"));
        check(activeDelay(6999,100,false)==2000);check(activeDelay(7000,100,false)==750);
        check(activeDelay(4999,2000,false)==2000);check(activeDelay(5000,2000,false)==750);
        check(activeDelay(9000,2000,true)==1000);check(activeDelay(-1,2000,false)==2000);
        check(activeDelay(9000,-1,false)==1000);
        check(GuardianPolicy.retry(1,BridgeFailure.TIMEOUT,false)==750);
        check(GuardianPolicy.retry(1,BridgeFailure.HTTP_LIMITE_REQUISICOES,false)==30000);
        check(!BridgeMonitorPolicy.keepRepeated(true,15000,1000));
        check(BridgeMonitorPolicy.validityMs(10000,25000,25000)==0);
        check(!AdaptiveEmitterPolicy.safeState("COMPRA"));check(!AdaptiveEmitterPolicy.safeState("VENDA"));
        System.out.println(n+" verificacoes OK · Session Quality v4.5");
    }
}
