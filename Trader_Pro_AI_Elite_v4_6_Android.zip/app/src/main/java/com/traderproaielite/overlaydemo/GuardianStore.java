package com.traderproaielite.overlaydemo;

import android.content.Context;
import android.content.SharedPreferences;
import java.time.Instant;

/** New separate preference namespace; no secrets or signal payloads. Session-local counts. */
public final class GuardianStore {
    private GuardianStore() {}
    private static SharedPreferences p(Context c){return c.getSharedPreferences("guardian_v43",Context.MODE_PRIVATE);}
    public static void start(Context c){
        SharedPreferences s=p(c);
        boolean prior=s.getBoolean("open",false);
        String url=c.getSharedPreferences("bridge_v31",Context.MODE_PRIVATE).getString("url", "");
        long baseline=-1; try {baseline=HistoryRecoveryStore.cursor(c,url);} catch(RuntimeException ignored) {}
        long wall=System.currentTimeMillis();
        s.edit().putBoolean("open",true).putString("start",Instant.ofEpochMilli(wall).toString())
            .putLong("reconcile_start",wall).putLong("reconcile_end",-1).putLong("reconcile_base",baseline)
            .putString("reconcile_project",url).putLong("fault_elapsed",-1).putLong("duration_count",0).putLong("duration_sum",0).putLong("duration_max",0)
            .putLong("unconfirmed",s.getLong("unconfirmed",0)+(prior?1:0))
            .putLong("gaps",0).putLong("max_gap",0).putLong("valid",0).putLong("failures",0)
            .putLong("critical",0).putLong("timeouts",0).putLong("recoveries",0)
            .putLong("quality_samples",0).putLong("quality_on_time",0).putLong("quality_rtt_samples",0).putLong("quality_slow_http",0).putLong("quality_off_samples",0).putLong("quality_off_on_time",0).putLong("quality_on_samples",0).putLong("quality_on_on_time",0).putLong("quality_unknown_screen",0).putLong("screen_off",0).putLong("age_sum",0).putLong("age_max",0)
            .putString("end","—").putString("last_gap","—").putString("severity","NORMAL").commit();
    }
    public static void stop(Context c,boolean wanted){
        SharedPreferences s=p(c); if(!s.getBoolean("open",false)) return;
        s.edit().putBoolean("open",false).putLong("reconcile_end",System.currentTimeMillis()).putString("end",(wanted?"SERVICO_ENCERRADO_COM_SESSAO_SOLICITADA":"ENCERRAMENTO_SOLICITADO")+" · "+Instant.now()).commit();
    }
    public static void gap(Context c,long duration){
        SharedPreferences s=p(c);
        s.edit().putLong("gaps",s.getLong("gaps",0)+1).putLong("max_gap",Math.max(duration,s.getLong("max_gap",0)))
            .putString("last_gap",Instant.now().toString()).putString("severity","CRITICA").apply();
    }
    public static void failure(Context c,BridgeFailure reason,int count,long elapsed){
        SharedPreferences s=p(c); GuardianPolicy.Severity level=GuardianPolicy.severity(reason,count);
        s.edit().putLong("fault_elapsed",s.getLong("fault_elapsed",-1)<0?elapsed:s.getLong("fault_elapsed",-1)).putLong("failures",s.getLong("failures",0)+1)
            .putLong("critical",s.getLong("critical",0)+(level==GuardianPolicy.Severity.CRITICA?1:0))
            .putLong("timeouts",s.getLong("timeouts",0)+(reason==BridgeFailure.TIMEOUT?1:0))
            .putString("severity",level.name()).apply();
    }
    public static void valid(Context c,long age,boolean recovered,long elapsed,long rtt){
        SharedPreferences s=p(c); android.os.PowerManager pm=(android.os.PowerManager)c.getSystemService(Context.POWER_SERVICE);
        boolean screenKnown=pm!=null, screenOff=screenKnown&&!pm.isInteractive();
        boolean timely=SessionQualityPolicy.onTime(age);
        long d=SessionReconcilePolicy.recoveryDuration(s.getLong("fault_elapsed",-1),elapsed);
        s.edit().putLong("quality_samples",s.getLong("quality_samples",0)+1)
            .putLong("quality_on_time",s.getLong("quality_on_time",0)+(timely?1:0))
            .putLong("quality_rtt_samples",s.getLong("quality_rtt_samples",0)+(rtt>=0?1:0))
            .putLong("quality_slow_http",s.getLong("quality_slow_http",0)+(SessionQualityPolicy.slowHttp(rtt)?1:0))
            .putLong("quality_off_samples",s.getLong("quality_off_samples",0)+(screenOff?1:0))
            .putLong("quality_off_on_time",s.getLong("quality_off_on_time",0)+(screenOff&&timely?1:0))
            .putLong("quality_on_samples",s.getLong("quality_on_samples",0)+(screenKnown&&!screenOff?1:0))
            .putLong("quality_on_on_time",s.getLong("quality_on_on_time",0)+(screenKnown&&!screenOff&&timely?1:0))
            .putLong("quality_unknown_screen",s.getLong("quality_unknown_screen",0)+(!screenKnown?1:0))
            .putLong("fault_elapsed",-1).putLong("duration_count",s.getLong("duration_count",0)+(d>=0?1:0))
            .putLong("duration_sum",s.getLong("duration_sum",0)+Math.max(0,d)).putLong("duration_max",Math.max(d,s.getLong("duration_max",0))).putLong("valid",s.getLong("valid",0)+1).putLong("recoveries",s.getLong("recoveries",0)+(recovered?1:0))
            .putLong("screen_off",s.getLong("screen_off",0)+(pm!=null&&!pm.isInteractive()?1:0))
            .putLong("age_sum",s.getLong("age_sum",0)+Math.max(0,age)).putLong("age_max",Math.max(age,s.getLong("age_max",0)))
            .putString("severity","NORMAL").apply();
    }
    public static String report(Context c){
        SharedPreferences s=p(c); long n=s.getLong("valid",0);
        String status=!BridgeSessionStore.wanted(c)?"DESATIVADO":(!BridgeAuditStore.live()?"SEM HEARTBEAT RECENTE · NÃO OPERAR":"HEARTBEAT RECENTE");
        return "Guardian v4.6 · DEMO\nEstado local: "+status+"\nÚltima classificação Guardian: "+s.getString("severity","NORMAL")+"\nInício: "+s.getString("start","—")+"\nFim do serviço: "+s.getString("end","—")
            +"\nSessões anteriores sem fechamento registrado: "+s.getLong("unconfirmed",0)
            +"\nIntervalos do loop ≥15s: "+s.getLong("gaps",0)+" · maior: "+s.getLong("max_gap",0)+"ms"
            +"\nÚltimo intervalo: "+s.getString("last_gap","—")
            +"\nEventos válidos nesta sessão: "+n+" · tela não interativa: "+s.getLong("screen_off",0)
            +"\nIdade estimada média/máxima: "+(n==0?"—":(s.getLong("age_sum",0)/n)+" / "+s.getLong("age_max",0)+"ms")
            +"\nOcorrências recordFailure: "+s.getLong("failures",0)+" · críticas: "+s.getLong("critical",0)+" · timeouts: "+s.getLong("timeouts",0)
            +"\nRecuperações por evento novo: "+s.getLong("recoveries",0)
            +"\nRecuperação monotônica (primeira recordFailure até evento válido): "+durations(s)
            +"\n"+quality(s,n)
            +"\nContagens locais não provam entrega integral; compare UUIDs com servidor. Intervalo não prova encerramento. Sem ordens/feed real.";
    }
    private static String quality(SharedPreferences s,long valid){
        long n=s.getLong("quality_samples",0), hits=s.getLong("quality_on_time",0);
        if(n!=valid) return "Qualidade v4.6: sessão anterior/parcial; inicie nova sessão para medir.";
        long on=s.getLong("quality_on_samples",0), off=s.getLong("quality_off_samples",0), http=s.getLong("quality_rtt_samples",0);
        return "Qualidade v4.6 · somente eventos aceitos (não mede perdas)"
            +"\nIdade ≤3s: "+hits+"/"+n+" · "+SessionQualityPolicy.percent(hits,n)
            +"\nTela interativa: "+SessionQualityPolicy.percent(s.getLong("quality_on_on_time",0),on)+" · n="+on
            +"\nTela não interativa: "+SessionQualityPolicy.percent(s.getLong("quality_off_on_time",0),off)+" · n="+off
            +"\nTela desconhecida: "+s.getLong("quality_unknown_screen",0)
            +"\nHTTP >1,5s (eventos aceitos): "+s.getLong("quality_slow_http",0)+"/"+http
            +"\nMetas diagnósticas; não alteram validade ou bloqueios.";
    }
    private static String durations(SharedPreferences s){
        long n=s.getLong("duration_count",0);
        return n==0?"sem amostra":n+" episódios · média "+s.getLong("duration_sum",0)/n+"ms · máxima "+s.getLong("duration_max",0)+"ms";
    }
    public static SessionReconcilePolicy.Report reconciliation(Context c,String url){
        SharedPreferences s=p(c);
        if(!url.equals(s.getString("reconcile_project",""))) throw new IllegalStateException("projeto diferente da sessão");
        long end=s.getLong("reconcile_end",-1);
        return SessionReconcilePolicy.reconcile(HistoryRecoveryStore.exportCsv(c,url),BridgeAuditStore.exportCsv(c),s.getLong("reconcile_start",-1),end<0?System.currentTimeMillis():end,s.getLong("reconcile_base",-1),s.getLong("valid",0));
    }
}
