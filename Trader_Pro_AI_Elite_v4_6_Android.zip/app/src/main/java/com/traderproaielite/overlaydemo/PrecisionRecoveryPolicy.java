package com.traderproaielite.overlaydemo;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** DEMO display only. No scheduled trade or order is implied by a timestamp. */
public final class PrecisionRecoveryPolicy {
    private PrecisionRecoveryPolicy() {}
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss", new Locale("pt", "BR"))
        .withZone(ZoneId.of("America/Sao_Paulo"));
    public static String clock(long wallMs) { return wallMs <= 0 ? "—" : CLOCK.format(Instant.ofEpochMilli(wallMs)); }
    public static long remaining(long deadline, long now) { return deadline <= now || now < 0 ? 0 : deadline-now; }
    public static boolean networkFault(BridgeFailure reason) {
        return reason == BridgeFailure.SEM_REDE_LOCAL || reason == BridgeFailure.DNS_INDISPONIVEL
            || reason == BridgeFailure.FALHA_DE_REDE || reason == BridgeFailure.TIMEOUT;
    }
    public static boolean protectedBackoff(BridgeFailure reason) {
        return reason == BridgeFailure.HTTP_LIMITE_REQUISICOES || reason == BridgeFailure.HTTP_NAO_AUTORIZADO
            || reason == BridgeFailure.CONFIGURACAO_INVALIDA || reason == BridgeFailure.TLS_FALHOU;
    }
    public static long retry(int count, BridgeFailure reason, boolean idle) {
        if (!idle && reason == BridgeFailure.DNS_INDISPONIVEL && count > 0 && count <= 3)
            return 2000L << (count-1);
        return GuardianPolicy.retry(count,reason,idle);
    }
    public static long wakeDeadline(long scheduled, long protectedUntil, long now,
                                    boolean newlyValidated, BridgeFailure reason) {
        return Math.max(protectedUntil, newlyValidated && networkFault(reason) ? Math.min(scheduled,now) : scheduled);
    }
    public static String panel(long issued, long received, long deadlineWall, long deadlineElapsed, long now) {
        if (issued <= 0 || received <= 0 || deadlineWall <= received || remaining(deadlineElapsed, now) == 0)
            return "SEM EVENTO VÁLIDO · SEM ORDENS";
        return "Brasília · emissão " + clock(issued) + "\nRecebido " + clock(received)
            + " · limite local ≈ " + clock(deadlineWall) + "\nValidade DEMO: "
            + String.format(Locale.ROOT,"%.1f s", remaining(deadlineElapsed, now)/1000.0) + " · sem ordens";
    }
}
