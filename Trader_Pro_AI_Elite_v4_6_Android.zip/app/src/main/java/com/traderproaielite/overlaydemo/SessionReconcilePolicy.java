package com.traderproaielite.overlaydemo;

import java.time.Instant;
import java.util.*;

/** Audit only. No dependency on live overlay or execution. */
public final class SessionReconcilePolicy {
    private SessionReconcilePolicy() {}
    static long ms(String s){return Instant.parse(s).toEpochMilli();}
    static boolean uuid(String s){return s.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");}
    static String family(String reason){
        switch(reason){
            case "SEM_REDE_LOCAL": case "DNS_INDISPONIVEL": case "TIMEOUT": case "FALHA_DE_REDE": case "HTTP_SERVIDOR": case "TLS_FALHOU": return "COMUNICACAO";
            case "FALHA_ARMAZENAMENTO_LOCAL": case "RESPOSTA_INVALIDA": case "CONFIGURACAO_INVALIDA": return "INTERNA_OU_CONFIGURACAO";
            case "EVENTO_VENCIDO": case "SEM_NOVA_PUBLICACAO": case "EMISSOR_INDISPONIVEL": return "EMISSAO_OU_VALIDADE";
            default: return "OUTRA";
        }
    }
    static final class Receipt {final long time,issued; final String state; Receipt(long t,long i,String s){time=t;issued=i;state=s;}}
    static final class Window {final long start,end; final Set<String> families; Window(long a,long b,Set<String> f){start=a;end=b;families=new TreeSet<>(f);}}
    public static final class Report {
        public int history, matched, missing, expiredOnIncorporation, inconsistent, unmatched, logged, gaps, duplicate;
        public boolean limited;
        public long start,end,baseline;
        public final StringBuilder details=new StringBuilder("sequencia,event_id,resultado,expirado_na_incorporacao,evidencia_na_emissao\n");
        public String summary(){return "Conciliação v4.6 · sessão local · cache de auditoria (provisório)\nRecorte UTC: "+Instant.ofEpochMilli(start)+" até "+Instant.ofEpochMilli(end)+" · cursor inicial: "+baseline+"\nHistórico no recorte: "+history+" · recebidos válidos conciliados: "+matched+"\nSem recebimento válido registrado: "+missing+" · destes, vencidos na incorporação: "+expiredOnIncorporation+"\nDivergências: "+inconsistent+" · recebimentos sem par no recorte: "+unmatched+" · duplicados: "+duplicate+"\nRegistros válidos no CSV: "+logged+" · saltos observados no histórico após início: "+gaps+"\nCobertura: "+(limited?"INCOMPLETA / INDETERMINADA":"SEM LACUNA LOCAL DETECTADA (não certificada)")+"\nTaxa observada no cache: "+(limited||history==0?"NÃO CALCULADA":String.format(Locale.ROOT,"%.2f%%",100.0*matched/history))+"\nCausas são indícios temporais, não prova. Histórico não gera alertas. Confirme com exportação independente do servidor.";}
    }
    public static Report reconcile(String historical,String live,long start,long end,long baseline,long expectedValid){
        if(start<=0||end<start||baseline<0||expectedValid<0) throw new IllegalArgumentException("sessao sem baseline");
        Report r=new Report(); r.start=start;r.end=end;r.baseline=baseline; Map<String,Receipt> received=new HashMap<>(); List<Window> windows=new ArrayList<>(); long fault=-1,previousLive=-1; Set<String> families=new TreeSet<>();
        String[] ll=live.split("\n");
        if(ll.length==0||!ll[0].startsWith("recebido_utc,emitido_utc,resultado,"))throw new IllegalArgumentException("CSV recebimentos");
        for(int n=1;n<ll.length;n++){
            String line=ll[n]; if(line.isEmpty())continue;
            if(!line.startsWith("\"")||!line.endsWith("\""))throw new IllegalArgumentException("linha recebimentos");
            String[] f=line.substring(1,line.length()-1).split("\",\"",-1); if(f.length!=11)throw new IllegalArgumentException("campos recebimentos");
            long t=ms(f[0]); if(t<start||t>end)continue;
            if(previousLive>t)r.limited=true; previousLive=t;
            if(f[2].equals("NOVO_EVENTO_RECEBIDO")||f[2].equals("RECUPERADA_COM_EVENTO_NOVO")){
                r.logged++; if(!uuid(f[8])){r.limited=true;continue;}
                if(received.putIfAbsent(f[8],new Receipt(t,ms(f[1]),f[4]))!=null)r.duplicate++;
                if(fault>=0){windows.add(new Window(fault,t,families));fault=-1;families.clear();}
            } else if(f[2].startsWith("FALHA_")||f[2].equals("SEM_NOVA_PUBLICACAO")){
                if(fault<0)fault=t; families.add(f[2].equals("FALHA_GUARDIAN_INTERVALO_LOOP")?"INTERVALO_LOOP":family(f[3]));
            } else if(f[2].equals("ENCERRAMENTO_PREVISTO")||f[2].equals("AGUARDANDO_ENCERRAMENTO")){
                if(fault>=0){windows.add(new Window(fault,t,families));fault=-1;families.clear();}
            }
        }
        if(fault>=0)windows.add(new Window(fault,end,families));
        if(r.logged!=expectedValid||r.duplicate>0)r.limited=true;
        String[] hh=historical.split("\n"); if(hh.length==0||!hh[0].startsWith("sequencia,event_id,contrato,"))throw new IllegalArgumentException("CSV historico");
        long previous=baseline; Set<String> ids=new HashSet<>();
        for(int n=1;n<hh.length;n++){
            if(hh[n].isEmpty())continue; String[] f=hh[n].split(",",-1);
            if(f.length!=8||!f[7].equals("true")||!uuid(f[1]))throw new IllegalArgumentException("linha historico");
            long seq=Long.parseLong(f[0]); if(seq<=baseline)continue;
            if(seq<=previous||!ids.add(f[1]))throw new IllegalArgumentException("ordem/UUID historico");
            if(seq>previous+1){r.gaps++;r.limited=true;} previous=seq;
            long issued=ms(f[4]),expires=ms(f[5]),incorporated=ms(f[6]); if(issued<start||issued>end)continue;
            if(expires<=issued)throw new IllegalArgumentException("validade historico");
            r.history++; Receipt a=received.remove(f[1]); String result; boolean expired=incorporated>=expires;
            Set<String> evidence=new TreeSet<>();
            if(a==null){r.missing++;if(expired)r.expiredOnIncorporation++;result="SEM_RECEBIMENTO_VALIDO_REGISTRADO";
                for(Window w:windows)if(issued>=w.start&&issued<=w.end)evidence.addAll(w.families);
            } else if(a.time>=expires||a.time<issued||a.issued!=issued||!a.state.equals(f[3])){r.inconsistent++;r.limited=true;result="DIVERGENCIA_TEMPO_OU_ESTADO";}
            else {r.matched++;result="RECEBIDO_VALIDO_CONCILIADO";}
            r.details.append(seq).append(',').append(f[1]).append(',').append(result).append(',').append(expired).append(',').append(evidence.isEmpty()?"SEM_INDICIO_REGISTRADO":String.join("+",evidence)).append('\n');
        }
        r.unmatched=received.size(); if(r.unmatched>0)r.limited=true;
        for(String id:new TreeSet<>(received.keySet()))r.details.append(",").append(id).append(",RECEBIMENTO_SEM_PAR_NO_RECORTE,,NAO_APLICAVEL\n");
        return r;
    }
    public static long recoveryDuration(long first,long valid){return first>=0&&valid>=first?valid-first:-1;}
}
