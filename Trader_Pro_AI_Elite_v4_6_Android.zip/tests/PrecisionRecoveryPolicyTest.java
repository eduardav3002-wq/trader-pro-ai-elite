import com.traderproaielite.overlaydemo.*;
import static com.traderproaielite.overlaydemo.PrecisionRecoveryPolicy.*;
public class PrecisionRecoveryPolicyTest {
    static int n;
    static void check(boolean b){n++;if(!b)throw new AssertionError("test "+n);}
    public static void main(String[] args){
        long issued=java.time.Instant.parse("2026-11-27T19:25:31.531Z").toEpochMilli();
        check(clock(issued).equals("16:25:31")); check(clock(-1).equals("—"));
        check(remaining(1000,1000)==0); check(remaining(1000,999)==1); check(remaining(1000,0)==1000);
        check(remaining(-1,500)==0); check(remaining(1000,-1)==0);
        check(panel(issued,issued+1000,issued+15000,16000,1000).contains("15.0 s"));
        check(panel(issued,issued+1000,issued+15000,16000,16000).startsWith("SEM EVENTO"));
        check(panel(issued,issued+1000,issued+15000,-1,1000).startsWith("SEM EVENTO"));
        check(panel(issued,issued+1000,issued+15000,16000,1000).contains("16:25:31"));
        check(retry(1,BridgeFailure.DNS_INDISPONIVEL,false)==2000);
        check(retry(2,BridgeFailure.DNS_INDISPONIVEL,false)==4000);
        check(retry(3,BridgeFailure.DNS_INDISPONIVEL,false)==8000);
        check(retry(4,BridgeFailure.DNS_INDISPONIVEL,false)==30000);
        check(retry(1,BridgeFailure.DNS_INDISPONIVEL,true)==5000);
        check(retry(1,BridgeFailure.HTTP_LIMITE_REQUISICOES,false)==30000);
        check(wakeDeadline(30000,0,1000,true,BridgeFailure.SEM_REDE_LOCAL)==1000);
        check(wakeDeadline(30000,0,1000,false,BridgeFailure.SEM_REDE_LOCAL)==30000);
        check(wakeDeadline(30000,25000,1000,true,BridgeFailure.DNS_INDISPONIVEL)==25000);
        check(wakeDeadline(30000,0,1000,true,BridgeFailure.HTTP_LIMITE_REQUISICOES)==30000);
        check(protectedBackoff(BridgeFailure.TLS_FALHOU)); check(!protectedBackoff(BridgeFailure.DNS_INDISPONIVEL));
        check(AdaptiveEmitterPolicy.safeState("AGUARDAR")); check(!AdaptiveEmitterPolicy.safeState("COMPRA"));
        check(!AdaptiveEmitterPolicy.safeState("VENDA"));
        System.out.println(n+" verificacoes OK · PrecisionRecovery v4.6");
    }
}
